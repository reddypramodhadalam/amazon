package com.rexel.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.rexel.runners.RunnerBase;
import com.rexel.utils.GlobalParams;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class CalculatorPage extends BasePage {
	GlobalParams params = new GlobalParams();
	TestData td = new TestData();

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'customerServiceTools')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'customerServiceTools')]")
	private MobileElement calculatorTab;

	@AndroidFindBy(accessibility = "Service tools section see all text with link")
	@iOSXCUITFindBy(accessibility = "Service tools section see all text with link")
	private MobileElement seeAllBtn;

	@AndroidFindBy(accessibility = "Cable Length")
	@iOSXCUITFindBy(accessibility = "Cable Length")
	private MobileElement cableLength;

	@AndroidFindBy(accessibility = "Calculator app bar rounded icon button")
	@iOSXCUITFindBy(accessibility = "Calculator app bar rounded icon button")
	private MobileElement formula;

	@AndroidFindBy(xpath = "//android.view.View/android.view.View[1]/android.widget.Button[1]")
	@iOSXCUITFindBy(accessibility = "//XCUIElementTypeStaticText[contains(@name,'Reactive Power')]")
	private MobileElement formulaValidate;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='5']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement innerRing;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement outerRing;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='11']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[3]")
	private MobileElement rings;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='13']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[4]")
	private MobileElement cable;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='16']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Cable length appbar bottom result')]")
	private MobileElement layers;

	@AndroidFindBy(xpath = "//android.widget.EditText[6]")
	@iOSXCUITFindBy(accessibility = "Decimal input textFormField")
	private MobileElement unrolledRings;

	@AndroidFindBy(accessibility = "Add Unrolled rings")
	@iOSXCUITFindBy(accessibility = "Add Unrolled rings")
	private MobileElement unrolledRingsCheckbox;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Cable length appbar bottom result')]")
	private MobileElement cableLengthValue;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Cable length appbar bottom result')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[2]/XCUIElementTypeStaticText")
	private MobileElement cableLengthValueResult;

	@AndroidFindBy(accessibility = "Cost of Electrical Power")
	@iOSXCUITFindBy(accessibility = "Cost of Electrical Power")
	private MobileElement costOfElectricalPower;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='3']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement power;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement operatingTimePerDay;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='8']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[3]")
	private MobileElement centPerKWH;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='11']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[4]")
	private MobileElement alternatePower;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'387,630')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'387,630')]")
	private MobileElement savingPerYear;

	@AndroidFindBy(accessibility = "Active Power")
	@iOSXCUITFindBy(accessibility = "Active Power")
	private MobileElement activePower;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement voltage;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement current;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Power factor')]/following-sibling::android.view.View")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Power factor')]/following-sibling::XCUIElementTypeOther")
	private MobileElement powerFactor;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='13']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[4]")
	private MobileElement activePowertext;

	@AndroidFindBy(xpath = "//android.view.View[@content-desc='1 Ph. Tab 2 of 2']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'1 Ph.')]")
	private MobileElement switchTabActivePower;

	@AndroidFindBy(accessibility = "Apparent Power")
	@iOSXCUITFindBy(accessibility = "Apparent Power")
	private MobileElement apparentPower;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement voltageApparent;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement currentApparent;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Apparent power (S)')]/following-sibling::android.view.View")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Apparent power (S)')]/following-sibling::XCUIElementTypeOther")
	private MobileElement apparentPowerText;

	@AndroidFindBy(accessibility = "1 Ph.\\nTab 2 of 2")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'1 Ph.')]")
	private MobileElement switchTabApparent;

	@AndroidFindBy(accessibility = "Ohm's Law")
	@iOSXCUITFindBy(accessibility = "Ohm's Law")
	private MobileElement ohmsLaw;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement amperageOhm;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement resistanceOhm;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Voltage (U)')]/following-sibling::android.view.View")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Voltage (U)')]/following-sibling::XCUIElementTypeOther")
	private MobileElement voltageOhm;

	@AndroidFindBy(xpath = "//android.view.View[@content-desc=\\\"Enter any 2 values\\nAmperage (I)\\nA\\nVoltage (U)\\nV\\nPower (P)\\nW\\\"]/android.view.View")
	private MobileElement powerOhm;

	@AndroidFindBy(accessibility = "P, U, I\\nTab 2 of 2")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[contains(@name,'P, U, I')]")
	private MobileElement switchTabOhm;

	@AndroidFindBy(accessibility = "Interval")
	@iOSXCUITFindBy(accessibility = "Interval")
	private MobileElement interval;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='5']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement length;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='6']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement intervala;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='9']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[3]")
	private MobileElement intervalb;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='10']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[4]")
	private MobileElement point;

	@AndroidFindBy(xpath = "//android.view.View[@content-desc='= 95']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='= 95']")
	private MobileElement intervalResult;

	@AndroidFindBy(xpath = "//android.widget.EditText[4]")
	@iOSXCUITFindBy(accessibility = "Interval c")
	private MobileElement intervalc;

	@AndroidFindBy(accessibility = "Points\nTab 2 of 2")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Points')]")
	private MobileElement switchTabInterval;

	@AndroidFindBy(xpath = "//android.view.View[@content-desc='= 24']")
	private MobileElement pointValue;

	@AndroidFindBy(accessibility = "Capacitor Capacitance")
	@iOSXCUITFindBy(accessibility = "Capacitor Capacitance")
	private MobileElement capacitorCapacitance;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement capacitorReactivePower;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement voltagecapacitor;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='10']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[3]")
	private MobileElement frequency;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Capacitor of compensating')]/following-sibling::android.view.View")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Capacitor of compensating')]/following-sibling::XCUIElementTypeOther")
	private MobileElement capacitor;

	@AndroidFindBy(accessibility = "Capacitor Power")
	@iOSXCUITFindBy(accessibility = "Capacitor Power")
	private MobileElement capacitorPower;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement activePowerCapacitor;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement actual;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='10']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[3]")
	private MobileElement desired;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Required capacitor power')]/following-sibling::android.view.View")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Required capacitor power')]/following-sibling::XCUIElementTypeOther")
	private MobileElement requiredCapacitorPower;

	@AndroidFindBy(accessibility = "Reactive Power")
	@iOSXCUITFindBy(accessibility = "Reactive Power")
	private MobileElement reactivePower;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[1]")
	private MobileElement apparentPowerReactive;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'Reactive Power')]/following-sibling::android.view.View")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Reactive Power')]/following-sibling::XCUIElementTypeOther")
	private MobileElement reactivePowerReactive;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[contains(@name, 'Decimal input textFormField')])[2]")
	private MobileElement activePowerReactive;

	@AndroidFindBy(accessibility = "Clear button")
	@iOSXCUITFindBy(accessibility = "Clear button")
	private MobileElement resetBtn;

	@AndroidFindBy(xpath = "//android.widget.EditText[1]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[3]/XCUIElementTypeTextField[1]")
	private MobileElement resetBtnValidate;
	
	@iOSXCUITFindBy(accessibility = "Done")
	private MobileElement doneButton;

	public CalculatorPage clickOnResetBtn() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		click(resetBtn);
		return this;
	}

	public CalculatorPage clickOnFormulaBtn() {
		click(formula);
		return this;
	}

	public CalculatorPage clickOnCostOfElectricalPowerBtn() {
		waitForVisibility(costOfElectricalPower);
		click(costOfElectricalPower);
		return this;
	}

	public CalculatorPage clickOnActivePowerbtn() {
		waitForVisibility(activePower);
		click(activePower);
		return this;
	}

	public CalculatorPage clickOnApparentPowerbtn() {
		waitForVisibility(apparentPower);
		click(apparentPower);
		return this;
	}

	public CalculatorPage clickOnOhmsLawbtn() {
		waitForVisibility(ohmsLaw);
		click(ohmsLaw);
		return this;
	}

	public CalculatorPage clickOnInterval() {
		waitForVisibility(interval);
		click(interval);
		return this;
	}

	public CalculatorPage clickOnCapacitorCapacitancebtn() {
		waitForVisibility(capacitorCapacitance);
		click(capacitorCapacitance);
		return this;
	}

	public CalculatorPage clickOnCapacitorPowerbtn() {
		waitForVisibility(capacitorPower);
		click(capacitorPower);
		return this;
	}

	public CalculatorPage clickOnReactivePowerbtn() {
		waitForVisibility(reactivePower);
		click(reactivePower);
		return this;
	}

	public CalculatorPage clickOnCableLengthBtn() {
		waitForVisibility(cableLength);
		click(cableLength);
		return this;
	}

	public CalculatorPage enterCableLengthValue() {
		click(innerRing);
		sendKeys(innerRing, td.getTestData(RunnerBase.country, "cableLengthInnerRing"));
		click(outerRing);
		sendKeys(outerRing, td.getTestData(RunnerBase.country, "cableLengthOuterRing"));
		click(rings);
		sendKeys(rings, td.getTestData(RunnerBase.country, "cableLengthRings"));
		click(cable);
		sendKeys(cable, td.getTestData(RunnerBase.country, "cableLengthCable"));
		// pressByCoordinates(90, 150);
		click(layers);
		sendKeys(layers, td.getTestData(RunnerBase.country, "cableLengthLayers"));
		pressByCoordinates(540, 894);
		click(unrolledRingsCheckbox);
		// waitForVisibility(unrolledRings);
		// scrollToElement(unrolledRings, "down");
		// click(unrolledRings);
		sendKeys(unrolledRings, td.getTestData(RunnerBase.country, "cableLengthUnrolledRings"));
		return this;
	}

	public CalculatorPage validateCableLength() {
		Assert.assertTrue(cableLengthValueResult.isDisplayed(), "Cable length value is not 13823 m");
		return this;
	}

	public CalculatorPage enterCostofElectricalPowerValue() {

		click(power);
		sendKeys(power, td.getTestData(RunnerBase.country, "electricPower"));
		click(operatingTimePerDay);
		sendKeys(operatingTimePerDay, td.getTestData(RunnerBase.country, "electricPowerOperatingTimePerDay"));
		click(centPerKWH);
		sendKeys(centPerKWH, td.getTestData(RunnerBase.country, "electricPowerCent"));
		click(alternatePower);
		sendKeys(alternatePower, td.getTestData(RunnerBase.country, "electricPowerAlternate"));
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
		}
		return this;
	}

	public CalculatorPage validateCostOfElectricalPower() {
		if(RunnerBase.platform.equals("iOS")){
			doneButton.click();
		}
		Assert.assertTrue(savingPerYear.isDisplayed(), "Cost of Electric Power is not correct");
		return this;
	}

	public CalculatorPage enterActivePowerValue3Ph() {

		click(voltage);
		sendKeys(voltage, td.getTestData(RunnerBase.country, "activePowerVoltage"));
		click(current);
		sendKeys(current, td.getTestData(RunnerBase.country, "activePowerCurrent"));
		click(activePowertext);
		sendKeys(activePowertext, td.getTestData(RunnerBase.country, "activePowerText"));
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
		}
		return this;
	}

	public CalculatorPage enterActivePowerValue1Ph() {

		click(switchTabActivePower);
		click(voltage);
		sendKeys(voltage, "5");
		click(current);
		sendKeys(current, "6");
		click(activePowertext);
		sendKeys(activePowertext, "20");
		return this;
	}

	public CalculatorPage validateActivePower3Ph() {
		String text = powerFactor.getText();
		Assert.assertTrue(text.contains(td.getTestData(RunnerBase.country, "activePowerFactor")),
				"Active power factor for 3ph is not correct");
		return this;
	}

	public CalculatorPage validateActivePower1Ph() {
		Assert.assertTrue(powerFactor.isDisplayed(), "Active power factor for 1ph is not correct");
		return this;
	}

	public CalculatorPage enterApparentPowerValue3Ph() {
		click(voltage);
		sendKeys(voltage, td.getTestData(RunnerBase.country, "apparentPowerVoltage"));
		click(current);
		sendKeys(current, td.getTestData(RunnerBase.country, "aparentPowerCurrent"));
		return this;
	}

	public CalculatorPage validateApparentPower3Ph() {
		String text = apparentPowerText.getText();
		Assert.assertTrue(text.contains(td.getTestData(RunnerBase.country, "apparentPowerText")),
				"Apparent Power for 3ph is not correct");
		return this;
	}

	public CalculatorPage enterApparentPowerValue1Ph() {
		click(switchTabActivePower);
		click(voltage);
		sendKeys(voltage, "2");
		click(current);
		sendKeys(current, "3");
		return this;
	}

	public CalculatorPage validateApparentPower1Ph() {
		Assert.assertTrue(apparentPowerText.isDisplayed(), "Apparent Power for 1ph is not correct");
		return this;
	}

	public CalculatorPage enterOhmsLawUIR() {
		click(amperageOhm);
		sendKeys(amperageOhm, td.getTestData(RunnerBase.country, "ohmsLawamperage"));
		click(resistanceOhm);
		sendKeys(resistanceOhm, td.getTestData(RunnerBase.country, "ohmsLawResistance"));
		return this;
	}

	public CalculatorPage validateOhmsLawUIR() {
		String text = voltageOhm.getText();
		Assert.assertTrue(text.contains(td.getTestData(RunnerBase.country, "ohmsLawVoltage")), "Ohms voltage is not displayed");
		return this;
	}

	public CalculatorPage enterOhmsLawPUI() {
		click(switchTabOhm);
		click(amperageOhm);
		sendKeys(amperageOhm, "5");
		click(resistanceOhm);
		sendKeys(resistanceOhm, "3");
		return this;
	}

	public CalculatorPage validateOhmsLawPUI() {
		Assert.assertTrue(powerOhm.isDisplayed(), "Ohms law power is not displayed");
		return this;
	}

	public CalculatorPage enterIntervalValue() {

		click(length);
		sendKeys(length, td.getTestData(RunnerBase.country, "intervalLength"));
		click(intervala);
		sendKeys(intervala, td.getTestData(RunnerBase.country, "intervalA"));
		click(intervalb);
		sendKeys(intervalb, td.getTestData(RunnerBase.country, "intervalB"));
		click(point);
		sendKeys(point, td.getTestData(RunnerBase.country, "intervalPoint"));
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
		}
		return this;
	}

	public CalculatorPage validateInterval() {
		Assert.assertTrue(intervalResult.isDisplayed(), "Interval value for the interval c is not matching");
		return this;
	}

	public CalculatorPage enterIntervalValuePoints() {

		click(length);
		sendKeys(length, "100");
		click(intervala);
		sendKeys(intervala, "3");
		click(intervalb);
		sendKeys(intervalb, "5");
		click(point);
		sendKeys(point, "4");
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
		}
		return this;
	}

	public CalculatorPage validateIntervalPoints() {
		Assert.assertTrue(pointValue.isDisplayed(), "Interval value for the points is not matching");
		return this;
	}

	public CalculatorPage enterCapacitorCapacitanceValue() {

		click(capacitorReactivePower);
		sendKeys(capacitorReactivePower, td.getTestData(RunnerBase.country, "capacitanceReactivePower"));
		click(voltagecapacitor);
		sendKeys(voltagecapacitor, td.getTestData(RunnerBase.country, "capacitanceVoltage"));
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
		}
		click(frequency);
		sendKeys(frequency, td.getTestData(RunnerBase.country, "capacitanceFrequency"));
		return this;
	}

	public CalculatorPage validateCapacitanceValue() {
		String text = capacitor.getText();
		Assert.assertTrue(text.contains(td.getTestData(RunnerBase.country, "capacitanceCompensatingCapacitor")), "Capacitor Capacitance is not matching");
		return this;
	}

	public CalculatorPage enterCapacitorPowerValue() {

		click(activePowerCapacitor);
		sendKeys(activePowerCapacitor, td.getTestData(RunnerBase.country, "capacitorPowerActivePower"));
		click(actual);
		sendKeys(actual, td.getTestData(RunnerBase.country, "capacitorPowerActual"));
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
		}
		click(desired);
		sendKeys(desired, td.getTestData(RunnerBase.country, "capacitorPowerDesired"));
		return this;
	}

	public CalculatorPage validateCapacitorPowerValue() {
		String text = requiredCapacitorPower.getText();
		Assert.assertTrue(text.contains(td.getTestData(RunnerBase.country, "capacitorPowerRequiredPower")), "Capacitor power is not matching");
		return this;
	}

	public CalculatorPage enterReactivePowerValue() {
		click(apparentPowerReactive);
		sendKeys(apparentPowerReactive, td.getTestData(RunnerBase.country, "reactivePowerApparentPower"));
		click(activePowerReactive);
		sendKeys(activePowerReactive, td.getTestData(RunnerBase.country, "reactivePowerActivePower"));
		return this;
	}

	public CalculatorPage validateReactivePower() {
		String text = reactivePowerReactive.getText();
		Assert.assertTrue(text.contains(td.getTestData(RunnerBase.country, "reactivePowerActual")), "Reactive power is not matching");
		return this;
	}

	public CalculatorPage validateFormulaBtn() {
		Assert.assertTrue(formulaValidate.isDisplayed(), "Formula is not displayed");
		return this;
	}

	public CalculatorPage validateResetBtn() {
		String text;
		if(RunnerBase.platform.equals("iOS")) {
			text = activePowerReactive.getText();
			Assert.assertFalse(text.contains(td.getTestData(RunnerBase.country, "reactivePowerActivePower")), "Reactive power is matching after reset");
		}
		else {
			text = reactivePowerReactive.getText();
			Assert.assertFalse(text.contains(td.getTestData(RunnerBase.country, "reactivePowerActual")), "Reactive power is matching after reset");
		}
		return this;
	}

	public CalculatorPage clickOnSeeAllBtn() {
		waitForVisibility(seeAllBtn);
		click(seeAllBtn);
		return this;
	}

	public CalculatorPage clickOnCalculatorTab() {
		waitForVisibility(calculatorTab);
		click(calculatorTab);
		return this;
	}

	public CalculatorPage clickOnIntervalbtn() {
		waitForVisibility(interval);
		click(interval);
		return this;

	}

	public CalculatorPage getCoordinatesSeeAllBtn() {

		seeAllBtn.getLocation();

		return this;
	}

}
