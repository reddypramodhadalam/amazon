package com.rexel.pages;

import io.appium.java_client.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
import okhttp3.Cookie;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.ImmutableMap;
import com.rexel.runners.RunnerBase;
import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.TestUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import io.appium.java_client.ios.IOSBatteryInfo;
import io.appium.java_client.ios.IOSDriver;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;

import java.awt.image.BufferedImage;
import java.time.Duration;

public class BasePage {
	protected AppiumDriver<?> driver;
	TestUtils utils = new TestUtils();

	public BasePage() {
		this.driver = new DriverManager().getDriver();
		PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	}

	public boolean waitForVisibility(MobileElement e) {
		WebDriverWait wait = new WebDriverWait(driver, TestUtils.WAIT);
		return wait.until(ExpectedConditions.visibilityOf(e))!=null;
	}

	public void waitForVisibility(By e) {
		WebDriverWait wait = new WebDriverWait(driver, TestUtils.WAIT);
		wait.until(ExpectedConditions.visibilityOfElementLocated(e));
	}

	public void clear(MobileElement e) {
		waitForVisibility(e);
		e.clear();
	}

	public void click(MobileElement e) {
		waitForVisibility(e);
		e.click();
	}

	public void click(MobileElement e, String msg) {
		waitForVisibility(e);
		utils.log().info(msg);
		e.click();
	}

	public void click(By e, String msg) {
		waitForVisibility(e);
		utils.log().info(msg);
		driver.findElement(e).click();
	}

	public void sendKeys(MobileElement e, String txt) {
		waitForVisibility(e);
		e.sendKeys(txt);
	}

	public void sendKeys(MobileElement e, String txt, String msg) {
		waitForVisibility(e);
		utils.log().info(msg);
		e.sendKeys(txt);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(RunnerBase.platform.equalsIgnoreCase("Android")) {
			driver.hideKeyboard();
		}	
		else {
			driver.findElementByAccessibilityId("Done").click();
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	public String getAttribute(MobileElement e, String attribute) {
		waitForVisibility(e);
		return e.getAttribute(attribute);
	}

	public String getAttribute(By e, String attribute) {
		waitForVisibility(e);
		return driver.findElement(e).getAttribute(attribute);
	}

	public String getText(MobileElement e, String msg) {
		String txt;
		switch (new GlobalParams().getPlatformName()) {
		case "Android":
			txt = getAttribute(e, "text");
			break;
		case "iOS":
			txt = getAttribute(e, "label");
			break;
		default:
			throw new IllegalStateException("Unexpected value: " + new GlobalParams().getPlatformName());
		}
		utils.log().info(msg + txt);
		return txt;
	}

	public String getText(By e, String msg) {
		String txt;
		switch (new GlobalParams().getPlatformName()) {
		case "Android":
			txt = getAttribute(e, "text");
			break;
		case "iOS":
			txt = getAttribute(e, "label");
			break;
		default:
			throw new IllegalStateException("Unexpected value: " + new GlobalParams().getPlatformName());
		}
		utils.log().info(msg + txt);
		return txt;
	}

	public void closeApp() {
		((InteractsWithApps) driver).closeApp();
	}

	public void launchApp() {
		((InteractsWithApps) driver).launchApp();
	}

	public MobileElement andScrollToElementUsingUiScrollable(String childLocAttr, String childLocValue) {
		return (MobileElement) ((FindsByAndroidUIAutomator) driver).findElementByAndroidUIAutomator(
				"new UiScrollable(new UiSelector()" + ".scrollable(true)).scrollIntoView(" + "new UiSelector()."
						+ childLocAttr + "(\"" + childLocValue + "\"));");
	}

	public MobileElement iOSScrollToElementUsingMobileScroll(MobileElement e) {
		RemoteWebElement element = ((RemoteWebElement) e);
		String elementID = element.getId();
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("element", elementID);
		//	  scrollObject.put("direction", "down");
		//	  scrollObject.put("predicateString", "label == 'ADD TO CART'");
		//	  scrollObject.put("name", "test-ADD TO CART");
		scrollObject.put("toVisible", "sdfnjksdnfkld");
		driver.executeScript("mobile:scroll", scrollObject);
		return e;
	}

	public By iOSScrollToElementUsingMobileScrollParent(MobileElement parentE, String predicateString) {
		RemoteWebElement parent = (RemoteWebElement) parentE;
		String parentID = parent.getId();
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("element", parentID);
		//	  scrollObject.put("direction", "down");
		scrollObject.put("predicateString", predicateString);
		//	  scrollObject.put("name", "test-ADD TO CART");
		//        scrollObject.put("toVisible", "sdfnjksdnfkld");
		driver.executeScript("mobile:scroll", scrollObject);
		By m = MobileBy.iOSNsPredicateString(predicateString);
		System.out.println("Mobilelement is " + m);
		return m;
	}

	public MobileElement scrollToElement(MobileElement element, String direction) throws Exception {
		Dimension size = driver.manage().window().getSize();
		int startX = (int) (size.width * 0.5);
		int endX = (int) (size.width * 0.5);
		int startY = 0;
		int endY = 0;
		boolean isFound = false;

		switch (direction) {
		case "up":
			endY = (int) (size.height * 0.4);
			startY = (int) (size.height * 0.6);
			break;

		case "down":
			endY = (int) (size.height * 0.6);
			startY = (int) (size.height * 0.4);
			break;
		}

		for (int i = 0; i < 3; i++) {
			if (find(element, 1)) {
				isFound = true;
				break;
			} else {
				swipe(startX, startY, endX, endY, 1000);
			}
		}
		if (!isFound) {
			throw new Exception("Element not found");
		}
		return element;
	}

	public By scrollToElement(By element, String direction) throws Exception {
		Dimension size = driver.manage().window().getSize();
		int startX = (int) (size.width * 0.5);
		int endX = (int) (size.width * 0.5);
		int startY = 0;
		int endY = 0;
		boolean isFound = false;

		switch (direction) {
		case "up":
			endY = (int) (size.height * 0.4);
			startY = (int) (size.height * 0.6);
			break;

		case "down":
			endY = (int) (size.height * 0.6);
			startY = (int) (size.height * 0.4);
			break;
		}

		for (int i = 0; i < 3; i++) {
			if (find(element, 1)) {
				isFound = true;
				break;
			} else {
				swipe(startX, startY, endX, endY, 1000);
			}
		}
		if (!isFound) {
			throw new Exception("Element not found");
		}
		return element;
	}

	public boolean find(final MobileElement element, int timeout) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeout);
			return wait.until(new ExpectedCondition<Boolean>() {
				@Override
				public Boolean apply(WebDriver driver) {
					if (element.isDisplayed()) {
						return true;
					}
					return false;
				}
			});
		} catch (Exception e) {
			return false;
		}
	}

	public boolean find(final By element, int timeout) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeout);
			return wait.until(new ExpectedCondition<Boolean>() {
				@Override
				public Boolean apply(WebDriver driver) {
					if (driver.findElement(element).isDisplayed()) {
						return true;
					}
					return false;
				}
			});
		} catch (Exception e) {
			return false;
		}
	}

	public void swipe(int startX, int startY, int endX, int endY, int millis) throws InterruptedException {
		TouchAction t = new TouchAction(driver);
		t.press(point(startX, startY)).waitAction(waitOptions(ofMillis(millis))).moveTo(point(endX, endY)).release()
		.perform();
	}

	public void pressByCoordinates(int x, int y) {
		TouchAction t = new TouchAction(driver);
		t.press(PointOption.point(x, y)).release().perform();
	}

	public int[] getElementCoordinates(MobileElement e) {
		Dimension dim = e.getSize();
		int[] coordinates = {dim.getWidth(),dim.getHeight()};
		return coordinates;
	}



	public int[] getElementLocation(MobileElement e) {
		Point location = e.getLocation();
		int x = location.getX();
		int y = location.getY();
		Dimension dim = e.getSize();
		int[] loc = {location.getX(),location.getY(),dim.getWidth(),dim.getHeight()};
		
		System.out.println("Start X:::::"+x+"Start Y::::::"+y+"Width::::::"+dim.getWidth()+"Height::::::"+dim.getHeight());
		return loc;
	}

	public void executeImageInjection(String id) {
		driver.executeScript("browserstack_executor: {\"action\":\"cameraImageInjection\", \"arguments\": {\"imageUrl\" : \"media://"+id+"\"}}");
		try {
			Thread.sleep(5000);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void navigateBack() {
		driver.navigate().back();
		try {
			Thread.sleep(3000);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void switchContext() {
		Set<String> contextNames = driver.getContextHandles();
		for (String contextName : contextNames) {
		    System.out.println(contextName);
		    if(contextName.contains("WEBVIEW")) {
		    	driver.context(contextName);
		    }
		}
	}
	
	public void switchContextToNative() {
		driver.context("NATIVE_APP");
	}
	
	public void refreshPage() {
		driver.navigate().back();
	}
	
	public String getGpuAndroid(String packageName) {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		Object response = jse.executeScript("browserstack_executor: {\"action\":\"adbShell\",\"arguments\":{\"command\":\"dumpsys gfxinfo "+packageName+"\"}}");
		utils.log().info("Getting GPU info for Android is successful");
		return response.toString();
	}
	
	public String getMemoryInfoAndroid(String packageName) {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		Object response = jse.executeScript("browserstack_executor: {\"action\":\"adbShell\",\"arguments\":{\"command\":\"dumpsys meminfo "+ packageName+"\"}}");
		utils.log().info("Getting memory info for Android is successful");
		return response.toString();
	}
	
	public String getMemoryInfoIos() {
		// Execute the custom script to launch the Instruments tool
		Object result = driver.executeScript("mobile: startPerfRecord", ImmutableMap.of("url", "instrument://com.apple.dt.Instruments3/xcode/"));

		System.out.println("Instruments Launched: " + result.toString());
		utils.log().info("getting memory info for iOS");
		return result.toString();
	}
	
	public void unplugBattery() {
		JavascriptExecutor jse = (JavascriptExecutor)driver;;
		jse.executeScript("browserstack_executor: {\"action\":\"adbShell\",\"arguments\":{\"command\":\"dumpsys battery unplug\"}}");
		utils.log().info("Unplug device battery is successful");
	}
	
	public void runApplicationInBackground(int seconds) {
		driver.runAppInBackground(Duration.ofSeconds(seconds));
		utils.log().info("Running app in background is successful");
	}
	
	public void resetBattery() {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("browserstack_executor: {\"action\":\"adbShell\",\"arguments\":{\"command\":\"dumpsys battery reset\"}}");
		utils.log().info("Unplug device battery is successful");
	}
	
	public double getBatteryPercentage() {
		Map<String,Object> result = (Map<String,Object>) ((JavascriptExecutor) driver).executeScript("mobile:batteryInfo");
		try {
		long BatteryPercent= (long)result.get("level")*100;	
		return  BatteryPercent;	
		}catch (Exception e) {
			double BatteryPercent= (double)result.get("level")*100;	
			return  BatteryPercent;
		}
	}
	
	public void getBatteryUsagIosApp() {
		IOSBatteryInfo batteryInfo = ((IOSDriver) driver).getBatteryInfo();
		System.out.println("Battery Level: " + batteryInfo.getLevel());
		System.out.println("Battery State: " + batteryInfo.getState());
	}
	
	public double getMemoryInfoAndroidAfterLogin(String packageName) {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		Object response = jse.executeScript("browserstack_executor: {\"action\":\"adbShell\",\"arguments\":{\"command\":\"dumpsys meminfo "+packageName+"\"}}");
		utils.log().info("Getting memory info for Android is successful");
		String data = response.toString();
		String[] newData = data.split("TOTAL PSS:");
		String total_PSS=newData[1].substring(0,13).trim();
		double usage = Double.parseDouble(total_PSS);
		double actualUsage = usage/1024;
		return actualUsage;
	}
}