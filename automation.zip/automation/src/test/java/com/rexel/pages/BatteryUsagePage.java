package com.rexel.pages;

import org.testng.Assert;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang3.time.StopWatch;
import com.rexel.runners.RunnerBase;
import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.TestUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class BatteryUsagePage extends BasePage {
	TestUtils utils = new TestUtils();
	GlobalParams params = new GlobalParams();
	TestData td = new TestData();
	double initialBattery;
	
	public BatteryUsagePage() {
		
	}
	
	public BatteryUsagePage runAppInBackground() {
		//unplugBattery();
		initialBattery = getBatteryPercentage();
		runApplicationInBackground(20);
		return this;
	}
	
	public BatteryUsagePage validateBatteryUsageWhenApplicationIsRunningInBackground() {
		double actualBattery = 0;
		if(RunnerBase.platform.equalsIgnoreCase("Android")) {
			actualBattery = getBatteryPercentage();
		}
		//resetBattery();
		double battery = initialBattery - actualBattery;
		String expectedBattery = td.getTestData(RunnerBase.country,"batteryValue");
		double expectedValue = Double.parseDouble(expectedBattery);
		Assert.assertTrue(battery < expectedValue, "Battery Usage is not below the expected Value" +td.getTestData(RunnerBase.country,"batteryValue"));
		return this;
	}
	
	public BatteryUsagePage validateCpuUsage() {
		String filePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test"
				+ File.separator + "resources" + File.separator + "SwiftCodeCPUUsage";
		String[] cmd = {filePath,"./SwiftCodeCPUUsage"};
		byte[] bo = new byte[100];
		Process p;
		try {
			p = Runtime.getRuntime().exec(cmd);
			double cpuUsage = p.getInputStream().read(bo);
			System.out.println("cpu usage.... " + cpuUsage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
}