package com.rexel.pages;

import java.util.Properties;

import org.testng.Assert;

import com.rexel.runners.RunnerBase;
import com.rexel.utils.TestUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class ScannerPage extends BasePage {

	TestUtils utils = new TestUtils();
	TestData td = new TestData();

	@AndroidFindBy(accessibility = "Scanner widget self checkout card and text")
	@iOSXCUITFindBy(accessibility = "Scanner widget self checkout card and text")
	private MobileElement selfCheckout;

	@AndroidFindBy(accessibility = "Change Branch")
	@iOSXCUITFindBy(accessibility = "Change Branch")
	private MobileElement changeBranch;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Add to Self Checkout']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Add to Self Checkout']")
	private MobileElement addToSelfCheckout;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Start Selfcheckout']")
	@iOSXCUITFindBy(accessibility = "Start Selfcheckout")
	private MobileElement startSelfChkout;

	@AndroidFindBy(accessibility = "Scanner widget regular checkout card and text")
	@iOSXCUITFindBy(accessibility = "Scanner widget regular checkout card and text")
	private MobileElement startRegularChkout;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'scanner')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'scanner')]")
	private MobileElement scanner;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Add Item to Cart']")
	@iOSXCUITFindBy(accessibility = "Add Item to Cart")
	private MobileElement addItemtoCart;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Add by ID']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Add by ID']")
	private MobileElement addById;

	@AndroidFindBy(accessibility = "Product scan by id widget search icon")
	@iOSXCUITFindBy(accessibility = "Product scan by id widget search icon")
	private MobileElement enterId;

	@AndroidFindBy(xpath = "(//android.widget.Button[1])[2]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeApplication[@name=\\\"UAT Rexel AT\\\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[3]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeButton[2]")
	private MobileElement deleteproduct;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Yes']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeApplication[@name=\"UAT Rexel AT\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[3]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeButton[2]")
	private MobileElement approveDelete;

	@AndroidFindBy(xpath = "//android.view.View/android.widget.ImageView[1]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeApplication[@name=\"UAT Rexel AT\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeButton[1]")
	private MobileElement closebtn;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Scan Sales Rep’s QR Code']")
	private MobileElement scanSaleCode;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Delete All']")
	private MobileElement deleteAll;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Start Selfcheckout']")
	private MobileElement selfChkout;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='0']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@name,'Product scan by id text field')]")
	private MobileElement addId;

	@AndroidFindBy(accessibility = "Add Item to Cart")
	@iOSXCUITFindBy(accessibility = "Add Item to Cart")
	private MobileElement addItemRegularCheckout;

	@AndroidFindBy(accessibility = "Custom outlined button Scan Branch Code")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name,'Scan Branch Code')]")
	private MobileElement scanBranchCodeButton;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='OK']")
	private MobileElement allowCamera;

	@iOSXCUITFindBy(accessibility = "Try Again")
	private MobileElement tryAgainBtn;

	@AndroidFindBy(accessibility = "We were unable to recognize the ID you entered\nPlease check the ID and re-enter")
	@iOSXCUITFindBy(accessibility = "Ok")
	private MobileElement invalidProductPopUp;

	@AndroidFindBy(accessibility = "Back")
	@iOSXCUITFindBy(accessibility = "Back")
	private MobileElement backButton;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.ImageView")
	private MobileElement flashIcon;

	@AndroidFindBy(accessibility = "Try Again")
	@iOSXCUITFindBy(accessibility = "Try Again")
	private MobileElement tryAgainButton;

	@AndroidFindBy(accessibility = "Product info view close button")
	@iOSXCUITFindBy(accessibility = "Product info view close button")
	private MobileElement productCloseButton;

	@AndroidFindBy(accessibility = "OK")
	private MobileElement okButton;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[3]")
	@iOSXCUITFindBy(accessibility = "Ref Rexel: LEG067001")
	private MobileElement articleId;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='6']")
	@iOSXCUITFindBy(accessibility = "Product info view product quantity")
	private MobileElement quantity;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeApplication[@name=\"UAT Rexel AT\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeOther[2]/XCUIElementTypeTextField")
	private MobileElement currentQuantity;

	@AndroidFindBy(accessibility = "Product info view add quantity buttons")
	@iOSXCUITFindBy(accessibility = "Product info view add quantity buttons")
	private MobileElement increaseButton;

	@AndroidFindBy(accessibility = "Product info view remove quantity buttons")
	@iOSXCUITFindBy(accessibility = "Product info view remove quantity buttons")
	private MobileElement decreaseButton;

	@AndroidFindBy(accessibility = "Custom outlined button Select Quantity")
	@iOSXCUITFindBy(accessibility = "Custom outlined button Select Quantity")
	private MobileElement selectQuantityButton;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Add to Cart']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Add to Cart']")
	private MobileElement addToCartButton;

	@AndroidFindBy(accessibility = "Product info view add quantity buttons")
	@iOSXCUITFindBy(accessibility = "Product info view add quantity buttons")
	private MobileElement plusButtonSelfCheckoutFullBox;

	@AndroidFindBy(accessibility = "Barcode scanner view continue to cart button")
	@iOSXCUITFindBy(accessibility = "Barcode scanner view continue to cart button")
	private MobileElement contToCart;

	@AndroidFindBy(accessibility = "Add all to Cart")
	@iOSXCUITFindBy(accessibility = "Add all to Cart")
	private MobileElement addAllToCart;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.app.Dialog/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.widget.Button[1]")
	private MobileElement acceptAllBtn;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[4]/android.view.View")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name='Checkout'])[1]")
	private MobileElement shoppingCart;

	public ScannerPage validateShoppingCart() {
		waitForVisibility(shoppingCart);
		Assert.assertTrue(shoppingCart.isDisplayed(), "Shopping Cart is not displayed");
		return this;
	}

	public ScannerPage clickOnAcceptAllBtn() {
		waitForVisibility(acceptAllBtn);
		click(acceptAllBtn);
		return this;
	}

	public ScannerPage clickOnAddAllToCart() {
		waitForVisibility(addAllToCart);
		click(addAllToCart);
		return this;
	}

	public ScannerPage clickOnContToCart() {
		waitForVisibility(contToCart);
		click(contToCart);
		return this;
	}

	public ScannerPage clickOnDeleteProduct() {
		waitForVisibility(deleteproduct);
		click(deleteproduct);
		return this;
	}

	public ScannerPage clickOnAddById() {
		waitForVisibility(addById);
		click(addById);
		return this;
	}

	public ScannerPage clickOnApproveDelete() {
		click(approveDelete);
		return this;
	}

	public ScannerPage clickOnScannerTab() {
		click(scanner);
		return this;
	}

	public ScannerPage clickOnChangeBranch() {
		executeImageInjection(td.getTestData(RunnerBase.country, "secondBranchCode"));
		waitForVisibility(changeBranch);
		click(changeBranch);
		return this;
	}

	public ScannerPage validateAddItemtoCart() {
		waitForVisibility(addItemtoCart);
		Assert.assertTrue(addItemtoCart.isDisplayed(), "Add Item to cart option is not displayed");
		return this;
	}

	public ScannerPage validateCheckoutOption() {
		waitForVisibility(startSelfChkout);
		Assert.assertTrue(startSelfChkout.isDisplayed(), "Start self checkout option is not displayed");
		return this;
	}

	public ScannerPage validateClosebtn() {
		waitForVisibility(closebtn);
		Assert.assertTrue(closebtn.isDisplayed(), "Start self checkout option is not displayed");
		return this;
	}

	public ScannerPage clickingOnClosebtn() {
		click(closebtn);
		return this;
	}

	public ScannerPage clickOnSelfCheckout() {
		click(selfCheckout);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;
	}

	public ScannerPage validateScanningIsDisplayed() {
		waitForVisibility(addById);
		Assert.assertTrue(addById.isDisplayed(), "Scanning or add by id screen is not displayed");
		return this;
	}

	public ScannerPage clickOnAddByID() {
		waitForVisibility(addById);
		click(addById);
		return this;
	}

	public ScannerPage validateAddByIdScreen() {
		waitForVisibility(addId);
		Assert.assertTrue(addId.isDisplayed(), "Add by id screen is not displayed");
		return this;
	}

	public ScannerPage enterProductId() throws InterruptedException {
		click(addId);
		sendKeys(addId, td.getTestData(RunnerBase.country, "regularProductId"));
		click(enterId);
		return this;
	}

	public ScannerPage userEntersInvalidProductId() {
		click(addId);
		sendKeys(addId, td.getTestData(RunnerBase.country, "validPassword"));
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		click(enterId);
		return this;
	}

	public ScannerPage enterFraudProductId() {
		click(addId);
		sendKeys(addId, "biz225004");
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		click(enterId);
		return this;
	}

	public ScannerPage validateContinueToCartDisplayed() throws InterruptedException {
		Thread.sleep(10000);
		waitForVisibility(contToCart);
		Assert.assertTrue(contToCart.isDisplayed(), "Continue to cart option is not displayed");
		return this;
	}

	public ScannerPage clickingOnContinueToCart() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		waitForVisibility(contToCart);
		click(contToCart);
		return this;
	}

	public ScannerPage clickingOnRegularCheckout() {
		executeImageInjection(td.getTestData(RunnerBase.country, "regularProductQrCode"));
		waitForVisibility(startRegularChkout);
		click(startRegularChkout);
		return this;
	}

	public ScannerPage clickingOnContinueToRegularCheckout() {
		click(enterId);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		waitForVisibility(addItemRegularCheckout);
		click(addItemRegularCheckout);
		return this;
	}

	public ScannerPage scanBlankCode() {
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		executeImageInjection(td.getTestData(RunnerBase.country, "blankImageId"));
		return this;
	}

	public ScannerPage scanProductQrCode() throws InterruptedException {
		executeImageInjection("042ece62c9037216ae4ffb5b7d1535b5fa6a6c39");
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Thread.sleep(10000);
		return this;
	}

	public ScannerPage scanFraudProductQrCode() throws InterruptedException {
		executeImageInjection("9f6dc709797bd58ecefc500d7956693b815a91fa");
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Thread.sleep(10000);
		return this;
	}

	public ScannerPage validateAddToCartOption() {
		try {
			Thread.sleep(7000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitForVisibility(addItemRegularCheckout);
		Assert.assertTrue(addItemRegularCheckout.isDisplayed(),
				"Add item to cart button is not displayed after scanning QR code in regular checkout");
		return this;
	}

	public ScannerPage clickOnAddToCartOption() {
		click(addItemRegularCheckout);
		return this;
	}

	public ScannerPage clickingOnScannerTab() {
		click(scanner);
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;
	}

	public ScannerPage clickOnAllowCamera() {
		try {
			waitForVisibility(allowCamera);
			click(allowCamera);
			System.out.println("iOS Driver is running....");
			return this;
		} catch (Exception e) {
			System.out.println("Android Driver is running....");
			return null;
		}
	}

	public ScannerPage clickingOnSelfCheckout() {
		click(selfCheckout);
		waitForVisibility(scanBranchCodeButton);
		return this;
	}

	public ScannerPage clickingOnBackButton() {
		navigateBack();
		waitForVisibility(selfCheckout);
		return this;
	}

	public ScannerPage clickOnTryAgainBtn() {
		waitForVisibility(tryAgainBtn);
		click(tryAgainBtn);
		return this;

	}

	public ScannerPage clickStartCheckout() {
		executeImageInjection(td.getTestData(RunnerBase.country, "blankImageId"));
		waitForVisibility(startSelfChkout);
		click(startSelfChkout);
		return this;

	}

	public ScannerPage clickOnProductDetailsCloseButton() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		executeImageInjection(td.getTestData(RunnerBase.country, "blankImageId"));
		click(productCloseButton);
		return this;
	}

	public ScannerPage validateProductDetailsClosure() {
		waitForVisibility(addById);
		Assert.assertTrue(addById.isDisplayed(), "Add by ID is not displayed");
		return this;
	}

	public ScannerPage scanInvalidProductCodeRegularCheckout() {
		executeImageInjection(td.getTestData(RunnerBase.country, "regularProductInvalidQrCode"));
		return this;
	}

	public ScannerPage swipeDownOnProductCard() {
		executeImageInjection(td.getTestData(RunnerBase.country, "blankImageId"));
		int[] x = getElementLocation(productCloseButton);

		try {
			swipe(x[0], x[1], x[0], x[1] + 900, 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public ScannerPage validateProductCardClosure() {
		waitForVisibility(addById);
		Assert.assertTrue(addById.isDisplayed(), "Product card is not closed");
		return this;
	}

	public ScannerPage clickOnRegularCheckoutForAddingProductId() {
		click(startRegularChkout);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return this;
	}

	public ScannerPage validateAddToCartEnablement() {
		Assert.assertFalse(addToCartButton.isEnabled(), "Add to cart button is enabled for self checkout full box");
		return this;
	}

	public ScannerPage clickingOnPlusSignInFullBoxProduct() {
		click(plusButtonSelfCheckoutFullBox);
		return this;
	}

	public ScannerPage validateAddToCartEnablementAfterAddingQuantity() {
		Assert.assertTrue(addToCartButton.isEnabled(), "Add to cart button is not enabled for self checkout full box");
		return this;
	}

	public ScannerPage validateProductQRScan() {
		waitForVisibility(addToSelfCheckout);
		Assert.assertTrue(addToSelfCheckout.isDisplayed(), "Add to Self checkout option is not displayed");
		return this;
	}

	public ScannerPage scanValidProductCode() {
		executeImageInjection("042ece62c9037216ae4ffb5b7d1535b5fa6a6c39");
		click(startSelfChkout);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public ScannerPage validateInvalidProductCode() {
		waitForVisibility(invalidProductPopUp);
		Assert.assertTrue(invalidProductPopUp.isDisplayed(), "Invalid product code pop up is not displayed");
		return this;
	}

	public ScannerPage scanInvalidProductCode() {
		executeImageInjection(td.getTestData(RunnerBase.country, "regularProductInvalidQrCode"));
		click(startSelfChkout);
		return this;
	}

	public ScannerPage validateInvalidProductScan() {
		waitForVisibility(tryAgainButton);
		Assert.assertTrue(tryAgainButton.isDisplayed(), "Invalid product code pop up is not displayed");
		return this;
	}

	public ScannerPage clickingOnRegularCheckoutInScannerTab() {
		waitForVisibility(startRegularChkout);
		click(startRegularChkout);
		return this;
	}

	public ScannerPage enterZeroAsQuantity() {
		waitForVisibility(quantity);
		click(quantity);
		clear(quantity);
		sendKeys(quantity, td.getTestData(RunnerBase.country, "quantity0"));
		click(decreaseButton);
		return this;
	}

	public ScannerPage validateZeroQuantity() {
		String text = quantity.getText();
		Assert.assertTrue(text.contains(td.getTestData(RunnerBase.country, "validateQuantity")),
				"Quantity didn't match during validating zero quantity");
		return this;
	}

	public ScannerPage enterProductIdWithMultipleQuantity() throws InterruptedException {
		click(addId);
		sendKeys(addId, td.getTestData(RunnerBase.country, "multipleProductId"));
		click(enterId);
		return this;
	}
	
	public ScannerPage enterfiftyAsQuantity() {
		waitForVisibility(quantity);
		click(quantity);
		clear(quantity);
		sendKeys(quantity, td.getTestData(RunnerBase.country, "quantity150"));
		click(decreaseButton);
		return this;
	}
	
	public ScannerPage validateScanBranchCode() {
		Assert.assertTrue(scanBranchCodeButton.isDisplayed(), "Scan Branch Code is not displayed");
		return this;
	}
	
//	public ScannerPage clickCartIcon() {
//		waitForVisibility(cookiesAccept);
//		click(cookiesAccept);
//		closeNoti();
//		waitForVisibility(cartIcon);
//		click(cartIcon);	
//		return this;
//	}
	
	public ScannerPage clickingOnScanBranchCode() {
		try {
			executeImageInjection(td.getTestData(RunnerBase.country, "branchCode"));
			Thread.sleep(5000);
			click(scanBranchCodeButton);
			Thread.sleep(5000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return this;
	}
	
	public ScannerPage startCheckout() {
		try {
			Thread.sleep(5000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		executeImageInjection(td.getTestData(RunnerBase.country, "blankImageId"));
		waitForVisibility(startSelfChkout);
		Assert.assertTrue(startSelfChkout.isDisplayed(), "Start self checkout option is not displayed");
		return this;
	}
	
	public ScannerPage clickingOnContinueToSelfCheckout() {
		try {
			Thread.sleep(5000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		waitForVisibility(addToSelfCheckout);
		click(addToSelfCheckout);
		return this;
	}
	
	public ScannerPage clickingOnStartSelfCheckoutButtonToScanProductCode() {
		try {
			executeImageInjection(td.getTestData(RunnerBase.country, "regularProductQrCode"));
			click(startSelfChkout);
			Thread.sleep(5000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return this;
	}
	
	public ScannerPage validateAddToSelfCheckoutOption() {
		waitForVisibility(addToSelfCheckout);
		Assert.assertTrue(addToSelfCheckout.isDisplayed(), "Add to self checkout button is not displayed after scanning QR code in self checkout");
		return this;
	}
	
	public ScannerPage scanFullBoxBranchCode() {
		try {
			executeImageInjection(td.getTestData(RunnerBase.country, "fullBoxBranchCode"));
			Thread.sleep(5000);
			click(scanBranchCodeButton);
			Thread.sleep(5000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return this;
	}
	
	public ScannerPage scanFullBoxProductQrCode() {
		try {
			executeImageInjection(td.getTestData(RunnerBase.country, "fullBoxProductQrCode"));
			click(startSelfChkout);
			Thread.sleep(5000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return this;
	}
	
	public ScannerPage validateSelectQuantityButton() {
		waitForVisibility(selectQuantityButton);
		Assert.assertTrue(selectQuantityButton.isDisplayed(), "Select Quantity button is not displayed");
		return this;
	}
	
	public ScannerPage clickingOnSelectQuantityButton() {
		click(selectQuantityButton);
		return this;
	}
	
	public ScannerPage enterFullBoxProductId() {
		click(addId);
		sendKeys(addId, td.getTestData(RunnerBase.country, "fullBoxProductId"));
		try {
			Thread.sleep(2000);
		} catch(Exception e) {
			e.printStackTrace();
		}
		click(enterId);
		return this;
	}
	
	public ScannerPage validateScannerPageDisplayed() {
		if(RunnerBase.platform.equalsIgnoreCase("iOS")) {
			try {
				Thread.sleep(4000);
				MobileElement allow = (MobileElement) driver.findElementByAccessibilityId("Allow Once");
				waitForVisibility(allow);
				click(allow);
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		}
		if(RunnerBase.country.equalsIgnoreCase("France")) {
			waitForVisibility(selfCheckout);
			Assert.assertTrue(selfCheckout.isDisplayed(), "Scanner Page is not displayed");
		}else {
			waitForVisibility(startRegularChkout);
			Assert.assertTrue(startRegularChkout.isDisplayed(), "Scanner Page is not displayed");
		}
		
		return this;
	}
	
	public ScannerPage enterProductIdWithSpecialCharacters() {
		click(addId);
		sendKeys(addId, td.getTestData(RunnerBase.country, "specialCharacterProductId"));
		click(enterId);
		return this;
	}
	
}
