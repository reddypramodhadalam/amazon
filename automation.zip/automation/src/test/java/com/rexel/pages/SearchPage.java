package com.rexel.pages;

import java.awt.Dimension;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.rexel.runners.RunnerBase;
import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.TestUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import okhttp3.internal.platform.Platform;

public class SearchPage extends BasePage {
	TestUtils utils = new TestUtils();
	GlobalParams params = new GlobalParams();
	TestData td = new TestData();

	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'search')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'search')]")
	private MobileElement searchTab;
	
	@AndroidFindBy(xpath="(//android.view.View[@content-desc='Most Ordered Category with products in it'])[1]")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Most Ordered Category with products in it'])[1]")
	private MobileElement mostOrderedProducts;
	
	@AndroidFindBy(accessibility = "View the entire category")
	@iOSXCUITFindBy(accessibility = "View the entire category")
	private MobileElement viewEntireCategory;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@index='0']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@name,'Search Rexel')]")
	private MobileElement searchBar;
	
	@AndroidFindBy(xpath="//android.widget.Button[contains(@content-desc, 'Product image in catalog product card')]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[contains(@name,'Product image in catalog product card')]")
	private MobileElement searchResults;
	
	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'Product image in catalog product card')]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[contains(@name,'Product image in catalog product card')]")
	private MobileElement searchResultsWithoutLogin;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Buy again')]")
	@iOSXCUITFindBy(accessibility = "Already bought")
	private MobileElement alreadyBought;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Bulk savings')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Bulk savings')]")
	private MobileElement bulkSavingsLink;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'1 - 0')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, '1 - 0')]")
	private MobileElement quantity0;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'1 - 99')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, '1 - 99')]")
	private MobileElement quantity1;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'100 - 999')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, '100 - 999')]")
	private MobileElement quantity2;
	
	@AndroidFindBy(accessibility = "Add to Cart")
	@iOSXCUITFindBy(accessibility = "Add to Cart")
	private MobileElement addToCart;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@index='0']")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton)[1]")
	private MobileElement closeButton;
	
	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'Product type:')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Product type:')]")
	private MobileElement productType;
	
	
	public SearchPage() {
		
	}
	
	public SearchPage navigateToSearchTab() {
		waitForVisibility(searchTab);
		click(searchTab);
		return this;
	}
	
	public SearchPage validateMostOrderedCategories() {
		waitForVisibility(alreadyBought);
		Assert.assertTrue(alreadyBought.isDisplayed(), "Buy again tab is not displayed");
		return this;
	}
	
	public SearchPage scrollToViewEntireCategory() {
		try {
			MobileElement element= scrollToElement(viewEntireCategory, "up");
			waitForVisibility(element);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public SearchPage validateViewEntireCategory() {
		Assert.assertTrue(viewEntireCategory.isDisplayed(), "View Entire category is not displayed");
		return this;
	}
	
	public SearchPage enterProductNameToSearch() {
		click(searchBar);
		sendKeys(searchBar, td.getTestData(RunnerBase.country, "searchTerm"));
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
			try {
				Thread.sleep(3000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return this;
	}
	
	public SearchPage validateSearchResults() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		waitForVisibility(searchResults);
		Assert.assertTrue(searchResults.isDisplayed(), "Search Results are not displayed");
		return this;
	}
	
	public SearchPage validateMostOrderedCategoriesNotDisplayed() {
		List<?> element = driver.findElements(By.xpath("//android.view.View[contains(@content-desc,'Buy again')]"));
		Assert.assertTrue(element.size() == 0, "Buy Again Tab is displayed");
		return this;
	}
	
	public SearchPage validateSearchResultsWithoutLogin() {
		waitForVisibility(searchResultsWithoutLogin);
		Assert.assertTrue(searchResultsWithoutLogin.isDisplayed(), "Search Results are not displayed without login");
		return this;
	}
	
	public SearchPage enterBulkSavingsProductNameToSearch() {
		click(searchBar);
		sendKeys(searchBar, td.getTestData(RunnerBase.country, "searchTermBulkSavings"));
		if(RunnerBase.platform.equals("Android")) {
			driver.hideKeyboard();
			try {
				Thread.sleep(3000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return this;
	}
	
	public SearchPage validateBulkSavingProductSearchResults() {
		waitForVisibility(bulkSavingsLink);
		Assert.assertTrue(bulkSavingsLink.isDisplayed(), "Bulk Savings Search Results are not displayed");
		return this;
	}
	
	public SearchPage clickOnBulkSavings() {
		click(bulkSavingsLink);
		return this;
	}
	
	public SearchPage validateTieredPricingInPlpPage() {
		Assert.assertTrue(quantity0.isDisplayed(), "Tier 1 of 3 pricing is not displayed");
		Assert.assertTrue(quantity1.isDisplayed(), "Tier 2 of 3 pricing is not displayed");
		Assert.assertTrue(quantity2.isDisplayed(), "Tier 3 of 3 pricing is not displayed");
		Assert.assertTrue(addToCart.isDisplayed(), "Add to cart button is not displayed");
		return this;
	}
	
	public SearchPage clickingOnCloseButton() {
		click(closeButton);
		waitForVisibility(bulkSavingsLink);
		return this;
	}
	
	public SearchPage clickingOnFirstProductInSearchResults() {
		try {
			Thread.sleep(10000);
			if(RunnerBase.platform.equalsIgnoreCase("Android")) {
				pressByCoordinates(563, 572);
			}
			else {
				pressByCoordinates(176, 263);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitForVisibility(quantity0);
		return this;
	}
	
	public SearchPage validatePdpResults() {
		Assert.assertTrue(quantity0.isDisplayed(), "Tier 1 of 3 pricing is not displayed");
		int[] x = getElementLocation(quantity0);
		try {
			swipe(x[0], x[1], x[0], x[1]-600, 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertTrue(quantity1.isDisplayed(), "Tier 2 of 3 pricing is not displayed");
		Assert.assertTrue(quantity2.isDisplayed(), "Tier 3 of 3 pricing is not displayed");
		Assert.assertTrue(addToCart.isDisplayed(), "Add to cart button is not displayed");
		return this;
	}
	
	public SearchPage clickingOnFirstProduct() {
		try {
			Thread.sleep(10000);
			if(RunnerBase.platform.equalsIgnoreCase("Android")) {
				pressByCoordinates(563, 572);
			}
			else {
				pressByCoordinates(176, 263);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public SearchPage validateProductTypeInPdp() {
		Assert.assertTrue(productType.isDisplayed(), "Product Type is not displayed in PDP");
		String text;
		if(RunnerBase.platform.equalsIgnoreCase("iOS")) {
			text = getAttribute(productType, "name");
		}
		else {
			text = getAttribute(productType, "content-desc");
		}
		String pattern = "Product type:\\s+(.*)";  
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(text);
        Assert.assertTrue(m.find(), "Product type name is not displayed in PDP after Text Product Type");
		return this;
	}
}