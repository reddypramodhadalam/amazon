package com.rexel.pages;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.aspectj.asm.IProgramElement.Accessibility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.rexel.runners.RunnerBase;
import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.PropertyManager;
import com.rexel.utils.TestUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.HasSupportedPerformanceDataType;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class LoginPage extends BasePage { 
	TestUtils utils = new TestUtils();
	GlobalParams params = new GlobalParams();
	TestData td = new TestData();
	

	@AndroidFindBy(accessibility = "Tutorial close button")
	@iOSXCUITFindBy(accessibility = "Tutorial close button")
	private MobileElement closeButton;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='4']")
    @iOSXCUITFindBy(accessibility = "Login view username field")
    private MobileElement username;

	@AndroidFindBy(xpath = "//android.widget.EditText[@index='7']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name='Login view password field']")
    private MobileElement password;

	@AndroidFindBy(accessibility = "Sign in")
	@iOSXCUITFindBy(accessibility = "Sign in")
	private MobileElement signInButton;

	@AndroidFindBy(accessibility = "Start Shopping")
	private MobileElement startShopping;

	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Ok']")
	@iOSXCUITFindBy(accessibility = "Ok")
	private MobileElement okDisable;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Tutorial')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Tutorial')]")
	private MobileElement tutorial;

	@AndroidFindBy(accessibility = "Login view close icon button")
	@iOSXCUITFindBy(accessibility = "Login view close icon button")
	private MobileElement loginCloseButton;

	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'scanner')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'scanner')]")
	private MobileElement scanner;

	@iOSXCUITFindBy(accessibility = "Allow Once")
	private MobileElement allowPermission;

	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'webshop')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name, 'webshop')]")
	private MobileElement homeTab;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'settings')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'settings')]")
	private MobileElement settingsTab;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Forgot username')]")
	@iOSXCUITFindBy(accessibility = "Forgot username")
	private MobileElement forgotUsername;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Forgot password')]")
	@iOSXCUITFindBy(accessibility = "Forgot password")
	private MobileElement forgotPassword;

	@AndroidFindBy(accessibility = "Register now")
	@iOSXCUITFindBy(accessibility = "Register now")
	private MobileElement registerButton;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Allow Once']")
	private MobileElement allowLocation;
	
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View[1]/android.view.View")
	private MobileElement hamburgerMenu;
	
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.app.Dialog/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.widget.Button[1]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[@name='Tout accepter']")
	private MobileElement cookiesAccept;
	
	@AndroidFindBy(xpath = "//*[@resource-id='existingRegistrationId']")
	@iOSXCUITFindBy(accessibility = "Yes" )
	private MobileElement registerScreen;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[6]/android.view.View[1]/android.widget.TabWidget/android.view.View[1]/android.view.View/android.widget.Button")
	private MobileElement registerScreenCookiesAccept;
	
	@AndroidFindBy(accessibility = "Remember username")
	@iOSXCUITFindBy(accessibility = "Remember username")
	private MobileElement rememberUsername;
	
	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'customerServiceTools')]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeStaticText[contains(@name, 'customerServiceTools')]")
	private MobileElement calculatorTab;
	
	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'search')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'search')]")
	private MobileElement searchTab;
	
	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc,'cart')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'cart')]")
	private MobileElement cartTab;
	
	@AndroidFindBy(accessibility = "Incorrect username or password. Please try again.")
	private MobileElement invalidCredentials;
	
	public LoginPage() {
	}

	public LoginPage clickOnAllowLocation() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(isallowLocationbtnvisible())
		{
		 click(allowLocation);
		 }
		 return this;		
	}
	
	public boolean isallowLocationbtnvisible() {
		try {
			return allowLocation.isDisplayed();
			
		}
		catch (Exception e){
			return false;
		}
	}
	
	public LoginPage clickOnCloseButton() {
		try {
			Thread.sleep(25000);
			waitForVisibility(closeButton);
			click(closeButton, "clicking on close button");
			Thread.sleep(3000);
			Assert.assertTrue(signInButton.isDisplayed(), "Login page is not displayed");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public LoginPage enterUserName() {
		waitForVisibility(username);
		click(username);
		clear(username);
		sendKeys(username, td.getTestData(RunnerBase.country,"validUserName"), "login with " + td.getTestData(RunnerBase.country,"validUserName"));
		return this;
	}

	public LoginPage enterPassword() {
		if(RunnerBase.platform.equalsIgnoreCase("iOS")) {
			try {
				Thread.sleep(3000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		click(password);
		clear(password);
//		List<MobileElement> els1 = (List<MobileElement>) driver.findElementsByAccessibilityId("Login view password field");
//		for(MobileElement e : els1) {
//			e.sendKeys("32748327");
//			break;
//		}
		sendKeys(password, td.getTestData(RunnerBase.country,"validPassword"), "password is " + td.getTestData(RunnerBase.country,"validPassword"));
		return this;
	}

	public LoginPage clickOnSignInButton() {
		waitForVisibility(signInButton);
		click(signInButton);
		return this;
	}

	public LoginPage validateStartShoppingButton() {
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitForVisibility(scanner);
		// waitForVisibility(homeScreenIcon);
		Assert.assertTrue(scanner.isDisplayed(), "Scanner button is not displayed after login");
		return this;
	}

	public LoginPage enterInvalidCredentials() {
		waitForVisibility(username);
		click(username);
		clear(username);
		sendKeys(username, td.getTestData(RunnerBase.country,"invalidUserName"), "login with " + td.getTestData(RunnerBase.country,"invalidUserName"));
		click(password);
		clear(password);
		sendKeys(password, td.getTestData(RunnerBase.country,"validPassword"), "password is " + td.getTestData(RunnerBase.country,"validPassword"));
		return this;
	}

	public LoginPage validateInvalidCredentialsPopUp() {
		if(RunnerBase.country.equalsIgnoreCase("Sweden")) {
			waitForVisibility(invalidCredentials);
			Assert.assertTrue(invalidCredentials.isDisplayed(), "Invalid Credentials Message is not displayed");
		} else {
			waitForVisibility(okDisable);
			Assert.assertTrue(okDisable.isDisplayed(), "Invalid Credentials PopUp is not displayed");
		}
		return this;
	}

	public LoginPage enterDisabledUserCredentials() {
		waitForVisibility(username);
		click(username);
		clear(username);
		sendKeys(username, td.getTestData(RunnerBase.country,"disabledUserName"), "login with " + td.getTestData(RunnerBase.country,"disabledUserName"));
		click(password);
		clear(password);
		sendKeys(password, td.getTestData(RunnerBase.country,"validPassword"), "password is " + td.getTestData(RunnerBase.country,"validPassword"));
		return this;
	}

	public LoginPage validateDisabledUserPopUp() {
		waitForVisibility(okDisable);
		Assert.assertTrue(okDisable.isDisplayed(), "Disabled User PopUp is not displayed");
		return this;
	}

	public LoginPage closeLoginScreen() {
		waitForVisibility(loginCloseButton);
		click(loginCloseButton);		
		return this;
	}

	public LoginPage validateLoginScreen() {
		Assert.assertTrue(username.isDisplayed(), "Login Screen is not displayed");
		return this;
	}

	public LoginPage clickOnStartShopping() {
		waitForVisibility(startShopping);
		click(startShopping);
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public LoginPage clickOnTutorialButton() {
		try {
			swipe(430, 1170, 430, 570, 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitForVisibility(tutorial);
		click(tutorial);
		return this;
	}

	public LoginPage validateTutorialScreenDisplayed() {
		waitForVisibility(closeButton);
		Assert.assertTrue(closeButton.isDisplayed(), "Tutorial screen is not displayed");
		return this;
	}

	public LoginPage clickOnCloseButtonInTutorialScreen() {
		waitForVisibility(closeButton);
		click(closeButton);
		return this;
	}

	public LoginPage validateHomePage() {
		if(RunnerBase.platform.equalsIgnoreCase("iOS")) {
			if(isallowLocationbtnvisible()) {
				waitForVisibility(allowLocation);
				click(allowLocation);
			}
			
		}
		waitForVisibility(scanner);
		Assert.assertTrue(scanner.isDisplayed(), "Home Page is not displayed after login");
		return this;
	}
	
	public LoginPage clickOnScanTab() {
		click(scanner);
		return this;
	}

	public LoginPage validateTabsAfterLaunching() {
		Assert.assertTrue(homeTab.isDisplayed(), "Home tab is not displayed in login page");
		Assert.assertTrue(scanner.isDisplayed(), "Scanner tab is not displayed in login page");
		Assert.assertTrue(settingsTab.isDisplayed(), "Settings tab is not displayed in login page");
		return this;
	}

	public LoginPage validateLoginPage() {
		Assert.assertTrue(forgotUsername.isDisplayed(), "Forgot Username Link is not displayed in login screen");
		Assert.assertTrue(forgotPassword.isDisplayed(), "Forgot Password Link is not displayed in login screen");
		Assert.assertTrue(signInButton.isDisplayed(), "Sign in button is not displayed in login screen");
		Assert.assertTrue(registerButton.isDisplayed(), "Register button is not displayed in login screen");
		Assert.assertTrue(rememberUsername.isDisplayed(), "Remember Username is not displayed in login screen");
		return this;
	}

	public LoginPage enterBlockedCredentials() {
		waitForVisibility(username);
		click(username);
		clear(username);
		sendKeys(username, td.getTestData(RunnerBase.country,"blockedUserName"), "login with " + td.getTestData(RunnerBase.country,"blockedUserName"));
		click(password);
		clear(password);
		sendKeys(password, td.getTestData(RunnerBase.country,"validPassword"), "password is " + td.getTestData(RunnerBase.country,"validPassword"));
		return this;
	}
	
	public LoginPage clickOnRegisterBtn() {
		waitForVisibility(registerButton);
		click(registerButton);
		return this;
	}
	
	public LoginPage validateRegisterScreen() {
		try {
			Thread.sleep(3000);
			switchContext();
			switchContextToNative();
			Thread.sleep(3000);
			String cookiesData = td.getTestData(RunnerBase.country, "cookiesString");
			//MobileElement element = (MobileElement) driver.findElement(By.xpath("//*[@resource-id='"+cookiesData+"']"));
			//element.click();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitForVisibility(registerScreen);
		Assert.assertTrue(registerScreen.isDisplayed(), "Register Screen is not displayed on clicking register button");
		return this;
	}
	
	public LoginPage validateFourTabsAfterLaunching() {
		Assert.assertTrue(homeTab.isDisplayed(), "Home tab is not displayed in login page");
		Assert.assertTrue(scanner.isDisplayed(), "Scanner tab is not displayed in login page");
		Assert.assertTrue(calculatorTab.isDisplayed(), "Calculator tab is not displayed in login page");
		Assert.assertTrue(settingsTab.isDisplayed(), "Settings tab is not displayed in login page");
		return this;
	}
	
	public LoginPage validateFiveTabsAfterLaunching() {
		Assert.assertTrue(homeTab.isDisplayed(), "Home tab is not displayed in login page");
		Assert.assertTrue(scanner.isDisplayed(), "Scanner tab is not displayed in login page");
		Assert.assertTrue(searchTab.isDisplayed(), "Search tab is not displayed in login page");
		Assert.assertTrue(settingsTab.isDisplayed(), "Settings tab is not displayed in login page");
		Assert.assertTrue(cartTab.isDisplayed(), "Cart tab is not displayed in login page");
		return this;
	}
	
	public LoginPage getCpuUsageForAndroid() throws NumberFormatException, IOException {
		String name = td.getTestData(RunnerBase.country, "packageName");
		List<List<Object>> performanceData = ((HasSupportedPerformanceDataType) driver)
				.getPerformanceData(name, "cpuinfo", 1000);

		HashMap<String, Integer> readableData = new HashMap<String, Integer>();
		for (int i = 0; i < performanceData.get(0).size(); i++) {
			int val;
			if (performanceData.get(1).get(i) == null) {
				val = 0;
			} else {
				val = Integer.parseInt((String) performanceData.get(1).get(i));
			}
			readableData.put((String) performanceData.get(0).get(i), val);
			ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,
					"CPU usage of application is :" + String.valueOf(val));
		}
		return this;
	}
	
	public LoginPage validateCpuUsageIos() {
		String filePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test"
				+ File.separator + "resources" + File.separator + "SwiftCodeCPUUsage";
		String[] cmd = {filePath,"./SwiftCodeCPUUsage"};
		byte[] bo = new byte[100];
		Process p;
		try {
			p = Runtime.getRuntime().exec(cmd);
			double cpuUsage = p.getInputStream().read(bo);
			System.out.println("cpu usage.... " + cpuUsage);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public LoginPage getGpuUsageAndroid() {
		String name = td.getTestData(RunnerBase.country, "packageName");
		String data = getGpuAndroid(name);
		String matchedData = "Total GPU memory usage:";
		int start = data.indexOf(matchedData);
		if (start != -1) {
			int end = data.indexOf('\n', start);
			if (end != -1) {
				String gpuUsage = data.substring(start, start + 50).trim();
				System.out.println("Second line: " + gpuUsage);
				ExtentCucumberAdapter.getCurrentStep().log(Status.INFO, "GPU usage of application is :" + gpuUsage);
			}
		}
		return this;
	}
	
	public LoginPage updateNetworkCondition() {
		String id = driver.getSessionId().toString();
		int code = ChangeNetwork.updateNetwork(id, "2g-gprs-good");
		Assert.assertTrue(code == 200, "Network profile update failed");
		return this;
	}
	
	public LoginPage validateLoginPageDisplayed() {
		Assert.assertTrue(signInButton.isDisplayed(), "Login page is not displayed");
		return this;
	}
	
	public LoginPage getBatteryUsageForAndroid() throws NumberFormatException, IOException {
		String packageName = td.getTestData(RunnerBase.country, "packageName");
		List<List<Object>> performanceData = ((HasSupportedPerformanceDataType) driver)
				.getPerformanceData(packageName, "batteryinfo", 1000);

		HashMap<String, Integer> readableData = new HashMap<String, Integer>();
		for (int i = 0; i < performanceData.get(0).size(); i++) {
			int val;
			if (performanceData.get(1).get(i) == null) {
				val = 0;
			} else {
				val = Integer.parseInt((String) performanceData.get(1).get(i));
			}
			readableData.put((String) performanceData.get(0).get(i), val);
			ExtentCucumberAdapter.getCurrentStep().log(Status.INFO,
					"Battery usage of application is :" + String.valueOf(val));
		}
		return this;
	}
	
	public LoginPage getBatteryStatusIosApp() {
		getBatteryUsagIosApp();
		return this;
	}
	
	public LoginPage getMemoryInfoForAndroid() {
		String name = td.getTestData(RunnerBase.country, "packageName");
		String data = getMemoryInfoAndroid(name);
		System.out.println(data);
		return this;
	}
	
	public LoginPage loginWithUxTradeUser() {
		waitForVisibility(username);
		click(username);
		clear(username);
		sendKeys(username, td.getTestData(RunnerBase.country,"tradeUser"), "login with " + td.getTestData(RunnerBase.country,"tradeUser"));
		return this;	
	}

}