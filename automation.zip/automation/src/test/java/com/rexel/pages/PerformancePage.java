package com.rexel.pages;

import org.testng.Assert;
import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;

import com.rexel.runners.RunnerBase;
import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.TestUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class PerformancePage extends BasePage {
	TestUtils utils = new TestUtils();
	GlobalParams params = new GlobalParams();
	StopWatch pageLoad = new StopWatch();
	public static long loginTime;
	public static long navigationTimeScannerScreen;
	public static long navigationTimeSettingsScreen;
	public static long logoutTime;
	public static long navigationTimeLoginScreen;
	public static long searchResultsTime;
	public static long loginErrorTime;
	TestData td = new TestData();
	
	
	@AndroidFindBy(accessibility = "Sign in")
	@iOSXCUITFindBy(accessibility = "Sign in")
	private MobileElement signInButton;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'scanner')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'scanner')]")
	private MobileElement scanner;
	
	@AndroidFindBy(accessibility = "Scanner widget regular checkout card and text")
	@iOSXCUITFindBy(accessibility = "Scanner widget regular checkout card and text")
	private MobileElement startRegularChkout;
	
	@AndroidFindBy(accessibility = "Scanner widget self checkout card and text")
	@iOSXCUITFindBy(accessibility = "Scanner widget self checkout card and text")
	private MobileElement startSelfChkout;
	
	@AndroidFindBy(xpath= "(//android.view.View[contains(@content-desc,'settings')])[2]")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@name, 'settings')])[2]")
	private MobileElement settings;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Scan Beeping')]")
	@iOSXCUITFindBy(accessibility = "Scan Beeping")
	private MobileElement scanbeep;
	
	@AndroidFindBy(xpath="//android.widget.Button[contains(@content-desc,'Sign out')]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeButton[contains(@name, 'Sign out')]")
	private MobileElement logoutBtn;
	
	@AndroidFindBy(accessibility = "Tutorial close button")
	@iOSXCUITFindBy(accessibility = "Tutorial close button")
	private MobileElement closeButton;
	
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Allow Once']")
	private MobileElement allowLocation;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@index='0']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[contains(@name,'Search Rexel')]")
	private MobileElement searchBar;
	
	@AndroidFindBy(xpath="//android.widget.Button[@index='1']")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[contains(@name,'Product image in catalog product card')]")
	private MobileElement searchResults;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Ok']")
	@iOSXCUITFindBy(accessibility = "Ok")
	private MobileElement okDisable;
	
	@AndroidFindBy(xpath= "//android.view.View[contains(@content-desc,'settings')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'settings')]")
	private MobileElement settingsWithoutNativeScreen;
	
	@AndroidFindBy(xpath = "(//android.view.View[contains(@content-desc,'account')])[2]")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@name, 'account')])[2]")
	private MobileElement accountTab;
	
	@AndroidFindBy(accessibility = "ACCOUNT")
	@iOSXCUITFindBy(accessibility = "ACCOUNT")
	private MobileElement accountSection;
	
	public PerformancePage() {
	}
	
	public PerformancePage clickOnSignInButton() {
		waitForVisibility(signInButton);
		click(signInButton);
		pageLoad.reset();
		pageLoad.start();
//		if (isallowLocationbtnvisible()) {
//			click(allowLocation);
//		}
		if(RunnerBase.platform.equalsIgnoreCase("iOS")) {
			allowLocation.click();
		}
		waitForVisibility(scanner);
		Assert.assertTrue(scanner.isDisplayed(), "Home Page is not displayed after login");
		pageLoad.stop();
		loginTime = pageLoad.getTime();
		return this;
	}
	
	public PerformancePage validateTimeTakenForLogin() {
		int denominator = 1000;
		double timeTaken = (double)loginTime/denominator;
		System.out.println(timeTaken);
		int expectedTime = Integer.parseInt(td.getTestData(RunnerBase.country, "loginTime"));
		if (timeTaken <= expectedTime) {
            System.out.println("User Logged in within "+expectedTime+" seconds");
        } else {
            throw new AssertionError("Expected to login in " + expectedTime + " seconds but took " + timeTaken + " seconds to login");
        }
		return this;
	}
	
	public PerformancePage clickingOnScannerTabForPerformance() {
		waitForVisibility(scanner);
		click(scanner);
		pageLoad.reset();
		pageLoad.start();
		if(RunnerBase.country.equalsIgnoreCase("France")) {
			waitForVisibility(startSelfChkout);
			Assert.assertTrue(startSelfChkout.isDisplayed(), "Self Checkout is not displayed after navigating to scanner screen");
		} else {
			waitForVisibility(startRegularChkout);
			Assert.assertTrue(startRegularChkout.isDisplayed(), "Regular Checkout is not displayed after navigating to scanner screen");
		}
		pageLoad.stop();
		navigationTimeScannerScreen = pageLoad.getTime();
		return this;
	}
	
	public PerformancePage validateTimeTakenForNavigatingToScannerScreen() {
		int denominator = 1000;
		double timeTaken = (double)navigationTimeScannerScreen/denominator;
		int expectedTime = Integer.parseInt(td.getTestData(RunnerBase.country, "navigationToScannerScreen"));
		if (timeTaken <= expectedTime) {
            System.out.println("User navigated within "+expectedTime+" seconds");
        } else {
            throw new AssertionError("Expected to navigate in " + expectedTime + " seconds but navigated in " + timeTaken + " seconds");
        }
		return this;
	}
		
	public PerformancePage clickingOnSettingsTabForPerformance() {
		if(RunnerBase.country.equalsIgnoreCase("France")) {
			waitForVisibility(accountTab);
			click(accountTab);
			pageLoad.reset();
			pageLoad.start();
			waitForVisibility(accountSection);
			Assert.assertTrue(accountSection.isDisplayed(), "Account tab is not displayed after clicking on settings tab");
			pageLoad.stop();
			navigationTimeSettingsScreen = pageLoad.getTime();
		}
		else if(RunnerBase.country.equalsIgnoreCase("Sweden") || RunnerBase.country.equalsIgnoreCase("Regro") || RunnerBase.country.equalsIgnoreCase("Schaeke")) {
			waitForVisibility(settings);
			click(settings);
			pageLoad.reset();
			pageLoad.start();
			waitForVisibility(scanbeep);
			Assert.assertTrue(scanbeep.isDisplayed(), "Settings tab is not displayed after clicking on settings tab");
			pageLoad.stop();
			navigationTimeSettingsScreen = pageLoad.getTime();
		} else {
			waitForVisibility(settingsWithoutNativeScreen);
			click(settingsWithoutNativeScreen);
			pageLoad.reset();
			pageLoad.start();
			waitForVisibility(scanbeep);
			Assert.assertTrue(scanbeep.isDisplayed(), "Settings tab is not displayed after clicking on settings tab");
			pageLoad.stop();
			navigationTimeSettingsScreen = pageLoad.getTime();
		}	
		
		return this;
	}
	
	public PerformancePage validateTimeTakenForNavigatingToSettingsScreen() {
		int denominator = 1000;
		double timeTaken = (double)navigationTimeSettingsScreen/denominator;
		int expectedTime = Integer.parseInt(td.getTestData(RunnerBase.country, "navigationToSettingsScreen"));
		if (timeTaken <= expectedTime) {
            System.out.println("User navigated within "+expectedTime+" seconds");
        } else {
            throw new AssertionError("Expected to navigate in " + expectedTime + " seconds but navigated in " + timeTaken + " seconds");
        }
		return this;
	}
	
	public PerformancePage clickingOnLogoutButton() {
		if(RunnerBase.country.equalsIgnoreCase("France")) {
			waitForVisibility(accountTab);
			click(accountTab);
			waitForVisibility(accountSection);
			Assert.assertTrue(accountSection.isDisplayed(), "Account tab is not displayed after clicking on settings tab");
			pageLoad.stop();
			navigationTimeSettingsScreen = pageLoad.getTime();
		}
		else if(RunnerBase.country.equalsIgnoreCase("Sweden") || RunnerBase.country.equalsIgnoreCase("Regro") || RunnerBase.country.equalsIgnoreCase("Schaeke")) {
			waitForVisibility(settings);
			click(settings);
			waitForVisibility(scanbeep);
		} else {
			waitForVisibility(settingsWithoutNativeScreen);
			click(settingsWithoutNativeScreen);
			waitForVisibility(scanbeep);
		}
		try {
			MobileElement element = scrollToElement(logoutBtn, "up");
			waitForVisibility(element);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitForVisibility(logoutBtn);
		click(logoutBtn);
		pageLoad.reset();
		pageLoad.start();
		waitForVisibility(signInButton);
		Assert.assertTrue(signInButton.isDisplayed(), "Login Screen is not displayed after clicking on Log out button");
		pageLoad.stop();
		logoutTime = pageLoad.getTime();
		return this;
	}
	
	public PerformancePage validateTimeTakenForLogout() {
		int denominator = 1000;
		double timeTaken = (double)logoutTime/denominator;
		int expectedTime = Integer.parseInt(td.getTestData(RunnerBase.country, "logoutTime"));
		if (timeTaken <= expectedTime) {
            System.out.println("User logged out within "+expectedTime+" seconds");
        } else {
            throw new AssertionError("Expected to log out in " + expectedTime + " seconds but logged out in " + timeTaken + " seconds");
        }
		return this;
	}
	
	public PerformancePage validateTutorialCloseButtonInLaunchScreen() {
		try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitForVisibility(closeButton);
		Assert.assertTrue(closeButton.isDisplayed(), "Tutorial Screen is not displayed after launching application");
		return this;
	}
	
	public PerformancePage clickingOnCloseButton() {
		waitForVisibility(closeButton);
		click(closeButton);
		pageLoad.reset();
		pageLoad.start();
		waitForVisibility(signInButton);
		Assert.assertTrue(signInButton.isDisplayed(), "Login Screen is not displayed after clicking on Log out button");
		pageLoad.stop();
		navigationTimeLoginScreen = pageLoad.getTime();
		return this;
	}
	
	public PerformancePage validateTimeTakenForNavigatingToLoginScreen() {
		int denominator = 1000;
		double timeTaken = (double)navigationTimeLoginScreen/denominator;
		int expectedTime = Integer.parseInt(td.getTestData(RunnerBase.country, "navigationToLoginScreen"));
		if (timeTaken <= expectedTime) {
            System.out.println("User navigated to login screen within "+expectedTime+" seconds");
        } else {
            throw new AssertionError("Expected to navigate in " + expectedTime + " seconds but navigated in " + timeTaken + " seconds");
        }
		return this;
	}
	
	public boolean isallowLocationbtnvisible() {
		try {
			waitForVisibility(allowLocation);
			return allowLocation.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}
	
	public PerformancePage enterSearchTermToMeasureTime() {
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		click(searchBar);
		sendKeys(searchBar, td.getTestData(RunnerBase.country, "searchTerm"));
		pageLoad.reset();
		pageLoad.start();
		waitForVisibility(searchResults);
		Assert.assertTrue(searchResults.isDisplayed(), "Search Results are not displayed");
		pageLoad.stop();
		searchResultsTime = pageLoad.getTime();
		return this;
	}
	
	public PerformancePage validateTimeTakenForDisplayingSearchResults() {
		int denominator = 1000;
		double timeTaken = (double)searchResultsTime/denominator;
		int expectedTime = Integer.parseInt(td.getTestData(RunnerBase.country, "searchResults"));
		if (timeTaken <= expectedTime) {
            System.out.println("Search Results are displayed with in "+expectedTime+" seconds");
        } else {
            throw new AssertionError("Search Results are expected to display in " + expectedTime + " seconds but displayed in " + timeTaken + " seconds");
        }
		return this;
	}
	
	public PerformancePage runningApplicationInBackground() {
		runApplicationInBackground(10);
		return this;
	}
	
	public PerformancePage validateAppRunningNormallyAfterLaunchingAgain() {
		try {
			Thread.sleep(15000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		Assert.assertTrue(scanner.isDisplayed(), "App is not working normally after login");
		return this;
	}
	
	public PerformancePage clickOnSignButtonToSeeErrorMessage() {
		waitForVisibility(signInButton);
		click(signInButton);
		pageLoad.reset();
		pageLoad.start();
		waitForVisibility(okDisable);
		Assert.assertTrue(okDisable.isDisplayed(), "Invalid Credentials PopUp is not displayed");
		pageLoad.stop();
		loginErrorTime = pageLoad.getTime();
		return this;
	}
	
	public PerformancePage validateTimeTakenForDisplayingErrorMessageDuringLogin() {
		int denominator = 1000;
		double timeTaken = (double)loginErrorTime/denominator;
		System.out.println(timeTaken);
		int expectedTime = Integer.parseInt(td.getTestData(RunnerBase.country, "loginErrorExpectedTime"));
		if (timeTaken <= expectedTime) {
            System.out.println("Error message displayed in within "+expectedTime+" seconds");
        } else {
            throw new AssertionError("Expected to display error message in " + expectedTime + " seconds but took " + timeTaken + " seconds to display");
        }
		return this;
	}

}