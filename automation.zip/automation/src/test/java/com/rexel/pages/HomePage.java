package com.rexel.pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.rexel.runners.RunnerBase;
import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.TestUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class HomePage extends BasePage {
	TestUtils utils = new TestUtils();
	GlobalParams params = new GlobalParams();
	TestData td = new TestData();

	@AndroidFindBy(xpath = "(//android.widget.TextView[@index='0'])[4]")
	private MobileElement hamburgerMenu;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'webshop')]")
	private MobileElement homeTab;

	@AndroidFindBy(xpath = "//*[@resource-id='my-cart-dropdown']")
	private MobileElement cartIcon;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View/android.app.Dialog/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.widget.Button[1]")
	private MobileElement cookiesAccept;

	@AndroidFindBy(accessibility = "Find products")
	@iOSXCUITFindBy(accessibility = "Find products")
	private MobileElement findProduct;

	@AndroidFindBy(accessibility = "My joblists")
	@iOSXCUITFindBy(accessibility = "My joblists")
	private MobileElement myJoblists;

	@AndroidFindBy(accessibility = "My orders")
	@iOSXCUITFindBy(accessibility = "My orders")
	private MobileElement myOrders;

	@AndroidFindBy(accessibility = "My quotes")
	@iOSXCUITFindBy(accessibility = "My quotes")
	private MobileElement myQuotes;

	@AndroidFindBy(accessibility = "My settings")
	@iOSXCUITFindBy(accessibility = "My settings")
	private MobileElement mySettings;

	@AndroidFindBy(accessibility = "My account")
	@iOSXCUITFindBy(accessibility = "My account")
	private MobileElement myAccount;

	@AndroidFindBy(accessibility = "Store finder")
	@iOSXCUITFindBy(accessibility = "Store finder")
	private MobileElement storeFinder;
	
	@AndroidFindBy(accessibility="Back Order Items")
	@iOSXCUITFindBy(accessibility = "Back Order Items")
	private MobileElement backOrderItems;
	
	@AndroidFindBy(accessibility = "Frequently purchased")
	@iOSXCUITFindBy(accessibility = "Frequently purchased")
	private MobileElement frequentlyPurchased;
	
	@AndroidFindBy(accessibility = "All category")
	@iOSXCUITFindBy(accessibility = "All category")
	private MobileElement allCategory;
	
	@AndroidFindBy(accessibility = "My Invoices")
	@iOSXCUITFindBy(accessibility = "My Invoices")
	private MobileElement myInvoices;
	
	@AndroidFindBy(accessibility = "Catalogs")
	@iOSXCUITFindBy(accessibility = "Catalogs")
	private MobileElement catalogs;

	public HomePage() {
	}

	public HomePage validateHomePageElements() {
		if (RunnerBase.country.equalsIgnoreCase("Sweden")) {
			waitForVisibility(findProduct);
			Assert.assertTrue(findProduct.isDisplayed(), "Find Products is not displayed in home page");
			Assert.assertTrue(myJoblists.isDisplayed(), "My Joblists is not displayed in home page");
			Assert.assertTrue(myOrders.isDisplayed(), "My Orders is not displayed in home page");
			Assert.assertTrue(myQuotes.isDisplayed(), "My Quotes is not displayed in home page");
			Assert.assertTrue(mySettings.isDisplayed(), "My Settings is not displayed in home page");
			Assert.assertTrue(myAccount.isDisplayed(), "My Account is not displayed in home page");
			Assert.assertTrue(storeFinder.isDisplayed(), "Store Finder is not displayed in home page");
		} else if(RunnerBase.country.equalsIgnoreCase("France")){
			waitForVisibility(myOrders);
			Assert.assertTrue(findProduct.isDisplayed(), "Find Products is not displayed in home page");
			Assert.assertTrue(myJoblists.isDisplayed(), "My Joblists is not displayed in home page");
			Assert.assertTrue(myOrders.isDisplayed(), "My Orders is not displayed in home page");
			Assert.assertTrue(mySettings.isDisplayed(), "My Settings is not displayed in home page");
			Assert.assertTrue(myQuotes.isDisplayed(), "My Quotes is not displayed in home page");
			Assert.assertTrue(myAccount.isDisplayed(), "My Account is not displayed in home page");
			Assert.assertTrue(storeFinder.isDisplayed(), "Store Finder is not displayed in home page");
		} else if(RunnerBase.country.equalsIgnoreCase("Regro")|| RunnerBase.country.equalsIgnoreCase("Schaeke")) {
			waitForVisibility(myOrders);
			Assert.assertTrue(myJoblists.isDisplayed(), "My Joblists is not displayed in home page");
			Assert.assertTrue(myOrders.isDisplayed(), "My Orders is not displayed in home page");
			Assert.assertTrue(myQuotes.isDisplayed(), "My Quotes is not displayed in home page");
			Assert.assertTrue(mySettings.isDisplayed(), "My Settings is not displayed in home page");
			Assert.assertTrue(myAccount.isDisplayed(), "My Account is not displayed in home page");
			Assert.assertTrue(storeFinder.isDisplayed(), "Store Finder is not displayed in home page");
		}
//		else if(RunnerBase.country.equalsIgnoreCase("Denmans")|| RunnerBase.country.equalsIgnoreCase("UK")) {
//			waitForVisibility(findProduct);
//			Assert.assertTrue(findProduct.isDisplayed(), "Find Products is not displayed in home page");
//			Assert.assertTrue(myJoblists.isDisplayed(), "My Joblists is not displayed in home page");
//			Assert.assertTrue(myOrders.isDisplayed(), "My Orders is not displayed in home page");
//			Assert.assertTrue(myQuotes.isDisplayed(), "My Quotes is not displayed in home page");
//			Assert.assertTrue(mySettings.isDisplayed(), "My Settings is not displayed in home page");
//			Assert.assertTrue(myAccount.isDisplayed(), "My Account is not displayed in home page");
//			Assert.assertTrue(storeFinder.isDisplayed(), "Store Finder is not displayed in home page");
//			Assert.assertTrue(myInvoices.isDisplayed(), "My Invoices is not displayed in home page");
//			Assert.assertTrue(catalogs.isDisplayed(), "Catalogs is not displayed in home page");
//		}
		else {
			try {
				String cookiesData = td.getTestData(RunnerBase.country, "cookiesString");
				MobileElement element = (MobileElement) driver.findElement(By.xpath("//*[@resource-id='"+cookiesData+"']"));
				element.click();
			} catch(Exception e) {
				e.printStackTrace();
			}
			switchContext();
			switchContextToNative();
			waitForVisibility(hamburgerMenu);
			Assert.assertTrue(homeTab.isDisplayed(), "Webshop tab is not displayed in home page");
			Assert.assertTrue(hamburgerMenu.isDisplayed(), "Hamburger Menu is not displayed in home page");
			Assert.assertTrue(cartIcon.isDisplayed(), "Cart icon is not displayed in home page");
		}

		return this;
	}
	
	public HomePage validateMemoryUsageAfterLogin() {
		String expectedUsage = td.getTestData(RunnerBase.country, "memoryUsage");
		double storage = Integer.parseInt(expectedUsage);
		String name = td.getTestData(RunnerBase.country, "packageName");
		double storedData= getMemoryInfoAndroidAfterLogin(name);
        if(storedData <= storage) {
            System.out.println("Memory usage is "+storedData+" MB" );
        }else {
            throw new AssertionError("Expected "+storage +" MB for memory usage but used "+storedData+" MB");
        }
        return this;
	}
}