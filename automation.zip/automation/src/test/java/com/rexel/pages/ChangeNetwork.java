package com.rexel.pages;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class ChangeNetwork {

	public static int updateNetwork(String sessionId, String networkProfile) {
		String url = "https://api-cloud.browserstack.com/app-automate/sessions/"+sessionId+"";
		RestAssured.baseURI = url;
		String requestBody = "{\"networkProfile\": \""+networkProfile+"\"}";
		String username = "qauser_rEAFf4";
        String password = "VTWxoA1Qr3hPnjQ5qTUt";
		Response response = RestAssured.given()
                .auth().basic(username, password)
                .contentType(ContentType.JSON)
                .body(requestBody).put("/update_network.json");
		int statusCode = response.getStatusCode();
		String responseBody = response.getBody().asString();
		System.out.println("Status code: " + statusCode);
		System.out.println("Response body: " + responseBody);
		return statusCode;
	}

}