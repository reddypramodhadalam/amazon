package com.rexel.pages;

import org.testng.Assert;

import com.rexel.runners.RunnerBase;
import com.rexel.utils.TestUtils;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.cucumber.java.en.And;

public class SettingsPage extends BasePage {

	TestUtils utils = new TestUtils();

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'settings')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'settings')]")
	private MobileElement settings;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Scan Beeping')]")
	@iOSXCUITFindBy(accessibility = "Scan Beeping")
	private MobileElement scanbeep;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Scan Vibrate')]")
	@iOSXCUITFindBy(accessibility = "Scan Vibrate")
	private MobileElement scanvibrate;

	@AndroidFindBy(accessibility = "Offline catalog section close icon button")
	@iOSXCUITFindBy(accessibility = "Offline catalog section close icon button")
	private MobileElement closeCatalog;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Allow Repeat Scanning')]")
	@iOSXCUITFindBy(accessibility = "Allow Repeat Scanning")
	private MobileElement repeatScanning;

	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Dark Mode')]")
	@iOSXCUITFindBy(accessibility = "Dark Mode")
	private MobileElement darkMode;

	@AndroidFindBy(xpath = "//android.widget.SeekBar[@content-desc=\"0%\"]")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@index='4'])[1]")
	private MobileElement seekBar;

	@AndroidFindBy(xpath = "//android.widget.Button[contains(@content-desc,'Sign out')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name, 'Sign out')]")
	private MobileElement logoutBtn;

	@AndroidFindBy(xpath = "//android.widget.Button[contains(@content-desc,'Sign in')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@name, 'Sign in')]")
	private MobileElement signInBtn;

	@AndroidFindBy(xpath = "(//android.view.View[contains(@content-desc,'account')])[2]")
	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@name, 'account')])[2]")
	private MobileElement accountTab;
	
	@AndroidFindBy(accessibility = "ACCOUNT")
	@iOSXCUITFindBy(accessibility = "ACCOUNT")
	private MobileElement accountSection;

	@AndroidFindBy(accessibility = "APP SETTINGS")
	@iOSXCUITFindBy(accessibility = "APP SETTINGS")
	private MobileElement appSettingsSection;

	@AndroidFindBy(accessibility = "SECURITY")
	@iOSXCUITFindBy(accessibility = "SECURITY")
	private MobileElement securitySection;

	@AndroidFindBy(accessibility = "LEGAL INFORMATION")
	@iOSXCUITFindBy(accessibility = "LEGAL INFORMATION")
	private MobileElement legalInformationSection;

	@AndroidFindBy(accessibility = "ABOUT")
	@iOSXCUITFindBy(accessibility = "ABOUT")
	private MobileElement aboutSection;

	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ACCOUNT']//android.view.View[@content-desc='Orders']")
	@iOSXCUITFindBy(accessibility = "Orders")
	private MobileElement ordersInAccountSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ACCOUNT']//android.view.View[@content-desc='Quotes']")
	@iOSXCUITFindBy(accessibility = "Quotes")
	private MobileElement quotesInAccountSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ACCOUNT']//android.view.View[@content-desc='Joblists']")
	@iOSXCUITFindBy(accessibility = "Joblists")
	private MobileElement jobListsInAccountSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ACCOUNT']//android.view.View[@content-desc='Invoices']")
	@iOSXCUITFindBy(accessibility = "Invoices")
	private MobileElement invoicesInAccountSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ACCOUNT']//android.view.View[@content-desc='Download center']")
	@iOSXCUITFindBy(accessibility = "Download center")
	private MobileElement downloadCenterInAccountSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ACCOUNT']//android.view.View[@content-desc='Profile']")
	@iOSXCUITFindBy(accessibility = "Profile")
	private MobileElement profileInAccountSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ACCOUNT']//android.view.View[@content-desc='Account settings']")
	@iOSXCUITFindBy(accessibility = "Account settings")
	private MobileElement accountSettingsInAccountSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='APP SETTINGS']//android.view.View[@content-desc='Settings']")
	@iOSXCUITFindBy(accessibility = "Settings")
	private MobileElement settingsInAppSettingsSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='APP SETTINGS']//android.view.View[@content-desc='Rate in App/Play store']")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name, 'Rate in App')]")
	private MobileElement rateInAppSettingsSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='APP SETTINGS']//android.view.View[@content-desc='Requests observer']")
	@iOSXCUITFindBy(accessibility = "Requests observer")
	private MobileElement requestsInAppSettingsSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='SECURITY']//android.view.View[@content-desc='APP security']")
	@iOSXCUITFindBy(accessibility = "APP security")
	private MobileElement appSecurityInSecuritySection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='LEGAL INFORMATION']//android.view.View[@content-desc='Terms & conditions']")
	@iOSXCUITFindBy(accessibility = "Terms & conditions")
	private MobileElement termsInLegalInformationSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='LEGAL INFORMATION']//android.view.View[@content-desc='Legal notice']")
	@iOSXCUITFindBy(accessibility = "Legal notice")
	private MobileElement legalNoticeInLegalInformationSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='LEGAL INFORMATION']//android.view.View[@content-desc='Privacy policy']")
	@iOSXCUITFindBy(accessibility = "Privacy policy")
	private MobileElement privacyPolicyInLegalInformationSection;
	
	@AndroidFindBy(xpath = "//android.view.View[@content-desc='ABOUT']//android.view.View[@content-desc='Contact us']")
	@iOSXCUITFindBy(accessibility = "Contact us")
	private MobileElement contactUsInAboutSection;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Tutorial')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Rate In App Store')]")
	private MobileElement rateInAppStore;
	
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Requests observer')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Requests observer')]")
	private MobileElement requestsObserver;
	
	@AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'Tutorial')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Tutorial')]")
	private MobileElement tutorial;
	

	public SettingsPage clickOnCloseCatalog() {
		waitForVisibility(closeCatalog);
		click(closeCatalog);
		return this;
	}

	public SettingsPage clickOnSettingsTab() {
		waitForVisibility(settings);
		if (RunnerBase.country.equalsIgnoreCase("Sweden") || RunnerBase.country.equalsIgnoreCase("Regro")
				|| RunnerBase.country.equalsIgnoreCase("Schaeke") || RunnerBase.country.equalsIgnoreCase("Denmans")) {
			driver.findElementByXPath("(//android.view.View[contains(@content-desc,'settings')])[2]").click();
		} else if (RunnerBase.country.equalsIgnoreCase("France")) {
			click(accountTab);
		} else {
			click(settings);
		}
		return this;
	}

	public SettingsPage validateSettingsPage() {
		waitForVisibility(scanbeep);
		Assert.assertTrue(scanbeep.isDisplayed(), "Settings tab is not displayed");
		return this;
	}

	public SettingsPage validateScanBeepButton() {
		Assert.assertTrue(scanbeep.isDisplayed(), "Scan beep toggle button is not displayed");
		click(scanbeep);
		click(scanbeep);
		return this;
	}

	public SettingsPage validateScanVibrateButton() {
		Assert.assertTrue(scanvibrate.isDisplayed(), "Scan vibrate toggle button is not displayed");
		click(scanvibrate);
		click(scanvibrate);
		return this;
	}

	public SettingsPage validateAllowRepeatScanButton() {
		Assert.assertTrue(repeatScanning.isDisplayed(), "Allow repeat scanning toggle button is not displayed");
		click(repeatScanning);
		click(repeatScanning);
		return this;
	}

	public SettingsPage adjustScanningSpeed() {
		int[] x = getElementLocation(seekBar);
		pressByCoordinates(x[2] - x[0], x[1]);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pressByCoordinates(x[0], x[1]);
		return this;
	}

	public SettingsPage validateDarkModeButton() {
		Assert.assertTrue(darkMode.isDisplayed(), "Dark mode toggle button is not displayed");
		click(darkMode);
		click(darkMode);
		return this;
	}

	public SettingsPage clickOnLogoutButton() {
		try {
			MobileElement element = scrollToElement(logoutBtn, "up");
			waitForVisibility(element);
			Thread.sleep(3000);
			click(logoutBtn);
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;
	}

	public SettingsPage validateSignInButton() {
		waitForVisibility(signInBtn);
		Assert.assertTrue(signInBtn.isDisplayed(), "Sign in button is not displayed");
		return this;
	}

	public SettingsPage clickOnSignInButton() {
		click(signInBtn);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return this;
	}
	
	public SettingsPage clickOnAccountTab() {
		click(accountTab);
		return this;
	}

	public SettingsPage validateAccountTabTitle() {
		Assert.assertTrue(accountSection.isDisplayed(), "Account Tab Title is not displayed");
		return this;
	}

	public SettingsPage validateSectionsInAccountTab() {
		Assert.assertTrue(accountSection.isDisplayed(), "Account section is not displayed in account tab");
		validateAccountSectionInAccountTab();
		Assert.assertTrue(appSettingsSection.isDisplayed(), "App Settings section is not displayed in account tab");
		validateAppSettingsSectionInAccountTab();
		try {
			MobileElement element = scrollToElement(aboutSection, "up");
			waitForVisibility(element);
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Assert.assertTrue(securitySection.isDisplayed(), "Security section is not displayed in account tab");
		validateSecuritySectionInAccountTab();
		Assert.assertTrue(legalInformationSection.isDisplayed(),
				"Legal Information section is not displayed in account tab");
		validateLegalInformationSectionInAccountTab();
		Assert.assertTrue(aboutSection.isDisplayed(), "About section is not displayed in account tab");
		validateAboutSectionInAccountTab();
		return this;
	}

	public SettingsPage validateAccountSectionInAccountTab() {
		Assert.assertTrue(ordersInAccountSection.isDisplayed(),
				"Orders button is not displayed in account section of account tab");
		Assert.assertTrue(quotesInAccountSection.isDisplayed(),
				"Quotes button is not displayed in account section of account tab");
		Assert.assertTrue(jobListsInAccountSection.isDisplayed(),
				"Joblists button is not displayed in account section of account tab");
		Assert.assertTrue(invoicesInAccountSection.isDisplayed(),
				"Invoice button is not displayed in account section of account tab");
		Assert.assertTrue(downloadCenterInAccountSection.isDisplayed(),
				"Download Center button is not displayed in account section of account tab");
		Assert.assertTrue(profileInAccountSection.isDisplayed(),
				"Profile Center button is not displayed in account section of account tab");
		Assert.assertTrue(accountSettingsInAccountSection.isDisplayed(),
				"Account Settings button is not displayed in account section of account tab");
		return this;
	}
	
	public SettingsPage validateAppSettingsSectionInAccountTab() {
		Assert.assertTrue(settingsInAppSettingsSection.isDisplayed(),
				"Settings button is not displayed in app settings section of account tab");
		Assert.assertTrue(rateInAppSettingsSection.isDisplayed(),
				"Rate in Play store or app store button is not displayed in app settings section of account tab");
		Assert.assertTrue(requestsInAppSettingsSection.isDisplayed(),
				"Request observer button is not displayed in app settings section of account tab");
		return this;
	}
	
	public SettingsPage validateSecuritySectionInAccountTab() {
		Assert.assertTrue(appSecurityInSecuritySection.isDisplayed(),
				"App Security button is not displayed in security section of account tab");
		return this;
	}
	
	public SettingsPage validateLegalInformationSectionInAccountTab() {
		Assert.assertTrue(termsInLegalInformationSection.isDisplayed(),
				"Terms & condition button is not displayed in legal information section of account tab");
		Assert.assertTrue(legalNoticeInLegalInformationSection.isDisplayed(),
				"Legal Notice button is not displayed in legal information section of account tab");
		Assert.assertTrue(privacyPolicyInLegalInformationSection.isDisplayed(),
				"Privacy policy button is not displayed in legal information section of account tab");
		return this;
	}
	
	public SettingsPage validateAboutSectionInAccountTab() {
		Assert.assertTrue(contactUsInAboutSection.isDisplayed(),
				"Contact us button is not displayed in about section of account tab");
		return this;
	}
	
	public SettingsPage clickOnSettingTabInAppSettings() {
		click(settingsInAppSettingsSection);
		return this;
	}
	
	public SettingsPage validateTutorialTabInSettingsScreen() {
		Assert.assertTrue(tutorial.isDisplayed(), "Tutorial tab is not displayed");
		return this;
	}
	
	public SettingsPage validateRateInAppStoreTabInSettingsScreen() {
		Assert.assertTrue(rateInAppStore.isDisplayed(), "Rate in app store tab is not displayed");
		return this;
	}
	
	public SettingsPage validateRequestsObserverTabInSettingsScreen() {
		Assert.assertTrue(requestsObserver.isDisplayed(), "Requests Observer tab is not displayed");
		return this;
	}
	
}
