package com.rexel.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.rexel.runners.RunnerBase;
import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.TestUtils;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class CartPage extends BasePage {
	TestUtils utils = new TestUtils();
	GlobalParams params = new GlobalParams();
	TestData td = new TestData();

	@AndroidFindBy(accessibility = "Add to Cart")
	@iOSXCUITFindBy(accessibility = "Add to Cart")
	private MobileElement addToCartButton;

	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc,'cart')]")
	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'cart')]")
	private MobileElement cartTab;

	@AndroidFindBy(xpath="//android.widget.Button[contains(@content-desc, 'Product image in catalog product card')]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[contains(@name,'Product image in catalog product card')]")
	private MobileElement searchResults;

	@AndroidFindBy(xpath="(//android.widget.Button)[3]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[@name='platform_view[0]']/XCUIElementTypeWebView/XCUIElementTypeWebView/XCUIElementTypeWebView")
	private MobileElement closeButton;

	@AndroidFindBy(accessibility = "Login to continue")
	@iOSXCUITFindBy(accessibility = "Login to continue")
	private MobileElement loginToContinue;

	@AndroidFindBy(accessibility = "Empty cart")
	@iOSXCUITFindBy(accessibility = "Empty cart")
	private MobileElement emptyCart;

	@AndroidFindBy(accessibility = "Custom outlined button Yes, empty cart")
	@iOSXCUITFindBy(accessibility = "Custom outlined button Yes, empty cart")
	private MobileElement yesEmptyCartButton;

	@AndroidFindBy(accessibility = "Custom outlined button Cancel")
	@iOSXCUITFindBy(accessibility = "Custom outlined button Cancel")
	private MobileElement cancelEmptyCartButton;

	@AndroidFindBy(accessibility = "Your Cart is empty!")
	@iOSXCUITFindBy(accessibility = "Your Cart is empty!")
	private MobileElement cartEmptyMessage;

	@AndroidFindBy(accessibility = "Start Shopping")
	@iOSXCUITFindBy(accessibility = "Start Shopping")
	private MobileElement startShoppingButton;
	
	@AndroidFindBy(xpath="//android.view.View[contains(@content-desc, 'Product image in catalog product card')]")
	@iOSXCUITFindBy(xpath="//XCUIElementTypeOther[contains(@name,'Product image in catalog product card')]")
	private MobileElement searchResultsWithoutLogin;

	public CartPage() {

	}

	public CartPage addProductToCart() {
		if (RunnerBase.platform.equalsIgnoreCase("Android")) {
			int[] x = getElementLocation(searchResults);
			pressByCoordinates((x[0] + x[2] - 100), (x[1] + x[3] - 80));
			try {
				Thread.sleep(3000);
				waitForVisibility(addToCartButton);
				click(addToCartButton);
				Thread.sleep(7000);
				driver.hideKeyboard();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			int[] x = getElementLocation(searchResults);
			pressByCoordinates((x[0] + x[2] - 35), (x[1] + x[3] - 25));
			try {
				Thread.sleep(3000);
				waitForVisibility(addToCartButton);
				click(addToCartButton);
				Thread.sleep(7000);
				driver.hideKeyboard();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return this;
	}

	public CartPage navigateToCartTab() {
		waitForVisibility(cartTab);
		click(cartTab);
		return this;
	}

	public CartPage validateProductInCart() {
		if(RunnerBase.country.equalsIgnoreCase("Android")) {
			pressByCoordinates(500, 1815);
			waitForVisibility(closeButton);
			String text = closeButton.getText();
			Assert.assertTrue(text.contains("Close"), "Cart Page is not displayed");
		} else {
			pressByCoordinates(180, 610);
			waitForVisibility(closeButton);
			Assert.assertTrue(closeButton.isDisplayed(), "Cart Page is not displayed");
		}		;
		return this;
	}

	public CartPage validateButtonInCartWithoutLogin() {
		waitForVisibility(loginToContinue);
		Assert.assertTrue(loginToContinue.isDisplayed(), "Login to continue button is not displayed");
		Assert.assertTrue(emptyCart.isDisplayed(), "Empty Cart button is not displayed");
		return this;
	}

	public CartPage clickingOnEmptyCartButton() {
		click(emptyCart);
		return this;
	}

	public CartPage validateEmptyCartPopUpButtons() {
		waitForVisibility(yesEmptyCartButton);
		Assert.assertTrue(yesEmptyCartButton.isDisplayed(), "Yes Empty Cart button is not displayed");
		Assert.assertTrue(cancelEmptyCartButton.isDisplayed(), "Cancel Empty Cart button is not displayed");
		return this;
	}

	public CartPage clickingOnYesButton() {
		click(yesEmptyCartButton);
		return this;
	}

	public CartPage validateProductDeleteMessage() {
		waitForVisibility(cartEmptyMessage);
		Assert.assertTrue(cartEmptyMessage.isDisplayed(), "Cart is not empty");
		return this;
	}

	public CartPage validateStartShoppingButton() {
		waitForVisibility(startShoppingButton);
		Assert.assertTrue(startShoppingButton.isDisplayed(), "Start Shopping button is not displayed");
		return this;
	}

	public CartPage validateEmptyCartButtonAfterDeletingProductsFromCart() {
		List<?> element = driver.findElements(By.xpath("//android.widget.Button[@content-desc='Empty cart']"));
		Assert.assertTrue(element.size() == 0, "Empty cart button is displayed");
		return this;
	}
	
	public CartPage addProductToCartWithoutLogin() {
		if (RunnerBase.platform.equalsIgnoreCase("Android")) {
			int[] x = getElementLocation(searchResultsWithoutLogin);
			pressByCoordinates((x[0] + x[2] - 100), (x[1] + x[3] - 80));
			try {
				Thread.sleep(3000);
				waitForVisibility(addToCartButton);
				click(addToCartButton);
				Thread.sleep(7000);
				driver.hideKeyboard();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			int[] x = getElementLocation(searchResultsWithoutLogin);
			pressByCoordinates((x[0] + x[2] - 35), (x[1] + x[3] - 25));
			try {
				Thread.sleep(3000);
				waitForVisibility(addToCartButton);
				click(addToCartButton);
				Thread.sleep(7000);
				//driver.hideKeyboard();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return this;
	}

}