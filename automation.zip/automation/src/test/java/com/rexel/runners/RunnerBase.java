package com.rexel.runners;

import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;
import io.cucumber.testng.TestNGCucumberRunner;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.ThreadContext;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.*;

import com.rexel.utils.DriverManager;
import com.rexel.utils.GlobalParams;
import com.rexel.utils.ServerManager;

public class RunnerBase {
	private static final ThreadLocal<TestNGCucumberRunner> testNGCucumberRunner = new ThreadLocal<>();
	public static String platform=System.getProperty("platform");
	public static String country=System.getProperty("country");
	public static TestNGCucumberRunner getRunner() {
		return testNGCucumberRunner.get();
	}

	private static void setRunner(TestNGCucumberRunner testNGCucumberRunner1) {
		testNGCucumberRunner.set(testNGCucumberRunner1);
	}

	@Parameters({ "platformName", "udid", "deviceName", "systemPort", "chromeDriverPort", "wdaLocalPort",
			"webkitDebugProxyPort", "osVersion", "BROWSERSTACK_BUILD_NAME"})
	@BeforeClass(alwaysRun = true)
	public void setUpClass(String platformName, String udid, String deviceName, @Optional("Android") String systemPort,
			@Optional("Android") String chromeDriverPort, @Optional("iOS") String wdaLocalPort,
			@Optional("iOS") String webkitDebugProxyPort, @Optional("Browserstack") String osVersion,
			@Optional("Browserstack") String BROWSERSTACK_BUILD_NAME)
			throws Exception {

		ThreadContext.put("ROUTINGKEY", platformName + "_" + deviceName);
		String browserstackAppId = downloadBuild();
		GlobalParams params = new GlobalParams();
		params.setPlatformName(platformName);
		params.setUDID(udid);
		params.setDeviceName(deviceName);

		switch (platformName) {
		case "Android":
			params.setSystemPort(systemPort);
			params.setChromeDriverPort(chromeDriverPort);
			break;
		case "iOS":
			params.setWdaLocalPort(wdaLocalPort);
			params.setWebkitDebugProxyPort(webkitDebugProxyPort);
			break;
		case "Browserstack":
			params.setType(platform);
			params.setOsVersion(osVersion);
			params.setBrowserstackAppId(browserstackAppId);
			params.setBrowserstackBuildName(BROWSERSTACK_BUILD_NAME);
			break;
		}
		setRunner(new TestNGCucumberRunner(this.getClass()));
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Scenarios", dataProvider = "scenarios")
	public void scenario(PickleWrapper pickle, FeatureWrapper cucumberFeature) throws Throwable {
		getRunner().runScenario(pickle.getPickle());
	}

	@DataProvider
	public static Object[][] scenarios() {
		return getRunner().provideScenarios();
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() {
		DriverManager driverManager = new DriverManager();
		if (driverManager.getDriver() != null) {
			driverManager.getDriver().quit();
			driverManager.setDriver(null);
		}
		ServerManager serverManager = new ServerManager();
		if (serverManager.getServer() != null) {
			serverManager.getServer().stop();
		}
		if (testNGCucumberRunner != null) {
			getRunner().finish();
		}
	}
	
	public String downloadBuild() {
		String appId=null;
		String filePath = System.getProperty("user.dir")+File.separator+"bstack.apk";
        Path path = Paths.get(filePath);
        if (Files.exists(path)) {
            System.out.println("File exists.");
            appId=uploadBuild(filePath);
        } else {
            System.out.println("File does not exist.");
            String downloadFolderPath = System.getProperty("user.dir");
    		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
            chromePrefs.put("profile.default_content_settings.popups", 0);
            chromePrefs.put("download.default_directory", downloadFolderPath);
    		System.setProperty("webdriver.chrome.driver", "C:\\Users\\arpramod\\Downloads\\chromedriver.exe");
    		ChromeOptions options = new ChromeOptions();
    		options.addArguments("--remote-allow-origins=*");
    		options.addArguments("--no-sandbox");
    		//options.addArguments("--remote-allow-origins=*");
    		options.addArguments("--disable-dev-shm-usage");
    		options.addArguments("--window-size=1920x1080");
    		//options.addArguments("--headless");
    		options.setExperimentalOption("prefs", chromePrefs);
    		WebDriver driver1 = new ChromeDriver(options);
    		try {			
    			driver1.get("https://appcenter.ms/apps?original_url=%2Fapps");
    			driver1.manage().window().maximize();
    			driver1.findElement(By.xpath("//a[contains(text(),'Sign in with email')]")).click();
    			Thread.sleep(5000);
    			driver1.findElement(By.xpath("//input[@name='email']")).sendKeys("a-reddy.pramodh@capgemini.com");
    			driver1.findElement(By.xpath("//input[@name='password']")).sendKeys("KPR5tb*197");
    			driver1.findElement(By.xpath("//span[text()='Sign in']")).click();
    			Thread.sleep(10000);
    			driver1.findElement(By.xpath("//span[contains(text(), 'flutter-uat-frx')]")).click();
    			Thread.sleep(5000);
    			String text = driver1.findElement(By.xpath("//h3")).getText();
    			String[] data = text.split("\\(");
    			String version = data[1].replace(")", "");
    			driver1.findElement(By.xpath("//div[contains(text(), 'See all releases')]")).click();
    			Thread.sleep(5000);
    			driver1.findElement(By.xpath("//span[contains(text(),'"+version+"')]")).click();
    			Thread.sleep(8000);
    			driver1.findElement(By.xpath("//div[@icon='button-expand-more']")).click();
    			Thread.sleep(8000);
    			driver1.findElement(By.xpath("//a[contains(text(), 'apk')]")).click();
    			for(int i=0;i<100;i++) {
    				String file = System.getProperty("user.dir")+File.separator+"app-uat_rexelfr-release.apk";
    		        Path p = Paths.get(file);
    				if(Files.exists(p)) {
    					break;
    				}
    				else {
    					Thread.sleep(5000);
    				}
    			}
    			driver1.close();
    			driver1.quit();
    			String oldFilePath = System.getProperty("user.dir")+File.separator+"app-uat_rexelfr-release.apk";
    	        String newFilePath = System.getProperty("user.dir")+File.separator+"bstack.apk";
    	        File oldFile = new File(oldFilePath);
    	        File newFile = new File(newFilePath);
    	        if (oldFile.exists()) {
    	            if (oldFile.renameTo(newFile)) {
    	                System.out.println("APK file renamed successfully.");
    	            } else {
    	                System.err.println("Failed to rename the APK file.");
    	            }
    	        } else {
    	            System.err.println("Old APK file does not exist.");
    	        }
    		} catch (Exception e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			driver1.close();
    			driver1.quit();
    		}
            appId=uploadBuild(filePath);
        }
		return appId;
	}
	public String uploadBuild(String path) {
		String id = null;
		id = uploadBuildUsingCurl(path);
		String pattern = "\"app_url\":\"(bs://[a-zA-Z0-9]+)\"";
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(id);
        if (matcher.find()) {
            String extractedValue = matcher.group(1);
            id = extractedValue;
            System.out.println("Extracted Value: " + extractedValue);
            try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        } else {
            System.out.println("Value not found in the input text.");
        }	
		String appId = id.replace("bs://", "");
		return appId;
	}
	
	public String uploadBuildUsingCurl(String path) {
		String text = null;
		try {
			System.out.println(path);
			String command = "curl -u \"qauser_rEAFf4:VTWxoA1Qr3hPnjQ5qTUt\" -X POST \"https://api-cloud.browserstack.com/app-automate/upload\" -F \"file=@"+path+"\"";
            ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
            	text = text + line;    
            }
            System.out.println(text);
            int exitCode = process.waitFor();
            System.out.println("Command exited with code " + exitCode);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return text;
	}
}
