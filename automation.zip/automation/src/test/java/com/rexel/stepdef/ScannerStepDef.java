package com.rexel.stepdef;

import com.rexel.pages.ScannerPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ScannerStepDef {

	@And("^Clicks on scanner tab$")
	public void clicksOnScannerTab() {
		new ScannerPage().clickOnScannerTab();
	}

	@And("^User clicked on change branch to scan new branch$")
	public void userClickedOnChangeBranch() {
		new ScannerPage().clickOnChangeBranch();
	}

	@Then("^Checkout option should be displayed$")
	public void checkoutOptionShouldBeDisplayed() {
		new ScannerPage().validateCheckoutOption();
	}

	@And("^User clicked on self checkout tab$")
	public void userClickedOnSelfCheckoutTab() {
		new ScannerPage().clickOnSelfCheckout();
	}

	@Then("^Scan or add by id option should be displayed$")
	public void scanOrAddByIdOptionShouldBeDisplayed() {
		new ScannerPage().validateScanningIsDisplayed();
	}

	@When("^User clicked on add by id$")
	public void userClickedOnAddById() throws InterruptedException {
		new ScannerPage().clickOnAddByID();
	}

	@Then("^Option to enter ID should be displayed$")
	public void optionToEnterIdShouldBeDisplayed() {
		new ScannerPage().validateAddByIdScreen();
	}

	@When("User enters product ID")
	public void userEntersProductId() throws InterruptedException {
		new ScannerPage().enterProductId();
	}

	@When("User enters invalid product ID")
	public void userEntersInvalidProductId() {
		new ScannerPage().userEntersInvalidProductId();
	}

	@And("^User clicked on start self checkout button$")
	public void userClickedOnStartSelfCheckoutButton() {
		new ScannerPage().clickStartCheckout();
	}

	@Then("^Continue to cart should be displayed$")
	public void continueToCartShouldBeDisplayed() throws InterruptedException {
		new ScannerPage().validateContinueToCartDisplayed();
	}

	@Then("^Clicking on Continue to Cart")
	public void clickingOnContinueToCart() {
		new ScannerPage().clickingOnContinueToCart();
	}

	@And("^User scans the Fraud QR code$")
	public void scanFraudProductQrCode() throws InterruptedException {
		new ScannerPage().scanFraudProductQrCode();
	}

	@And("^User scans the QR code$")
	public void userScansQrCode() throws InterruptedException {
		new ScannerPage().scanProductQrCode();
	}

	@And("^User clicks on cross Delete Product")
	public void clickOnDeleteProduct() {
		new ScannerPage().clickOnDeleteProduct();
	}

	@And("^User clicks the Change Branch Btn$")
	public void userClickOnChangeBranch() {
		new ScannerPage().clickOnChangeBranch();
	}

	@And("^User added product to cart$")
	public void userAddedProductToCart() {
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@And("^User clicked on regular checkout tab$")
	public void userClickedOnRegularCheckoutTab() {
		new ScannerPage().clickingOnRegularCheckoutInScannerTab();
	}

	@And("^User added product to regular checkout$")
	public void userAddedProductToRegularCheckout() {
		new ScannerPage().clickingOnContinueToRegularCheckout();
	}

	@And("^User scans a blank image$")
	public void scanBlankImage() {
		new ScannerPage().scanBlankCode();
	}

	@Then("^Add to cart option should be displayed$")
	public void addToCartOptionShouldBeDisplayed() {
		new ScannerPage().validateAddToCartOption();
	}

	@When("^User clicks on scan tab$")
	public void userClicksOnScanTab() {
		new ScannerPage().clickingOnScannerTab();
	}

	@And("^User clicked on selfcheckout$")
	public void userClickedOnSelfCheckout() {
		new ScannerPage().clickingOnSelfCheckout();
	}

	@When("^User clicked on back button$")
	public void userClickedOnBackButton() {
		new ScannerPage().clickingOnBackButton();
	}

	@And("^User clicks on Allow Camera button")
	public void userClickOnAllowCameraBtn() {
		new ScannerPage().clickOnAllowCamera();
	}

	@And("^User clicked on Add by Id")
	public void userClickOnAddByIdBtn() {
		new ScannerPage().clickOnAddById();
	}

	@When("^User enters fraud check product ID")
	public void clickOnIFrauddTextBox() {
		new ScannerPage().enterFraudProductId();
	}

	@And("^User Clicks on Try Again button")
	public void clickOnTryAgainBtn() {
		new ScannerPage().clickOnTryAgainBtn();
	}

	@And("^Validate close button")
	public void validatecloseBtn() {
		new ScannerPage().validateClosebtn();
	}

	@And("^User clicks on close button")
	public void clickOnCloseBtn() {
		new ScannerPage().clickingOnClosebtn();
	}

	@And("^Validate add Item to Cart")
	public void validateAddItemtoCart() {
		new ScannerPage().validateAddItemtoCart();
	}

	@And("^Click on Yes button")
	public void clickOnApproveDelete() {
		new ScannerPage().clickOnApproveDelete();
	}

	@When("^User clicked on start checkout$")
	public void userClickedOnstartCheckout() {
		new ScannerPage().clickStartCheckout();
	}

	@When("^User clicked on start self checkout to scan invalid product code$")
	public void userClickedOnStartSelfCheckoutToScanInvalidProductCode() {
		new ScannerPage().scanInvalidProductCode();
	}

	@Then("^Pop up should be displayed to scan valid product$")
	public void popUpShouldBeDisplayedToScanValidProduct() {
		new ScannerPage().validateInvalidProductScan();
	}

	@When("^User clicked on start self checkout to scan valid product code$")
	public void userClickedOnStartSelfCheckoutToScanValidProductCode() {
		new ScannerPage().scanValidProductCode();
	}

	@Then("^Pop up should be displayed with product details$")
	public void popUpShouldBeDisplayedWithProductDetails() {
		new ScannerPage().validateProductQRScan();
	}

	@When("^User clicks on close button in product details tile$")
	public void userClicksOnCloseButtonInProductDetailsTile() {
		new ScannerPage().clickOnProductDetailsCloseButton();
	}

	@Then("^Product tile should be closed$")
	public void productTileShouldBeClosed() {
		new ScannerPage().validateProductDetailsClosure();
	}

	@When("^User enters valid product ID$")
	public void userEntersValidProductId() throws InterruptedException {
		new ScannerPage().enterProductId();
	}

	@And("^User scan invalid product code$")
	public void userScanInvalidProductCode() {
		new ScannerPage().scanInvalidProductCodeRegularCheckout();
	}

	@When("^User swipe down on the product card$")
	public void userSwipeDownOnTheProductCard() {
		new ScannerPage().swipeDownOnProductCard();
	}

	@Then("^Product card should be closed$")
	public void productCardShouldBeClosed() {
		new ScannerPage().validateProductCardClosure();
	}

	@And("^User clicked on regular checkout tab for adding Id$")
	public void userClickedOnRegularCheckoutTabForAddingId() {
		new ScannerPage().clickOnRegularCheckoutForAddingProductId();
	}

	@Then("^Add to cart should not be enabled$")
	public void addToCartShouldNotBeEnabled() {
		new ScannerPage().validateAddToCartEnablement();
	}

	@When("^User clicked on plus button for any item$")
	public void user_clicked_on_plus_button_for_any_item() {
		new ScannerPage().clickingOnPlusSignInFullBoxProduct();
	}

	@Then("^Add to cart button should be enabled$")
	public void add_to_cart_button_should_be_enabled() {
		new ScannerPage().validateAddToCartEnablementAfterAddingQuantity();
	}

	@Then("^Pop up should be displayed to enter invalid product id$")
	public void popUpShouldBeDisplayedToEnterInvalidProductId() {
		new ScannerPage().validateInvalidProductCode();
	}

	@And("^User clicks on Add to cart option$")
	public void clickOnAddItemToCart() {
		new ScannerPage().clickOnAddToCartOption();
	}

	@And("^User click on Continue to cart$")
	public void clickOnContToCart() {
		new ScannerPage().clickOnContToCart();
		new ScannerPage().clickOnAddAllToCart();
	}

	@When("^User clicks on Accept All Btn$")
	public void clickOnAcceptAllBtn() {
		new ScannerPage().clickOnAcceptAllBtn();

	}

	@Then("^Validate Shopping Cart$")
	public void validateShoppingCart() {
		new ScannerPage().validateShoppingCart();

	}

	@And("^User clicked on regular checkout tab to scan QR code$")
	public void userClickedOnRegularCheckoutTabToScanQrCode() {
		new ScannerPage().clickingOnRegularCheckout();
	}

	@When("^Enter quantity as 0$")
	public void enterQuantityAsZero() {
		new ScannerPage().enterZeroAsQuantity();
	}

	@Then("^Validate Quantity$")
	public void validateQuantity() {
		new ScannerPage().validateZeroQuantity();
	}

	@And("^User enters product ID which has more than one as multiple$")
	public void userEntersProductIdWhichHasMoreThanOneAsMultiple() throws InterruptedException {
		new ScannerPage().enterProductIdWithMultipleQuantity();
	}
	
	@When("^Enter quantity as 50$")
	public void enterQuantityAsFifty() {
		new ScannerPage().enterfiftyAsQuantity();
	}
	
	@Then("^Quantity should be updated to nearest multiple$")
	public void quantityShouldBeUpdateToNearestMultiple() {
		new ScannerPage().validateZeroQuantity();
	}
	
	@Then("^Scan Branch Code option should be displayed$")
	public void scanBranchCodeOptionShouldBeDisplayed() {
		new ScannerPage().validateScanBranchCode();
	}
	
//	@When("^Click on Cart Icon$")
//	public void clickCartIcon() {
//		new ScannerPage().clickCartIcon();
//	}
	
	@When("^User Clicked on Scan branch code to scan branch qr code$")
	public void userClickedOnScanBranchCode() {
		new ScannerPage().clickingOnScanBranchCode();
	}
	
	@Then("^Start checkout option should be displayed$")
	public void startCheckoutOptionShouldBeDisplayed() {
		new ScannerPage().startCheckout();
	}
	
	@And("^User added product to self checkout$")
	public void userAddedProductToSelfCheckout() {
		new ScannerPage().clickingOnContinueToSelfCheckout();
	}
	
	@When("^User clicked on start self checkout button to scan product qr code$")
	public void userClickedOnStartSelfChecoutButtonToScanProductQrCode() {
		new ScannerPage().clickingOnStartSelfCheckoutButtonToScanProductCode();
	}
	
	@Then("^Add to self checkout option should be displayed$")
	public void addToSelfCheckoutOptionShouldBeDisplayed() {
		new ScannerPage().validateAddToSelfCheckoutOption();
	}
	
	@When("^User Clicked on Scan branch code to scan full branch qr code$")
	public void userClickedOnScanBranchCodeToScanFullBranchQrCode() {
		new ScannerPage().scanFullBoxBranchCode();
	}
	
	@When("^User clicked on start self checkout to scan full box product code$")
	public void userClickedOnStartSelfCheckoutToScanFullBoxProductCode() {
		new ScannerPage().scanFullBoxProductQrCode();
	}
	
	@Then("^Select quantity button should be displayed$")
	public void selectQuantityButtonShouldBeDisplayed() {
		new ScannerPage().validateSelectQuantityButton();
	}
	
	@When("^User clicked on select quantity$")
	public void userClickedOnSelectQuantity() {
		new ScannerPage().clickingOnSelectQuantityButton();
	}
	
	@When("^User enters full box product ID$")
	public void userEntersFullBoxProductId() {
		new ScannerPage().enterFullBoxProductId();
	}
	
	@Then("^Scanner page should be displayed$")
	public void scannerPageShouldBeDisplayed() {
		new ScannerPage().validateScannerPageDisplayed();
	}
	
	@And("^User enters product ID with special characters$")
	public void userEntersProductIdWithSpecialCharacters() {
		new ScannerPage().enterProductIdWithSpecialCharacters();
	}
	
}
