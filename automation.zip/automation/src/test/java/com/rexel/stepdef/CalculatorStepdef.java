package com.rexel.stepdef;

import com.rexel.pages.CalculatorPage;
import io.cucumber.java.en.*;

public class CalculatorStepdef {

	@And("^User clicks on calcuator tab$")
	public void clickOnCalculatorTab() {
		new CalculatorPage().clickOnCalculatorTab();
	}

	@And("^User clicks on see all btn$")
	public void clickOnSeeAllBtn() {
		new CalculatorPage().clickOnSeeAllBtn();
	}

	@And("^User Enters Values for calculating cable length$")
	public void enterCableLengthValue() {
		new CalculatorPage().enterCableLengthValue();

	}

	@And("^Validate Cable Length$")
	public void validateCableLength() {
		new CalculatorPage().validateCableLength();

	}

	@And("^Get Coordinates$")
	public void getCoordinates() {
		new CalculatorPage().getCoordinatesSeeAllBtn();
	}

	@And("^User Clicks on Formula btn$")
	public void clickOnFormulaBtn() {
		new CalculatorPage().clickOnFormulaBtn();

	}

	@And("^User Clicks on Reset Btn$")
	public void clickOnResetBtn() {
		new CalculatorPage().clickOnResetBtn();

	}

	@And("^User Clicks on Cable Length$")
	public void clickOnCableLengthBtn() {
		new CalculatorPage().clickOnCableLengthBtn();

	}

	@And("^User Clicks on Cost of Electric Power btn$")
	public void clickOnCostOfElectricalPowerBtn() {
		new CalculatorPage().clickOnCostOfElectricalPowerBtn();

	}

	@And("^User clicks on Active Power$")
	public void clickOnActivePowerBtn() {
		new CalculatorPage().clickOnActivePowerbtn();

	}

	@And("^User clicks on Apparent Power$")
	public void clickOnApparentPowerBtn() {
		new CalculatorPage().clickOnApparentPowerbtn();

	}

	@And("^User clicks on Ohms Law$")
	public void clickOnOhmsLawBtn() {
		new CalculatorPage().clickOnOhmsLawbtn();

	}

	@And("^User clicks on Interval$")
	public void clickOnIntervalBtn() {
		new CalculatorPage().clickOnIntervalbtn();

	}

	@And("^User Clicks on Reactive power$")
	public void clickOnReactivePowerBtn() {
		new CalculatorPage().clickOnReactivePowerbtn();

	}

	@And("^User clicks on Capacitor Capacitance$")
	public void clickOnCapacitorCapacitanceBtn() {
		new CalculatorPage().clickOnCapacitorCapacitancebtn();

	}

	@And("^User Enters Values for calculating Apparent Power$")
	public void enterApparentPowerValue() {
		new CalculatorPage().enterApparentPowerValue3Ph();

	}

	@And("^User Enters Values for calculating Capacitor Capacitance$")
	public void enterCapacitanceCapacitorValue() {
		new CalculatorPage().enterCapacitorCapacitanceValue();

	}

	@And("^User Enters Values for calculating Reactive Power$")
	public void enterReactivePowerValue() {
		new CalculatorPage().enterReactivePowerValue();

	}

	@And("^User Enters Values for calculating cost of Electrical Power$")
	public void enterCostofElectricalPowerValue() {
		new CalculatorPage().enterCostofElectricalPowerValue();

	}

	@Then("^Validate Cost of Electrical Power$")
	public void validateCostOfElectricalPower() {
		new CalculatorPage().validateCostOfElectricalPower();
	}

	@And("^User Enters Values for calculating Active Power 3Ph$")
	public void enterActivePowerValue3Ph() {
		new CalculatorPage().enterActivePowerValue3Ph();

	}

	@And("^User Enters Values for calculating Interval$")
	public void enterIntervalValue() {
		new CalculatorPage().enterIntervalValue();

	}

	@And("^User Enters Values for calculating Active Power One Ph$")
	public void enterActivePowerValue1Ph() {
		new CalculatorPage().enterActivePowerValue1Ph();

	}

	@And("^User Enters Values for calculating Ohms Voltage$")
	public void enterOhmsValues() {
		new CalculatorPage().enterOhmsLawUIR();

	}

	@And("^User Enters Values for calculating Capacitor Power$")
	public void enterCapacitorValues() {
		new CalculatorPage().enterCapacitorPowerValue();

	}

	@Then("^Validate Capacitor Power$")
	public void validateCapacitorPower() {
		new CalculatorPage().validateCapacitorPowerValue();
	}

	@Then("^Validate Active Power 3Ph$")
	public void validateActivePower3Ph() {
		new CalculatorPage().validateActivePower3Ph();
	}

	@Then("^Validate Active Power 1Ph$")
	public void validateActivePower1Ph() {
		new CalculatorPage().validateActivePower1Ph();
	}

	@Then("^Validate Capacitor Capacitance$")
	public void validateCapacitorCapacitance() {
		new CalculatorPage().validateCapacitanceValue();
	}

	@Then("^Validate Reactive Power$")
	public void validateReactivePower() {
		new CalculatorPage().validateReactivePower();
	}

	@Then("^Validate Interval$")
	public void validateInterval() {
		new CalculatorPage().validateInterval();
	}

	@Then("^Validate Ohms Voltage$")
	public void validateOhmsLawUIR() {
		new CalculatorPage().validateOhmsLawUIR();
	}

	@Then("^Validate Apparent Power$")
	public void validateApparentPower() {
		new CalculatorPage().validateApparentPower3Ph();
	}

	@Then("^Validate Formula Btn$")
	public void validateFormulaBtn() {
		new CalculatorPage().validateFormulaBtn();
	}

	@Then("^Validate Reset Btn$")
	public void validateResetBtn() {
		new CalculatorPage().validateResetBtn();
	}

	@And("^User clicks on Capacitor Power$")
	public void userClicksOnCapacitorPower() {
		new CalculatorPage().clickOnCapacitorPowerbtn();
		
	}
}
