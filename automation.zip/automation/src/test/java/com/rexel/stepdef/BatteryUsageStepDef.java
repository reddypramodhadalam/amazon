package com.rexel.stepdef;

import com.rexel.pages.BatteryUsagePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BatteryUsageStepDef {
	
	@When("^User run the application in background$")
	public void userRunTheApplicationInBackground() {
		new BatteryUsagePage().runAppInBackground();
	}
	
	@Then("^Verify the battery usage should be under permissible value$")
	public void verifyThatBatteryUsageShouldBeUnderPermissibleValue() {
		new BatteryUsagePage().validateBatteryUsageWhenApplicationIsRunningInBackground();
	}

}