package com.rexel.stepdef;

import com.rexel.pages.SettingsPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SettingsStepDef {
	 
	@And("^User clicked on settings tab$")
	public void userClickedOnSettingsTab() {
		new SettingsPage().clickOnSettingsTab();
	}
	
	@Then("^Settings tab should be displayed$")
	public void settingTabShouldBeDisplayed() {
		new SettingsPage().validateSettingsPage();
	}
	
	@And("^Settings tab should have scan beep toggle button$")
	public void settingsTabShouldHaveScanBeepToggelButton() {
		new SettingsPage().validateScanBeepButton();
	}
	
	@And("^Settings tab should have scan vibrate toggle button$")
	public void settingsTabShouldHaveScanVibrateToggleButton() {
		new SettingsPage().validateScanVibrateButton();
	}
	
	@And("^Settings tab should have allow repeat scanning toggle button$")
	public void settingsTabShouldHaveAllowRepeatScanningToggleButton() {
		new SettingsPage().validateAllowRepeatScanButton();
	}
	
	@And("^User should be able to adjust scanning speed$")
	public void userShouldBeAbleToAdjustScanningSpeed() {
		new SettingsPage().adjustScanningSpeed();
	}
	
	@And("^Settings tab should have dark mode toggle button$")
	public void settingsTabShouldHaveDarkModeToggleButton() {
		new SettingsPage().validateDarkModeButton();
	}
	
	@When("^User clicks on logout button$")
	public void userClicksOnLogoutButton() {
		new SettingsPage().clickOnLogoutButton();
	}
	
	@And("^User clicks on close catalog button")
	public void userClickOnCloseCatalogBtn() {
		new SettingsPage().clickOnCloseCatalog();
	}
	
	@Then("^Sign in button should be displayed$")
	public void signInButtonShouldBeDisplayed() {
		new SettingsPage().validateSignInButton();
	}
	
	@When("^User clicks on sign in button$")
	public void userClicksOnSignInButton() {
		new SettingsPage().clickOnSignInButton();
	}
	
	@When("^User clicked on Account tab$")
	public void userClickedOnAccountTab() {
		new SettingsPage().clickOnAccountTab();
	}
	
	@Then("^Account tab should be displayed$")
	public void accountTabShouldBeDisplayed() {
		new SettingsPage().validateAccountTabTitle();
	}
	
	@And("^Account should have five sections with all buttons$")
	public void accountShouldHaveFiveSections() {
		new SettingsPage().validateSectionsInAccountTab();
	}
	
	@When("^User clicks on app settings tab$")
	public void userClicksOnAppSettingsTab() {
		new SettingsPage().clickOnSettingTabInAppSettings();
	}
	
	@Then("^Tutorial tab should be displayed$")
	public void tutorialTabShouldBeDisplayed() {
		new SettingsPage().validateTutorialTabInSettingsScreen();
	}
	
	@And("^Rate in app store tab should be displayed$")
	public void rateInAppStoreTabShouldBeDisplayed() {
		new SettingsPage().validateRateInAppStoreTabInSettingsScreen();
	}
	
	@And("^Requests observer tab should be displayed$")
	public void requestsObserverTabShouldBeDisplayed() {
		new SettingsPage().validateRequestsObserverTabInSettingsScreen();
	}
}
