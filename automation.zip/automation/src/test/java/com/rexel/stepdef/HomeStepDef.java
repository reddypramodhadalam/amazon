package com.rexel.stepdef;

import com.rexel.pages.HomePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomeStepDef {
	
	@And("^Home page should have hamburger menu and cart$")
	public void homePageShouldHaveHamburgerMenuAndCart() {
		new HomePage().validateHomePageElements();
	}
	
	@And("^Memory usage and cache should be under permissible value$")
	public void memoryUsageAndCacheShouldBeUnderPermissibleValue() {
		new HomePage().validateMemoryUsageAfterLogin();
	}
}
