package com.rexel.stepdef;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;

import com.rexel.utils.DriverManager;
import com.rexel.utils.ServerManager;
import com.rexel.utils.TestUtils;
import com.rexel.utils.VideoManager;

import java.io.IOException;

public class Hooks {
	
	TestUtils utils = new TestUtils();

	@Before
	public void initialize(Scenario scenario) throws Exception {

		String testName = scenario.getName();
		utils.log().info(testName);
		//new ServerManager().startServer();
		new DriverManager().initializeDriver(testName);
		// new VideoManager().startRecording();
	}

	@After
	public void quit(Scenario scenario) throws IOException {
		if (scenario.isFailed()) {
			byte[] screenshot = new DriverManager().getDriver().getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", scenario.getName());
		}

		// new VideoManager().stopRecording(scenario.getName());
		DriverManager driverManager = new DriverManager();
		if (driverManager.getDriver() != null) {
			driverManager.getDriver().quit();
			driverManager.setDriver(null);
		}

//		ServerManager serverManager = new ServerManager();
//		if (serverManager.getServer() != null) {
//			serverManager.getServer().stop();
//		}

	}
}