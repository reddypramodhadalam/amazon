package com.rexel.stepdef;


import com.rexel.pages.PerformancePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PerformanceStepDef {
	
	@Then("^Clicks on login button to check performance$")
	public void clicksOnLoginButtonToCheckPerformance() {
		new PerformancePage().clickOnSignInButton();
	}
	
	@And("^Time taken for login should be with in the time specified$")
	public void timeTakenForLoginShouldBeWithInTheTimeSpecified() {
		new PerformancePage().validateTimeTakenForLogin();
	}
	
	@When("^User clicks on scan tab to check performance$")
	public void userClicksOnScanTabToCheckPerformance() {
		new PerformancePage().clickingOnScannerTabForPerformance();
	}
	
	@Then("^Time taken for navigating to scanner screen from home page should be with in the time specified$")
	public void timeTakenForNavigatingToScannerScreenFromHomePageShouldBeWithInTheTimeSpecified() {
		new PerformancePage().validateTimeTakenForNavigatingToScannerScreen();
	}
	
	@When("^User clicks on settings tab to check performance$")
	public void userClicksOnSettingTabToCheckPerformance() {
		new PerformancePage().clickingOnSettingsTabForPerformance();
	}
	
	@Then("^Time taken for navigating to settings screen from home page should be with in the time specified$")
	public void timeTakenForNavigatingToSettingsScreenFromHomePageShouldBeWithInTheSpecifiedTime() {
		new PerformancePage().validateTimeTakenForNavigatingToSettingsScreen();
	}
	
	@When("^User clicks on logout button after navigating to settings tab for checking performance$")
	public void userClicksOnLogoutButtonAfterNavigatingToSettingsTabForCheckingPerformance() {
		new PerformancePage().clickingOnLogoutButton();
	}
	
	@Then("^Time taken to logout should be with in the time specified$")
	public void timeTakenToLogoutShouldBeWithInTheTimeSpecified() {
		new PerformancePage().validateTimeTakenForLogout();
	}
	
	@Given("^Rexel app is launched on the device$")
	public void rexelAppIsLaunchedOnTheDevice() {
		new PerformancePage().validateTutorialCloseButtonInLaunchScreen();
	}
	
	@When("^User navigates to Login screen$")
	public void userNavigatesToLoginScreen() {
		new PerformancePage().clickingOnCloseButton();
	}
	
	@Then("^Time taken to navigate to login screen should be with in the time specified$")
	public void timeTakenToNavigateToLoginScreenShouldBeWithInTheTimeSpecified() {
		new PerformancePage().validateTimeTakenForNavigatingToLoginScreen();
	}
	
	@And("^Enters product name to search to measure time taken$")
	public void entersProductNameToSearchToMeasureTimeTaken() {
		new PerformancePage().enterSearchTermToMeasureTime();
	}
	
	@Then("^Time taken to display search results should be with in the time specified$")
	public void timeTakenToDisplaySearchResultsShouldBeWithInTheTimeSpecified() {
		new PerformancePage().validateTimeTakenForDisplayingSearchResults();
	}
	
	@When("^User run the application at background$")
	public void userRunTheApplicationAtBackground() {
		new PerformancePage().runningApplicationInBackground();
	}
	
	@Then("^App should be working as normal when launched again$")
	public void appShouldBeWorkingAsNormalWhenLaunchedAgain() {
		new PerformancePage().validateAppRunningNormallyAfterLaunchingAgain();
	}
	
	@And("^Clicks on login button to measure time taken$")
	public void clicksOnLoginButtonToMeasureTimeTaken() {
		new PerformancePage().clickOnSignButtonToSeeErrorMessage();
	}
	
	@Then("^Error message pop up should be displayed with in the time specified$")
	public void errorMessagePopUpShouldBeDisplayedWithInTheTimeSpecified() {
		new PerformancePage().validateTimeTakenForDisplayingErrorMessageDuringLogin();
	}
}