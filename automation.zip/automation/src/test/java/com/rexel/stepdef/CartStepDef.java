package com.rexel.stepdef;

import com.rexel.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CartStepDef {
	
	@When("^Users adds a product to cart$")
	public void userAddsProductToCart() {
		new CartPage().addProductToCart();
	}
	
	@And("^Navigates to cart$")
	public void navigatesToCart() {
		new CartPage().navigateToCartTab();
	}
	
	@Then("^Product should be displayed in cart$")
	public void productShouldBeDisplayedInCart() {
		new CartPage().validateProductInCart();
	}
	
	@And("^Login to continue empty cart button should be displayed$")
	public void loginToContinueEmptyCartButtonShouldBeDisplayed() {
		new CartPage().validateButtonInCartWithoutLogin();
	}
	
	@When("^User Clicks on empty cart button$")
	public void userClicksOnEmptyCartButton() {
		new CartPage().clickingOnEmptyCartButton();
	}
	
	@Then("^Yes empty cart and cancel buttons should be displayed$")
	public void yesEmptyCartAndCancelButtonsShouldBeDisplayed() {
		new CartPage().validateEmptyCartPopUpButtons();
	}
	
	@When("^User clicks on yes button in pop up$")
	public void userClicksOnYesButtonInPopUp() {
		new CartPage().clickingOnYesButton();
	}
	
	@Then("^Product should be deleted from cart$")
	public void productShouldBeDeletedFromCart() {
		new CartPage().validateProductDeleteMessage();
	}
	
	@And("^Start shopping button should be displayed$")
	public void startShoppingButtonShouldBeDisplayed() {
		new CartPage().validateStartShoppingButton();
	}
	
	@And("^Empty cart button should not be displayed$")
	public void emptyCartButtonShouldNotBeDisplayed() {
		new CartPage().validateEmptyCartButtonAfterDeletingProductsFromCart();
	}
	
	@When("^Users adds a product to cart without login$")
	public void usersAddsAProductToCartWithoutLogin() {
		new CartPage().addProductToCartWithoutLogin();
	}
}
