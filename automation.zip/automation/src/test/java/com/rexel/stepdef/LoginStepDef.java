package com.rexel.stepdef;

import java.io.IOException;

import com.rexel.pages.LoginPage;
import com.rexel.pages.ScannerPage;
import com.rexel.runners.RunnerBase;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDef {

	@Given("^Rexel app is launched$")
	public void rexelAppIsLaunched() throws InterruptedException {
		new LoginPage().clickOnCloseButton();
	}

	@When("^User enters username and password$")
	public void userEntersUsernameAndPassword() throws InterruptedException {
		new LoginPage().enterUserName();
		new LoginPage().enterPassword();
	}

	@Then("^User should see forgot username forgot password sign in remember username and register button$")
	public void userShouldSeeForgotUsernameForgotPasswordSignInAndRegisterButton() {
		new LoginPage().validateLoginPage();
	}

	@And("^Clicks on login button$")
	public void clicksOnLoginButton() {
		new LoginPage().clickOnSignInButton();
	}

	@And("^Clicks on Allow Location$")
	public void clicksOnAllowLocation() {
		new LoginPage().clickOnAllowLocation();
	}

	@Then("^Home screen should be displayed$")
	public void homeScreenShouldBeDisplayed() {
		new LoginPage().validateStartShoppingButton();
	}

	@When("^User enters invalid username and password$")
	public void userEntersInvalidUsernameAndPassword() {
		new LoginPage().enterInvalidCredentials();
	}

	@Then("^Invalid credentials pop up should be displayed$")
	public void invalidCredentialsPopUpShouldBeDisplayed() {
		new LoginPage().validateInvalidCredentialsPopUp();
	}

	@When("^User enters disabled username and password$")
	public void userEntersDisabledUsernameAndPassword() {
		new LoginPage().enterDisabledUserCredentials();
	}

	@Then("^Disabled user pop up should be displayed$")
	public void disabledUserPopUpShouldBeDisplayed() {
		new LoginPage().validateDisabledUserPopUp();
	}

	@When("^User closes the login screen$")
	public void userClosesLoginScreen() {
		new LoginPage().closeLoginScreen();
	}

	@Then("^Login screen should be displayed$")
	public void loginScreenShouldBeDisplayed() {
		new LoginPage().validateLoginScreen();
	}

	@When("^User clicks on start shopping button$")
	public void userClickedOnStartShoppingButton() {
		new LoginPage().clickOnStartShopping();
	}

	@When("^User clicks on tutorial button$")
	public void userClicksOnTutorialButton() {
		new LoginPage().clickOnTutorialButton();
	}

	@Then("^Tutorial screen should be displayed$")
	public void tutorialScreenShouldBeDisplayed() {
		new LoginPage().validateTutorialScreenDisplayed();
	}

	@When("^User closes the tutorial screen$")
	public void userClosesTheTutorialScreen() {
		new LoginPage().clickOnCloseButtonInTutorialScreen();
	}

	@Then("^Home page should be displayed$")
	public void homePageShouldBeDisplayed() {
		new LoginPage().validateHomePage();
	}

	@Then("^User can see webshop scanner and settings tabs$")
	public void userCanSeeWebshopScannerAndSettingsTabs() {
		new LoginPage().validateTabsAfterLaunching();
	}

	@When("^User enters blocked username and password$")
	public void userEntersBlockedUsernameAndPassword() {
		new LoginPage().enterBlockedCredentials();
	}

	@Then("^Blocked credentials pop up should be displayed$")
	public void blockedCredentialsPopUpShouldBeDisplayed() {
		new LoginPage().validateInvalidCredentialsPopUp();
	}

	@Then("^User clicks on scanner tab$")
	public void clickOnScanTab() {
		new LoginPage().clickOnScanTab();
	}

	@And("^User clicks on register button$")
	public void clickOnRegisterBtn() {
		new LoginPage().clickOnRegisterBtn();
	}

	@And("^Registration screen should be displayed$")
	public void validateRegisterScreen() {
		new LoginPage().validateRegisterScreen();
	}
	
	@Then("^User can see webshop scanner calculator and settings tabs$")
	public void userCanSeeWebshopScannerCalculatorAndSettingsTabs() {
		new LoginPage().validateFourTabsAfterLaunching();
	}
	
	@Then("^User can see webshop search scanner cart and settings tabs$")
	public void userCanSeeWebshopSearchScannerCartAndSettingsTabs() {
		new LoginPage().validateFiveTabsAfterLaunching();
	}
	
	@Then("^CPU usage should be under permissible value$")
	public void cpuUageShouldBeUnderPermissibleValue() throws NumberFormatException, IOException {
		if(RunnerBase.platform.equalsIgnoreCase("Android")) {
			new LoginPage().getCpuUsageForAndroid();
		} else {
			new LoginPage().validateCpuUsageIos();
		}	
	}
	
	@Then("^GPU usage should be under permissible value$")
	public void gpuUageShouldBeUnderPermissibleValue() {
		new LoginPage().getGpuUsageAndroid();
	}
	
	@Given("^User switches to 2G network$")
	public void userSwitchesTo2GNetwork() {
		new LoginPage().updateNetworkCondition();
	}
	
	@Then("^Application should be launched$")
	public void applicationShouldBeLaunched() {
		new LoginPage().validateLoginPageDisplayed();
	}
	
	@Then("^Battery usage should be under permissible value$")
	public void batteryUsageShouldBeUnderPermissibleValue() throws NumberFormatException, IOException {
		if(RunnerBase.platform.equalsIgnoreCase("Android")) {
			new LoginPage().getBatteryUsageForAndroid();
		} else {
			new LoginPage().getBatteryStatusIosApp();
		}	
	}
	
	@Then("^Memory usage should be under permissible value$")
	public void memoryUsageShouldBeUnderPermissibleValue() throws NumberFormatException, IOException {
		new LoginPage().getMemoryInfoForAndroid();
	}
	
	@When("^User enters trade username and password$")
	public void userEntersTradeUsernameAndPassword() {
		new LoginPage().loginWithUxTradeUser();
		new LoginPage().enterPassword();
	}
}
