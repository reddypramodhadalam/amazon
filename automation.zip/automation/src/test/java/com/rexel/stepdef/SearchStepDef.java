package com.rexel.stepdef;

import com.rexel.pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchStepDef {
	
	@When("^User navigates to search tab$")
	public void userNavigatesToSearchTab() {
		new SearchPage().navigateToSearchTab();
	}
	
	@Then("^Already bought should be displayed$")
	public void topOrderCategoriesShouldBeDisplayed() {
		new SearchPage().validateMostOrderedCategories();
	}
	
	@And("^Scrolls to the bottom of the screen$")
	public void scrollsToTheBottomOfTheScreen() {
		new SearchPage().scrollToViewEntireCategory();
	}
	
	@Then("^View all categories button should be displayed$")
	public void viewAllCategoriesButtonShouldBeDisplayed() {
		new SearchPage().validateViewEntireCategory();
	}
	
	@And("^Enters product name to search$")
	public void entersProductNameToSearch() {
		new SearchPage().enterProductNameToSearch();
	}
	
	@Then("^Search results related to searched product should be displayed$")
	public void searchResultsRelatedToSearchedProductShouldBeDisplayed() {
		new SearchPage().validateSearchResults();
	}
	
	@Then("^Top order categories should not be displayed$")
	public void topOrderCategoriesShouldNotBeDisplayed() {
		new SearchPage().validateMostOrderedCategoriesNotDisplayed();
	}
	
	@Then("^Search results related to searched product should be displayed without login$")
	public void searchResultsRelatedToSearchedProductShouldBeDisplayedWithoutLogin() {
		new SearchPage().validateSearchResultsWithoutLogin();
	}
	
	@And("^Enters product name to search bulk savings$")
	public void entersProductNameToSearchBulkSavings() {
		new SearchPage().enterBulkSavingsProductNameToSearch();
	}
	
	@Then("^Search results related with bulk savings should be displayed$")
	public void searchResultsRelatedWithBulkSavingShouldBeDisplayed() {
		new SearchPage().validateBulkSavingProductSearchResults();
	}
	
	@And("^Upon clicking on bulk saving it should show tiered pricing$")
	public void uponClickingOnBulkSavingItShouldShowTieredPricing() {
		new SearchPage().clickOnBulkSavings();
		new SearchPage().validateTieredPricingInPlpPage();
	}
	
	@When("^User clicks on close button of pricing sheet$")
	public void userClicksOnCloseButtonOfPricingSheet() {
		new SearchPage().clickingOnCloseButton();
	}
	
	@And("^Clicks on the first product with bulk savings$")
	public void clicksOnTheFirstProductWithBulkSavings() {
		new SearchPage().clickingOnFirstProductInSearchResults();
	}
	
	@Then("^PDP page also should display tiered pricing$")
	public void pdpPageAlsoShouldDisplayTieredPricing() {
		new SearchPage().validatePdpResults();
	}
	
	@When("^Clicks on the first product$")
	public void clicksOnTheFirstProduct() {
		new SearchPage().clickingOnFirstProduct();
	}
	
	@Then("^PDP page should display product type$")
	public void pdpPageShouldDisplayProductType() {
		new SearchPage().validateProductTypeInPdp();
	}
}
