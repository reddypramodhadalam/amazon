const STORAGE_KEY = 'recordedData';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'record-action' && message.action) {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      let data = result[STORAGE_KEY] || { url: '', actions: [], scenarioName: '' };
      data.actions.push(message.action);
      chrome.storage.local.set({ [STORAGE_KEY]: data });
    });
  } else if (message.type === 'clear-actions') {
    chrome.storage.local.set({ [STORAGE_KEY]: { url: '', actions: [], scenarioName: '' } });
  } else if (message.type === 'get-actions') {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      sendResponse(result[STORAGE_KEY] || { url: '', actions: [], scenarioName: '' });
    });
    return true;
  } else if (message.type === 'set-url' && message.url) {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      let data = result[STORAGE_KEY] || { url: '', actions: [], scenarioName: '' };
      data.url = message.url;
      data.actions = [];
      chrome.storage.local.set({ [STORAGE_KEY]: data });
    });
  } else if (message.type === 'set-scenario-name' && message.scenarioName) {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      let data = result[STORAGE_KEY] || { url: '', actions: [], scenarioName: '' };
      data.scenarioName = message.scenarioName;
      chrome.storage.local.set({ [STORAGE_KEY]: data }, () => {
        sendResponse({ success: true });
      });
    });
    return true;
  }
});