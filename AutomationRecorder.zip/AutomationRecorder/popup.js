const urlInput = document.getElementById('url-input');
const loadUrlButton = document.getElementById('load-url-button');
const actionsListEl = document.getElementById('actionsList');
const clearBtn = document.getElementById('clearBtn');
const generateBtn = document.getElementById('generateBtn');
const codeOutput = document.getElementById('codeOutput');
const scenarioInput = document.getElementById('scenarioInput');
const scenarioBtn = document.getElementById('scenarioBtn');

let currentData = null;

function renderActions(actions) {
  actionsListEl.innerHTML = '';
  if (!actions.length) {
    const li = document.createElement('li');
    li.textContent = '(No actions recorded)';
    actionsListEl.appendChild(li);
    clearBtn.disabled = true;
    generateBtn.disabled = true;
    codeOutput.style.display = 'none';
    return;
  }
  actions.forEach((action, i) => {
    const li = document.createElement('li');
    li.textContent = `${i + 1}. Type: ${action.type}, XPath: ${action.xpath}${action.value ? `, Value: "${action.value}"` : ''}`;
    actionsListEl.appendChild(li);
  });
  clearBtn.disabled = false;
  generateBtn.disabled = false;
  codeOutput.style.display = 'none';
}

function loadActions() {
  chrome.runtime.sendMessage({ type: 'get-actions' }, (data) => {
    if (!data) data = { url: '', actions: [], scenarioName: '' };
    currentData = data;
    renderActions(data.actions);
    urlInput.value = data.url || '';
    scenarioInput.value = data.scenarioName || '';
  });
}

clearBtn.addEventListener('click', () => {
  if (confirm('Clear all recorded data?')) {
    chrome.runtime.sendMessage({ type: 'clear-actions' });
    currentData = { url: '', actions: [], scenarioName: '' };
    renderActions([]);
    urlInput.value = '';
    scenarioInput.value = '';
    codeOutput.style.display = 'none';
  }
});

loadUrlButton.addEventListener('click', () => {
  const url = urlInput.value.trim();
  if (!url) {
    alert('Please enter a URL to load');
    return;
  }
  chrome.runtime.sendMessage({ type: 'set-url', url: url });
  chrome.tabs.create({ url: url });
  currentData = { url: url, actions: [], scenarioName: scenarioInput.value.trim() };
  renderActions([]);
  codeOutput.style.display = 'none';
});

scenarioBtn.addEventListener('click', () => {
  const scenarioName = scenarioInput.value.trim();
  if (!scenarioName) {
    alert('Please enter a scenario name.');
    return;
  }

  chrome.runtime.sendMessage({ type: 'set-scenario-name', scenarioName }, () => {
    currentData.scenarioName = scenarioName;  // ✅ Update local data object
    alert('Scenario name saved.');
  });
});


function downloadJSON(data) {
  const output = {
    scenarioName: data.scenarioName || '',
    url: data.url,
    actions: data.actions
  };
  const jsonStr = JSON.stringify(output, null, 2);
  codeOutput.textContent = jsonStr;
  codeOutput.style.display = 'block';

  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'recorded_actions.json';
  a.click();
  URL.revokeObjectURL(url);
}

generateBtn.addEventListener('click', () => {
  if (!currentData || !currentData.actions || currentData.actions.length === 0) {
    alert('No recorded actions to generate JSON.');
    return;
  }
  downloadJSON(currentData);
});

window.onload = loadActions;