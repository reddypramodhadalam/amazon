(function() {
  function getXPath(element) {
    if (!element) return null;

    if (element.id) {
      const idValue = element.id;
      const elemsWithId = element.ownerDocument.querySelectorAll(`#${CSS.escape(idValue)}`);
      if (elemsWithId.length === 1) {
        return `//*[@id="${idValue}"]`;
      }
    }

    function getElementIdx(el) {
      let index = 1;
      let sibling = el.previousSibling;
      while (sibling) {
        if (sibling.nodeType === 1 && sibling.nodeName === el.nodeName) {
          index++;
        }
        sibling = sibling.previousSibling;
      }
      return index;
    }

    let paths = [];
    let currentElem = element;
    let foundUniqueIdAncestor = null;
    while (currentElem && currentElem.nodeType === 1) {
      if (currentElem.id) {
        const idVal = currentElem.id;
        const elemsWithId = element.ownerDocument.querySelectorAll(`#${CSS.escape(idVal)}`);
        if (elemsWithId.length === 1) {
          foundUniqueIdAncestor = currentElem;
          break;
        }
      }
      currentElem = currentElem.parentNode;
    }

    currentElem = element;
    if (foundUniqueIdAncestor) {
      while (currentElem !== foundUniqueIdAncestor) {
        const tagName = currentElem.nodeName.toLowerCase();
        const idx = getElementIdx(currentElem);
        const part = idx > 1 ? `${tagName}[${idx}]` : tagName;
        paths.unshift(part);
        currentElem = currentElem.parentNode;
      }
      return `//*[@id="${foundUniqueIdAncestor.id}"]/${paths.join('/')}`;
    } else {
      currentElem = element;
      paths = [];
      while (currentElem && currentElem.nodeType === 1) {
        const tagName = currentElem.nodeName.toLowerCase();
        const idx = getElementIdx(currentElem);
        const part = idx > 1 ? `${tagName}[${idx}]` : tagName;
        paths.unshift(part);
        currentElem = currentElem.parentNode;
      }
      return '/' + paths.join('/');
    }
  }

  function sendAction(action) {
    chrome.runtime.sendMessage({ type: 'record-action', action });
  }

  function onClick(e) {
    if (e.button !== 0 || e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;

    const selector = getXPath(e.target);
    let actionType = 'click';
    const elementName = e.target.name || e.target.id || e.target.className || ''; // Capture name, id, or class
    if (e.target.tagName.toLowerCase() === 'button') {
      actionType = 'button';
    }
    const action = {
      type: actionType,
      xpath: selector,
      name: elementName, // Include the name, id, or class in the action
      timestamp: Date.now()
    };
    sendAction(action);
  }

  const inputTimers = new Map();
  const inputValues = new Map();

  function sendInputAction(el, selector) {
    const value = inputValues.get(el) || '';
    const elementName = el.name || el.id || el.className || ''; // Capture name, id, or class
    const action = {
      type: 'input',
      xpath: selector,
      value: value,
      name: elementName, // Include the name, id, or class in the action
      timestamp: Date.now()
    };
    chrome.runtime.sendMessage({ type: 'record-action', action });
    inputValues.delete(el);
    inputTimers.delete(el);
  }

  function onInput(e) {
    const el = e.target;
    if (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA' && !el.isContentEditable) return;

    const selector = getXPath(el);
    inputValues.set(el, el.value || el.textContent || '');

 const elementName = el.name || el.id || el.className || ''; // Capture name, id, or class
    const action = {
      type: 'input',
      xpath: selector,
      value: value,
      name: elementName, // Include the name, id, or class in the action
      timestamp: Date.now()
    };
    chrome.runtime.sendMessage({ type: 'record-action', action });
    inputValues.delete(el);
    inputTimers.delete(el);
  }

  function onBlur(e) {
    const el = e.target;
    if (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA' && !el.isContentEditable) return;

    const selector = getXPath(el);
    if (inputTimers.has(el)) {
      clearTimeout(inputTimers.get(el));
      sendInputAction(el, selector);
    } else if (inputValues.has(el)) {
      sendInputAction(el, selector);
    }
  }

  document.addEventListener('click', onClick, true);
  document.addEventListener('input', onInput, true);
  document.addEventListener('blur', onBlur, true);
})();