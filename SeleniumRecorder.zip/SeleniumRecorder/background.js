const STORAGE_KEY = 'recordedActions';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'record-action' && message.action) {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      let actions = result[STORAGE_KEY] || [];
      actions.push(message.action);
      chrome.storage.local.set({ [STORAGE_KEY]: actions });
    });
  } else if (message.type === 'clear-actions') {
    chrome.storage.local.set({ [STORAGE_KEY]: [] });
  } else if (message.type === 'get-actions') {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      sendResponse({ actions: result[STORAGE_KEY] || [] });
    });
    return true; // asynchronous response
  }
});