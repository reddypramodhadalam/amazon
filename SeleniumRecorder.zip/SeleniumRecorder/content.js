// Content script injected into all pages to capture click and input events using improved XPath selectors

(function() {
  function getXPath(element) {
    if (element.id) {
      // Use id attribute for short unique XPath
      return `//*[@id="${element.id}"]`;
    }

    function hasUniqueAttribute(el, attr) {
      if (!el.hasAttribute(attr)) return false;
      const value = el.getAttribute(attr);
      const elements = el.ownerDocument.querySelectorAll(`[${attr}="${value}"]`);
      return elements.length === 1;
    }

    if (hasUniqueAttribute(element, 'name')) {
      return `//*[@name="${element.getAttribute('name')}"]`;
    }

    function getElementIdx(el) {
      let count = 0;
      const siblings = el.parentNode ? el.parentNode.children : [];
      for (let i = 0; i < siblings.length; i++) {
        const sibling = siblings[i];
        if (sibling.nodeName === el.nodeName) {
          count++;
        }
        if (sibling === el) {
          return count;
        }
      }
      return 1;
    }

    let paths = [];

    for (; element && element.nodeType === 1; element = element.parentNode) {
      let tagName = element.nodeName.toLowerCase();

      if (element.id) {
        paths.unshift(`//*[@id="${element.id}"]`);
        break;
      } else {
        let index = getElementIdx(element);
        let pathIndex = (index > 1) ? `[${index}]` : '';
        paths.unshift(`${tagName}${pathIndex}`);
      }
    }

    return paths.length ? '/' + paths.join('/') : null;
  }

  function sendAction(action) {
    chrome.runtime.sendMessage({ type: 'record-action', action });
  }

  function onClick(e) {
    if (e.button !== 0 || e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
    const selector = getXPath(e.target);
    const action = {
      type: 'click',
      selector: selector,
      timestamp: Date.now()
    };
    sendAction(action);
  }

  function onInput(e) {
    const el = e.target;
    if (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA' && el.isContentEditable !== true) return;

    const selector = getXPath(el);
    const value = el.value || el.textContent || '';

    const action = {
      type: 'input',
      selector: selector,
      value: value,
      timestamp: Date.now()
    };
    sendAction(action);
  }

  document.addEventListener('click', onClick, true);
  document.addEventListener('input', onInput, true);
})();