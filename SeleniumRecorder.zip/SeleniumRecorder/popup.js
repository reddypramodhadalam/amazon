// Popup script to manage URL input, recorded actions, and generate Selenium POM Java code with XPath selectors

const urlInput = document.getElementById('url-input');
const loadUrlButton = document.getElementById('load-url-button');
const actionsListEl = document.getElementById('actionsList');
const clearBtn = document.getElementById('clearBtn');
const generateBtn = document.getElementById('generateBtn');
const codeOutput = document.getElementById('codeOutput');

function sanitizeVarName(sel) {
  let s = sel.replace(/[^a-zA-Z0-9]/g, '_');
  s = s.replace(/_{2,}/g, '_');
  s = s.replace(/^_+|_+$/g, '');
  if (!s) s = 'elem';
  return s;
}

// Render recorded actions list and update button states
function renderActions(actions) {
  actionsListEl.innerHTML = '';
  if (!actions.length) {
    const li = document.createElement('li');
    li.textContent = '(No actions recorded)';
    actionsListEl.appendChild(li);
    clearBtn.disabled = true;
    generateBtn.disabled = true;
    codeOutput.style.display = 'none';
    return;
  }
  actions.forEach((action, i) => {
    const li = document.createElement('li');
    if (action.type === 'click') {
      li.textContent = `${i + 1}. Click: ${action.selector}`;
    } else if (action.type === 'input') {
      li.textContent = `${i + 1}. Input "${action.value}": ${action.selector}`;
    } else {
      li.textContent = `${i + 1}. Unknown action`;
    }
    actionsListEl.appendChild(li);
  });
  clearBtn.disabled = false;
  generateBtn.disabled = false;
  codeOutput.style.display = 'none';
}

// Load recorded actions from chrome.storage and render
function loadActions() {
  chrome.runtime.sendMessage({ type: 'get-actions' }, (response) => {
    const actions = response.actions || [];
    renderActions(actions);
  });
}

// Clear all recorded actions
clearBtn.addEventListener('click', () => {
  if (confirm('Clear all recorded actions?')) {
    chrome.runtime.sendMessage({ type: 'clear-actions' });
    loadActions();
  }
});

// Load URL in a new tab on button click
loadUrlButton.addEventListener('click', () => {
  const url = urlInput.value.trim();
  if (!url) {
    alert('Please enter a URL to load');
    return;
  }
  // Open new tab with the entered URL
  chrome.tabs.create({ url: url }, (tab) => {
    // Optionally, you can send message to start recording after tab loads
    // But content script auto-starts recording upon injection as per current design
  });
});

// Trigger download of multiple files
function downloadFiles(files) {
  Object.entries(files).forEach(([filename, content]) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  });
}

// Generate Selenium POM Java code with XPath selectors from recorded actions
function generateJavaCode(actions) {
  if (actions.length === 0) {
    alert('No actions recorded.');
    return null;
  }

  const className = 'MainPage';
  const testClassName = 'MainTest';
  const packageName = 'com.example.tests';

  const pageObjectImports = [
    'import org.openqa.selenium.WebDriver;',
    'import org.openqa.selenium.WebElement;',
    'import org.openqa.selenium.support.FindBy;',
    'import org.openqa.selenium.support.PageFactory;'
  ].join('\n');

  const testImports = [
    'import org.openqa.selenium.WebDriver;',
    'import org.openqa.selenium.chrome.ChromeDriver;',
    'import org.testng.annotations.AfterClass;',
    'import org.testng.annotations.BeforeClass;',
    'import org.testng.annotations.Test;'
  ].join('\n');

  const selectorVarMap = new Map();

  actions.forEach((act) => {
    if (!selectorVarMap.has(act.selector)) {
      let baseName = sanitizeVarName(act.selector);
      let varName = baseName;
      let dupCount = 1;
      while ([...selectorVarMap.values()].includes(varName)) {
        varName = baseName + dupCount;
        dupCount++;
      }
      selectorVarMap.set(act.selector, varName);
    }
  });

  const fields = [];
  for (const [sel, varName] of selectorVarMap.entries()) {
    fields.push(`    @FindBy(xpath = "${sel}")\n    private WebElement ${varName};`);
  }

  const methods = [];
  let actionIndex = 1;
  actions.forEach((act) => {
    const varName = selectorVarMap.get(act.selector);
    if (act.type === 'click') {
      methods.push(
`    /**
     * Clicks on element: ${act.selector}
     */
    public void click_${varName}() {
        ${varName}.click();
    }`
      );
    } else if (act.type === 'input') {
      methods.push(
`    /**
     * Inputs value into element: ${act.selector}
     */
    public void set_${varName}(String value) {
        ${varName}.clear();
        ${varName}.sendKeys(value);
    }`
      );
    }
    actionIndex++;
  });

  const pageObjectCode =
`package ${packageName};

${pageObjectImports}

public class ${className} {

    private WebDriver driver;
${fields.join('\n\n')}

    public ${className}(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

${methods.join('\n\n')}
}
`;

  actionIndex = 1;
  const testMethods = [];
  actions.forEach((act) => {
    const varName = selectorVarMap.get(act.selector);
    if (act.type === 'click') {
      testMethods.push(`        page.click_${varName}(); // Action ${actionIndex}`);
    } else if (act.type === 'input') {
      const safeValue = (act.value || '').replace(/"/g, '\\"');
      testMethods.push(`        page.set_${varName}("${safeValue}"); // Action ${actionIndex}`);
    }
    actionIndex++;
  });

  // Use last loaded URL or the URL from current active tab (could enhance to store URL on recording start)
  const url = actions.length > 0 && actions[0].url ? actions[0].url : 'about:blank';

  const testClassCode =
`package ${packageName};

${testImports}

public class ${testClassName} {

    private WebDriver driver;
    private ${className} page;

    @BeforeClass
    public void setUp() {
        // Set path to chromedriver executable on your machine
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get("${url}");
        page = new ${className}(driver);
    }

    @Test
    public void testRecordedActions() {
${testMethods.join('\n')}
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
`;

  const pomXml =
`<project xmlns="http://maven.apache.org/POM/4.0.0"  
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"   
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0  
        http://maven.apache.org/xsd/maven-4.0.0.xsd">  
    <modelVersion>4.0.0</modelVersion>  
    <groupId>${packageName}</groupId>  
    <artifactId>selenium-pom</artifactId>  
    <version>1.0-SNAPSHOT</version>  
    <properties>  
        <maven.compiler.source>1.8</maven.compiler.source>  
        <maven.compiler.target>1.8</maven.compiler.target>  
    </properties>  
    <dependencies>  
        <dependency>  
            <groupId>org.seleniumhq.selenium</groupId>  
            <artifactId>selenium-java</artifactId>  
            <version>4.9.0</version>  
        </dependency>  
        <dependency>  
            <groupId>org.testng</groupId>  
            <artifactId>testng</artifactId>  
            <version>7.7.0</version>  
            <scope>test</scope>  
        </dependency>  
    </dependencies>  
    <build>  
        <plugins>  
            <plugin>  
                <groupId>org.apache.maven.plugins</groupId>  
                <artifactId>maven-surefire-plugin</artifactId>  
                <version>3.0.0-M7</version>  
                <configuration>  
                    <suiteXmlFiles>  
                        <suiteXmlFile>testng.xml</suiteXmlFile>  
                    </suiteXmlFiles>  
                </configuration>  
            </plugin>  
        </plugins>  
    </build>  
</project>`;

  const testngXml =
`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE suite SYSTEM "https://testng.org/testng-1.0.dtd">
<suite name="RecordedTestSuite">
  <test name="RecordedTest">
    <classes>
      <class name="${packageName}.${testClassName}"/>
    </classes>
  </test>
</suite>`;

  return {
    'MainPage.java': pageObjectCode,
    'MainTest.java': testClassCode,
    'pom.xml': pomXml,
    'testng.xml': testngXml
  };
}

generateBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'get-actions' }, (response) => {
    const actions = response.actions || [];
    if (actions.length === 0) {
      alert('No recorded actions found.');
      return;
    }
    const files = generateJavaCode(actions);
    if (!files) return;

    codeOutput.textContent = files['MainPage.java'];
    codeOutput.style.display = 'block';

    downloadFiles(files);
  });
});

window.onload = () => {
  loadActions();
};