// utils/xpath-utils.js

// Log when the file is loaded to help with debugging
console.log('XPath utils loaded');

/**
 * Generates a relative XPath for an element
 * @param {Element} element - The DOM element to generate XPath for
 * @returns {string} The relative XPath
 */
window.generateRelativeXPath = function(element) {
  if (!element) return null;
  
  // Check if element has an id
  if (element.id) {
    return `//*[@id="${element.id}"]`;
  }
  
  // Try to create a unique XPath using attributes
  let path = '';
  let current = element;
  
  while (current && current.nodeType === Node.ELEMENT_NODE) {
    let index = 0;
    let hasUniqueAttribute = false;
    let attributeXPath = '';
    
    // Try to use name, class, or other attributes to make the XPath more specific
    if (current.getAttribute('name')) {
      attributeXPath = `[@name="${current.getAttribute('name')}"]`;
      hasUniqueAttribute = true;
    } else if (current.className && typeof current.className === 'string' && current.className.trim()) {
      // Use the first class name for simplicity
      const className = current.className.trim().split(/\s+/)[0];
      attributeXPath = `[contains(@class, "${className}")]`;
      hasUniqueAttribute = true;
    } else if (current.getAttribute('type')) {
      attributeXPath = `[@type="${current.getAttribute('type')}"]`;
      hasUniqueAttribute = true;
    } else if (current.getAttribute('role')) {
      attributeXPath = `[@role="${current.getAttribute('role')}"]`;
      hasUniqueAttribute = true;
    }
    
    // If no unique attribute was found, use position
    if (!hasUniqueAttribute) {
      let sibling = current.previousSibling;
      
      while (sibling) {
        if (sibling.nodeType === Node.ELEMENT_NODE && sibling.tagName === current.tagName) {
          index++;
        }
        sibling = sibling.previousSibling;
      }
      
      attributeXPath = index ? `[${index + 1}]` : '';
    }
    
    const tagName = current.tagName.toLowerCase();
    path = `/${tagName}${attributeXPath}${path}`;
    
    // Don't go beyond the body
    if (current.tagName === 'BODY') {
      break;
    }
    
    current = current.parentNode;
  }
  
  return path;
};

/**
 * Gets a more specific XPath for an element based on its attributes and context
 * @param {Element} element - The DOM element
 * @returns {string} The optimized XPath
 */
window.getOptimizedXPath = function(element) {
  // Try to get a short, specific XPath
  if (element.id) {
    return `//*[@id="${element.id}"]`;
  }
  
  // For form elements, try to use name attribute
  if ((element.tagName === 'INPUT' || element.tagName === 'SELECT' || element.tagName === 'TEXTAREA') && 
      element.getAttribute('name')) {
    return `//${element.tagName.toLowerCase()}[@name="${element.getAttribute('name')}"]`;
  }
  
  // For buttons with text, use the text content
  if ((element.tagName === 'BUTTON' || element.tagName === 'A') && element.textContent.trim()) {
    const text = element.textContent.trim();
    // Escape single quotes in the text
    const escapedText = text.replace(/'/g, "\\'");
    return `//${element.tagName.toLowerCase()}[contains(text(), '${escapedText}')]`;
  }
  
  // For labels, use the text content
  if (element.tagName === 'LABEL' && element.textContent.trim()) {
    const text = element.textContent.trim();
    // Escape single quotes in the text
    const escapedText = text.replace(/'/g, "\\'");
    return `//label[contains(text(), '${escapedText}')]`;
  }
  
  // For inputs with type, use the type attribute
  if (element.tagName === 'INPUT' && element.getAttribute('type')) {
    const type = element.getAttribute('type');
    // Try to find a more specific selector
    if (element.getAttribute('placeholder')) {
      return `//input[@type='${type}' and @placeholder='${element.getAttribute('placeholder')}']`;
    }
    
    // If there are multiple inputs of this type, add position
    const sameTypeInputs = document.querySelectorAll(`input[type='${type}']`);
    if (sameTypeInputs.length > 1) {
      const index = Array.from(sameTypeInputs).indexOf(element) + 1;
      return `(//input[@type='${type}'])[${index}]`;
    }
    
    return `//input[@type='${type}']`;
  }
  
  // Fall back to relative XPath
  return window.generateRelativeXPath(element);
};

// Also provide local versions of the functions for backward compatibility
function generateRelativeXPath(element) {
  return window.generateRelativeXPath(element);
}

function getOptimizedXPath(element) {
  return window.getOptimizedXPath(element);
}

// Notify that the XPath utils are ready
console.log('XPath utils ready');