// expiration_enforcer.js
(function() {
  // Constants
  const CHECK_INTERVAL_MS = 10000; // Check every 10 seconds
  const API_KEY = "{{API_KEY}}"; // Will be replaced by the packaging script
  
  // Parse expiration from API key
  function getExpirationDate() {
    try {
      const parts = API_KEY.split('.');
      if (parts.length !== 5) return null;
      
      const expirationHex = parts[1];
      const expirationTimestamp = parseInt(expirationHex, 16);
      return new Date(expirationTimestamp * 1000);
    } catch (e) {
      console.error("Failed to parse expiration date:", e);
      return null;
    }
  }
  
  // Check if the license is expired
  function isExpired() {
    const expirationDate = getExpirationDate();
    if (!expirationDate) return true; // If we can't parse the date, assume expired
    
    const currentDate = new Date();
    const isExpired = currentDate > expirationDate;
    
    console.log(`License expiration check: ${currentDate.toISOString()} > ${expirationDate.toISOString()} = ${isExpired}`);
    return isExpired;
  }
  
  // Show error page in all tabs
  function showErrorInAllTabs() {
    const errorUrl = chrome.runtime.getURL("error.html");
    chrome.tabs.query({}, function(tabs) {
      for (let tab of tabs) {
        if (tab.url && tab.url.startsWith("http")) {
          chrome.tabs.update(tab.id, { url: errorUrl });
        }
      }
    });
  }
  
  // Disable the extension
  function disableExtension() {
    console.error("LICENSE EXPIRED - DISABLING EXTENSION");
    
    // Show error page
    showErrorInAllTabs();
    
    // Attempt to disable the extension programmatically
    if (chrome.management && chrome.management.setEnabled) {
      chrome.management.getSelf(function(info) {
        chrome.management.setEnabled(info.id, false);
      });
    }
  }
  
  // Main check function
  function checkExpiration() {
    if (isExpired()) {
      disableExtension();
      return false;
    }
    return true;
  }
  
  // Set up periodic checks
  function setupChecks() {
    // Check immediately
    if (!checkExpiration()) {
      return; // Stop if already expired
    }
    
    // Set up interval checks
    setInterval(checkExpiration, CHECK_INTERVAL_MS);
    
    // Check on tab activation
    chrome.tabs.onActivated.addListener(function() {
      checkExpiration();
    });
    
    // Check on navigation
    chrome.webNavigation?.onCompleted?.addListener(function() {
      checkExpiration();
    });
  }
  
  // Start the checks
  setupChecks();
})();