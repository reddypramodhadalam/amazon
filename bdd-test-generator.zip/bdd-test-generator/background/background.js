// Initialize storage when extension is installed
chrome.runtime.onInstalled.addListener(function() {
  console.log('BDD Test Generator installed');
  chrome.storage.local.clear();
  chrome.storage.local.set({
    isRecording: false,
    steps: []
  });
});

// Global steps array
let steps = [];

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log('Background received message:', request.action);
  
  if (request.action === 'addStep') {
    console.log('Adding step:', request.step);
    
    try {
      // Add step to array
      steps.push(request.step);
      
      // Save to storage
      chrome.storage.local.set({ steps: steps }, function() {
        if (chrome.runtime.lastError) {
          console.error('Error saving steps to storage:', chrome.runtime.lastError);
        } else {
          console.log('Saved steps to storage, count:', steps.length);
        }
      });
      
      // Notify popup about the updated steps
      try {
        chrome.runtime.sendMessage({
          action: 'updateSteps',
          steps: steps
        }).catch(e => {
          console.log('Could not update popup (probably not open)');
        });
      } catch (e) {
        console.error('Error sending updateSteps message:', e);
      }
      
      // Send response
      sendResponse({ success: true, stepsCount: steps.length });
    } catch (error) {
      console.error('Error processing addStep:', error);
      sendResponse({ success: false, error: error.message });
    }
    
    return true;
  }
  
  if (request.action === 'getSteps') {
    console.log('Returning steps, count:', steps.length);
    sendResponse({ steps: steps });
    return true;
  }
  
  if (request.action === 'clearSteps') {
    console.log('Clearing steps');
    steps = [];
    chrome.storage.local.set({ steps: [] }, function() {
      console.log('Steps cleared in storage');
    });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'startRecording') {
    console.log('Starting recording');
    chrome.storage.local.set({ isRecording: true }, function() {
      console.log('Recording state saved to storage');
    });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'stopRecording') {
    console.log('Stopping recording');
    chrome.storage.local.set({ isRecording: false }, function() {
      console.log('Recording state saved to storage');
    });
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'ping') {
    console.log('Received ping, sending response');
    sendResponse({ success: true, message: 'Background script is active' });
    return true;
  }
  
  // Default response
  console.log('Unknown action:', request.action);
  sendResponse({ success: false, error: 'Unknown action' });
  return true;
});

// Load steps from storage when background script starts
chrome.storage.local.get(['steps'], function(data) {
  if (chrome.runtime.lastError) {
    console.error('Error loading steps from storage:', chrome.runtime.lastError);
  } else if (data.steps) {
    steps = data.steps;
    console.log('Loaded steps from storage, count:', steps.length);
  } else {
    console.log('No steps found in storage');
  }
});

// Listen for tab removal to stop recording if the recording tab is closed
chrome.tabs.onRemoved.addListener(function(tabId, removeInfo) {
  chrome.storage.local.get(['isRecording', 'activeRecordingTabId'], function(data) {
    if (data.isRecording && data.activeRecordingTabId === tabId) {
      console.log('Recording tab was closed, stopping recording');
      chrome.storage.local.set({ isRecording: false });
      
      // Notify popup that recording has stopped
      try {
        chrome.runtime.sendMessage({
          action: 'recordingStopped',
          reason: 'tabClosed'
        }).catch(e => {
          console.log('Could not notify popup (probably not open)');
        });
      } catch (e) {
        console.error('Error sending recordingStopped message:', e);
      }
    }
  });
});

console.log('Background script loaded successfully');