console.log('BDD Test Generator content script loaded');

// Variables to track recording state
let isRecording = false;
let initialUrlCaptured = false;
let lastClickElement = null;
let lastClickTimestamp = 0;
let lastPageTitle = null;
let seenElements = new Set();

// Check if we should be recording
chrome.storage.local.get(['isRecording'], function(data) {
  isRecording = !!data.isRecording;
  console.log('Initial recording state:', isRecording);
  
  if (isRecording) {
    console.log('Starting recording automatically');
    startRecording();
  }
});

// Listen for messages
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log('Content script received message:', request.action);
  
  if (request.action === 'startRecording') {
    console.log('Starting recording from message');
    isRecording = true;
    startRecording(request.url);
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'stopRecording') {
    console.log('Stopping recording from message');
    isRecording = false;
    stopRecording();
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'ping') {
    console.log('Received ping, responding');
    sendResponse({ success: true, isRecording: isRecording });
    return true;
  }
  
  console.log('Unknown action:', request.action);
  sendResponse({ success: false, error: 'Unknown action' });
  return true;
});

// Start recording user interactions
function startRecording(url) {
  console.log('BDD Test Generator: Recording started');
  
  // Reset tracking variables
  initialUrlCaptured = false;
  lastClickElement = null;
  lastClickTimestamp = 0;
  lastPageTitle = null;
  seenElements.clear();
  
  // Capture initial URL only once
  if (!initialUrlCaptured) {
    const step = {
      type: 'navigation',
      url: url || window.location.href,
      timestamp: Date.now()
    };
    addStep(step);
    console.log('Initial URL captured:', url || window.location.href);
    initialUrlCaptured = true;
    
    // Wait for the page to be fully loaded before capturing the title
    if (document.readyState === 'complete') {
      capturePageTitle();
    } else {
      window.addEventListener('load', capturePageTitle);
    }
  }
  
  // Set up event listeners
  document.addEventListener('click', handleClick, true);
  document.addEventListener('input', handleInput, true);
  document.addEventListener('change', handleChange, true);
  
  // Set up iframe listeners
  setupIframeListeners();
  
  // Monitor page title changes
  try {
    const titleElement = document.querySelector('title');
    if (titleElement) {
      const titleObserver = new MutationObserver(() => {
        if (document.title !== lastPageTitle) {
          console.log('Page title changed to:', document.title);
          capturePageTitle();
        }
      });
      
      titleObserver.observe(titleElement, { 
        subtree: true, 
        characterData: true, 
        childList: true 
      });
    }
  } catch (e) {
    console.error('Error setting up title observer:', e);
  }
}

// Capture page title
function capturePageTitle() {
  if (document.title && document.title.trim()) {
    const titleStep = {
      type: 'assertion',
      element: `page title "${document.title}"`,
      xpath: 'document.title',
      timestamp: Date.now()
    };
    
    if (lastPageTitle !== document.title) {
      lastPageTitle = document.title;
      addStep(titleStep);
      console.log('Page title captured:', document.title);
    }
  }
}

// Stop recording user interactions
function stopRecording() {
  console.log('BDD Test Generator: Recording stopped');
  
  // Remove event listeners
  document.removeEventListener('click', handleClick, true);
  document.removeEventListener('input', handleInput, true);
  document.removeEventListener('change', handleChange, true);
  
  // Remove iframe listeners
  removeIframeListeners();
}

// Setup listeners for all iframes
function setupIframeListeners() {
  try {
    console.log('Setting up iframe listeners');
    
    // Function to recursively add listeners to iframes
    function addListenersToIframe(iframe, path = '') {
      try {
        // Try to access the iframe content
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        const iframePath = path ? path : `iframe[${Array.from(document.querySelectorAll('iframe')).indexOf(iframe)}]`;
        
        console.log(`Adding listeners to iframe: ${iframePath}`);
        
        // Add event listeners to the iframe document
        iframeDoc.addEventListener('click', (e) => {
          console.log(`Click detected in iframe: ${iframePath}`);
          handleIframeEvent(e, 'click', iframePath);
        }, true);
        
        iframeDoc.addEventListener('input', (e) => {
          console.log(`Input detected in iframe: ${iframePath}`);
          handleIframeEvent(e, 'input', iframePath);
        }, true);
        
        iframeDoc.addEventListener('change', (e) => {
          console.log(`Change detected in iframe: ${iframePath}`);
          handleIframeEvent(e, 'change', iframePath);
        }, true);
        
        // Also check for nested iframes
        const nestedIframes = iframeDoc.querySelectorAll('iframe');
        if (nestedIframes.length > 0) {
          console.log(`Found ${nestedIframes.length} nested iframes in ${iframePath}`);
          nestedIframes.forEach((nestedIframe, nestedIndex) => {
            const nestedPath = `${iframePath}/iframe[${nestedIndex}]`;
            addListenersToIframe(nestedIframe, nestedPath);
          });
        }
        
        // Set up a mutation observer to detect new iframes
        const iframeObserver = new MutationObserver((mutations) => {
          mutations.forEach((mutation) => {
            if (mutation.type === 'childList') {
              mutation.addedNodes.forEach((node) => {
                if (node.tagName === 'IFRAME') {
                  console.log(`New iframe detected in ${iframePath}`);
                  addListenersToIframe(node, `${iframePath}/iframe[${Array.from(iframeDoc.querySelectorAll('iframe')).indexOf(node)}]`);
                }
              });
            }
          });
        });
        
        iframeObserver.observe(iframeDoc.body, {
          childList: true,
          subtree: true
        });
        
      } catch (e) {
        console.log(`Could not access iframe ${path}: ${e.message}`);
      }
    }
    
    // Find all iframes in the main document
    const iframes = document.querySelectorAll('iframe');
    console.log(`Found ${iframes.length} iframes in main document`);
    
    // Add listeners to each iframe
    iframes.forEach((iframe) => {
      addListenersToIframe(iframe);
    });
    
    // Set up a mutation observer to detect new iframes in the main document
    const mainObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.tagName === 'IFRAME') {
              console.log('New iframe detected in main document');
              addListenersToIframe(node);
            }
          });
        }
      });
    });
    
    mainObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
    
  } catch (e) {
    console.error('Error setting up iframe listeners:', e);
  }
}

// Remove listeners from iframes
function removeIframeListeners() {
  const iframes = document.querySelectorAll('iframe');
  iframes.forEach((iframe, index) => {
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      console.log(`Removing listeners from iframe ${index}`);
      
      // For nested iframes
      const nestedIframes = iframeDoc.querySelectorAll('iframe');
      nestedIframes.forEach((nestedIframe, nestedIndex) => {
        try {
          console.log(`Removing listeners from nested iframe ${index}.${nestedIndex}`);
        } catch (e) {
          // Ignore cross-origin iframes
        }
      });
    } catch (e) {
      // Ignore cross-origin iframes
    }
  });
}

// Handle events from iframes
function handleIframeEvent(event, eventType, iframePath) {
  if (!isRecording) return;
  
  const element = event.target;
  console.log(`Handling ${eventType} event in iframe: ${iframePath} for element:`, element);
  
  if (eventType === 'click') {
    handleElementClick(element, true, iframePath);
  } else if (eventType === 'input') {
    handleElementInput(element, true, iframePath);
  } else if (eventType === 'change') {
    handleElementChange(element, true, iframePath);
  }
}

// Handle click events
function handleClick(event) {
  if (!isRecording) return;
  handleElementClick(event.target, false);
}

// Handle input events
function handleInput(event) {
  if (!isRecording) return;
  handleElementInput(event.target, false);
}

// Handle change events
function handleChange(event) {
  if (!isRecording) return;
  handleElementChange(event.target, false);
}

// Process element click
function handleElementClick(element, isIframe, iframePath) {
  // Check if the click was on a span with glyphicon inside a button
  if (element.tagName === 'SPAN' && element.classList.contains('glyphicon') && 
      element.parentElement && element.parentElement.tagName === 'BUTTON') {
    console.log('Detected click on glyphicon inside button, using parent button instead');
    element = element.parentElement; // Use the parent button as the target
  }

  // Debounce clicks on the same element (prevent duplicates)
  const now = Date.now();
  if (element === lastClickElement && now - lastClickTimestamp < 500) {
    console.log('Skipping duplicate click on same element');
    return;
  }
  lastClickElement = element;
  lastClickTimestamp = now;

  let elementDescription = getElementDescription(element);
  // Skip if we couldn't identify the element well
  if (elementDescription === 'unknown element') {
    // Try to get a better description by looking at parent elements for list items
    if (element.tagName === 'SPAN' && element.parentElement &&
        (element.parentElement.tagName === 'LI' || element.parentElement.classList.contains('ms-elem-selectable'))) {
      // This is likely a span inside a list item, use the span's text content
      elementDescription = element.textContent.trim();
      // If the parent has an ID, include that in the description
      if (element.parentElement.id) {
        elementDescription += ` (item ${element.parentElement.id})`;
      }
    } else if (element.tagName === 'LI' || element.classList.contains('ms-elem-selectable')) {
      // This is a list item, try to get its text content
      const spanElement = element.querySelector('span');
      if (spanElement && spanElement.textContent) {
        elementDescription = spanElement.textContent.trim();
      } else if (element.textContent) {
        elementDescription = element.textContent.trim();
      }
      // If the element has an ID, include that in the description
      if (element.id) {
        elementDescription += ` (item ${element.id})`;
      }
    }
    // If we still couldn't identify the element, skip it
    if (elementDescription === 'unknown element') return;
  }

  // Add iframe context if applicable
  if (isIframe) {
    elementDescription = `in iframe: ${elementDescription}`;
  }

  // Check if this is a calendar date selection
  let isCalendarDate = false;
  let calendarContext = '';
  // Check if the element is inside a calendar component
  let parent = element;
  while (parent && parent !== document.body) {
    // Check for common calendar container classes/attributes
    if (parent.classList.contains('calendar') ||
        parent.classList.contains('datepicker') ||
        parent.classList.contains('ui-datepicker') ||
        parent.getAttribute('role') === 'calendar' ||
        parent.getAttribute('data-handler') === 'selectDay') {
      isCalendarDate = true;
      // Try to find the associated input field
      const inputField = document.querySelector('input[id="' + parent.getAttribute('data-input') + '"]') ||
                         document.querySelector('input[aria-owns="' + parent.id + '"]') ||
                         document.querySelector('input[aria-controls="' + parent.id + '"]');
      if (inputField) {
        calendarContext = getElementDescription(inputField);
      } else {
        // Try to find a label or heading near the calendar
        const nearbyLabel = parent.previousElementSibling;
        if (nearbyLabel && (nearbyLabel.tagName === 'LABEL' || nearbyLabel.tagName === 'H3' || nearbyLabel.tagName === 'H4')) {
          calendarContext = nearbyLabel.textContent.trim();
        }
      }
      break;
    }
    parent = parent.parentElement;
  }

  // Get XPath - improved for calendar dates and list items
  let xpath = '';
  if (isCalendarDate) {
    // For calendar dates, create a more specific XPath
    const dateText = element.textContent.trim();
    const month = getCalendarMonth(parent);
    const year = getCalendarYear(parent);
    // Create a more specific XPath for the date cell
    xpath = createCalendarDateXPath(element, dateText, month, year, calendarContext);
    // Update element description to include calendar context
    if (calendarContext) {
      elementDescription = `date ${dateText} in ${calendarContext} calendar`;
    } else {
      elementDescription = `date ${dateText} in calendar`;
    }
  } else if (element.tagName === 'SPAN' && element.parentElement &&
            (element.parentElement.tagName === 'LI' || element.parentElement.classList.contains('ms-elem-selectable')) &&
            element.parentElement.id) {
    // For spans inside list items with IDs, use the parent's ID
    xpath = `//*[@id='${element.parentElement.id}']`;
  } else if ((element.tagName === 'LI' || element.classList.contains('ms-elem-selectable')) && element.id) {
    // For list items with IDs
    xpath = `//*[@id='${element.id}']`;
  } else {
    // Use the standard XPath generation
    xpath = getXPath(element);
  }

  if (isIframe) {
    xpath = `${iframePath}/${xpath}`;
  }

  // Record the click
  const step = {
    type: 'click',
    element: elementDescription,
    xpath: xpath,
    timestamp: Date.now()
  };
  addStep(step);
  console.log('Click recorded:', elementDescription);
}

// Helper function to get the current month from a calendar
function getCalendarMonth(calendarElement) {
  if (!calendarElement) return '';
  
  // Look for month indicator in the calendar
  const monthElement = calendarElement.querySelector('.ui-datepicker-month') || 
                       calendarElement.querySelector('.month') ||
                       calendarElement.querySelector('[class*="month"]');
  
  return monthElement ? monthElement.textContent.trim() : '';
}

// Helper function to get the current year from a calendar
function getCalendarYear(calendarElement) {
  if (!calendarElement) return '';
  
  // Look for year indicator in the calendar
  const yearElement = calendarElement.querySelector('.ui-datepicker-year') || 
                      calendarElement.querySelector('.year') ||
                      calendarElement.querySelector('[class*="year"]');
  
  return yearElement ? yearElement.textContent.trim() : '';
}

// Create a more specific XPath for calendar date cells
function createCalendarDateXPath(element, dateText, month, year, calendarContext) {
  // Start with the element's basic attributes
  let xpath = '';
  
  // If the element has specific attributes that identify it as a date cell
  if (element.getAttribute('data-date')) {
    xpath = `//*[@data-date="${element.getAttribute('data-date')}"]`;
  } else if (element.getAttribute('data-day')) {
    xpath = `//*[@data-day="${element.getAttribute('data-day')}"]`;
  } else {
    // Create an XPath that's specific to calendar date cells
    // This looks for the date text within a cell that has appropriate classes or attributes
    const dateClasses = element.className.split(' ').filter(c => c.length > 0).join(' and @class="');
    if (dateClasses) {
      xpath = `//*[@class="${dateClasses}"][text()="${dateText}"]`;
    } else {
      // If no useful classes, try to be more specific about the context
      if (month && year) {
        // If we know the month and year, include them in the XPath
        xpath = `//*[contains(@class, "day") or contains(@class, "date")][text()="${dateText}" and ancestor::*[contains(., "${month}") and contains(., "${year}")]]`;
      } else {
        // Otherwise, try to be specific about the element's role and position
        xpath = `//*[(@role="gridcell" or contains(@class, "day") or contains(@class, "date")) and text()="${dateText}"]`;
      }
    }
  }
  
  // If we have calendar context (like the input field name), make the XPath even more specific
  if (calendarContext) {
    const inputId = calendarContext.replace(/\s+/g, '').toLowerCase();
    xpath = `//*[@id="${inputId}"]/following::*[text()="${dateText}" and (contains(@class, "day") or @role="gridcell")]`;
  }
  
  return xpath;
}

// Helper function to get the current month from a calendar
function getCalendarMonth(calendarElement) {
  if (!calendarElement) return '';
  
  // Look for month indicator in the calendar
  const monthElement = calendarElement.querySelector('.ui-datepicker-month') || 
                       calendarElement.querySelector('.month') ||
                       calendarElement.querySelector('[class*="month"]');
  
  return monthElement ? monthElement.textContent.trim() : '';
}

// Helper function to get the current year from a calendar
function getCalendarYear(calendarElement) {
  if (!calendarElement) return '';
  
  // Look for year indicator in the calendar
  const yearElement = calendarElement.querySelector('.ui-datepicker-year') || 
                      calendarElement.querySelector('.year') ||
                      calendarElement.querySelector('[class*="year"]');
  
  return yearElement ? yearElement.textContent.trim() : '';
}

// Create a more specific XPath for calendar date cells
// Create a more specific XPath for calendar date cells
function createCalendarDateXPath(element, dateText, month, year, calendarContext) {
  // Start with the element's basic attributes
  let xpath = '';
  
  // If the element has specific attributes that identify it as a date cell
  if (element.getAttribute('data-date')) {
    xpath = `//*[@data-date="${element.getAttribute('data-date')}"]`;
  } else if (element.getAttribute('data-day')) {
    xpath = `//*[@data-day="${element.getAttribute('data-day')}"]`;
  } else {
    // Create an XPath that's specific to calendar date cells
    if (element.className) {
      // Check if this is a jQuery UI datepicker date cell with highlight/hover classes
      if (element.className.includes('ui-state-default') && 
          (element.className.includes('ui-state-highlight') || element.className.includes('ui-state-hover'))) {
        // For highlighted/hovered date cells, don't include the text in the XPath
        // as the highlight/hover state is specific enough
        const classNames = element.className.split(' ').filter(c => c.length > 0);
        const classConditions = classNames.map(c => `contains(@class, '${c}')`).join(' and ');
        xpath = `//*[${classConditions}]`;
      } else {
        // For regular date cells, include both class and text
        const classNames = element.className.split(' ').filter(c => c.length > 0);
        if (classNames.length > 0) {
          const classConditions = classNames.map(c => `contains(@class, '${c}')`).join(' and ');
          xpath = `//*[${classConditions}][text()="${dateText}"]`;
        } else {
          // If no classes, use a more generic approach
          xpath = `//*[text()="${dateText}" and (@role="gridcell" or contains(@class, "day") or contains(@class, "date"))]`;
        }
      }
    } else {
      // If no useful classes, try to be more specific about the context
      if (month && year) {
        // If we know the month and year, include them in the XPath
        xpath = `//*[contains(@class, "day") or contains(@class, "date")][text()="${dateText}" and ancestor::*[contains(., "${month}") and contains(., "${year}")]]`;
      } else {
        // Otherwise, try to be specific about the element's role and position
        xpath = `//*[(@role="gridcell" or contains(@class, "day") or contains(@class, "date")) and text()="${dateText}"]`;
      }
    }
  }
  
  // If we have calendar context (like the input field name), make the XPath even more specific
  if (calendarContext) {
    // Try to find the input field ID or a nearby identifier
    const inputId = calendarContext.replace(/\s+/g, '').toLowerCase();
    
    // Create a more specific XPath that relates to the input field
    xpath = `//*[@id="${inputId}" or @aria-labelledby="${inputId}" or @aria-label="${calendarContext}"]/following::*[text()="${dateText}" and (contains(@class, "day") or @role="gridcell")]`;
    
    // If that's too specific, we'll have a fallback in the Java step definition
  }
  
  return xpath;
}

// Process element input
function handleElementInput(element, isIframe, iframePath) {
  // Only record for input, textarea, and contenteditable elements
  if (element.tagName !== 'INPUT' && element.tagName !== 'TEXTAREA' && !element.isContentEditable) {
    return;
  }
  
  let elementDescription = getElementDescription(element);
  
  // Add iframe context if applicable
  if (isIframe) {
    elementDescription = `in iframe: ${elementDescription}`;
  }
  
  // Get XPath
  let xpath = getXPath(element);
  
  if (isIframe) {
    xpath = `${iframePath}/${xpath}`;
  }
  
  let value = element.value || element.textContent;
  
  // // Mask password inputs
  // if (element.type === 'password') {
  //   value = '********';
  // }
  
  // Debounce input events
  if (element._inputTimeout) {
    clearTimeout(element._inputTimeout);
  }
  
  element._inputTimeout = setTimeout(() => {
    const step = {
      type: 'input',
      element: elementDescription,
      value: value,
      xpath: xpath,
      timestamp: Date.now()
    };
    
    addStep(step);
    console.log('Input recorded:', elementDescription, 'with value:', value);
  }, 1000);
}

// Process element change
// Process checkbox change
function handleElementChange(element, isIframe, iframePath) {
  // Handle select elements
  if (element.tagName === 'SELECT') {
    let elementDescription = getElementDescription(element);
    
    // Add iframe context if applicable
    if (isIframe) {
      elementDescription = `in iframe: ${elementDescription}`;
    }
    
    // Get XPath
    let xpath = getXPath(element);
    if (isIframe) {
      xpath = `${iframePath}/${xpath}`;
    }
    
    const value = element.options[element.selectedIndex].text;
    const step = {
      type: 'select',
      element: elementDescription,
      value: value,
      xpath: xpath,
      timestamp: Date.now()
    };
    
    addStep(step);
    console.log('Select recorded:', elementDescription);
    return;
  }
  
  // Handle checkbox elements
  if (element.type === 'checkbox') {
    let elementDescription = getElementDescription(element);
    
    // Add iframe context if applicable
    if (isIframe) {
      elementDescription = `in iframe: ${elementDescription}`;
    }
    
    // Get XPath
    let xpath = getXPath(element);
    if (isIframe) {
      xpath = `${iframePath}/${xpath}`;
    }
    
    const step = {
      type: 'checkbox',
      element: elementDescription,
      checked: element.checked,
      xpath: xpath,
      timestamp: Date.now()
    };
    
    addStep(step);
    console.log('Checkbox recorded:', elementDescription, 'checked:', element.checked);
    return;
  }
  
  // Handle radio button elements
  if (element.type === 'radio') {
    let elementDescription = getElementDescription(element);
    
    // Add iframe context if applicable
    if (isIframe) {
      elementDescription = `in iframe: ${elementDescription}`;
    }
    
    // Get XPath
    let xpath = getXPath(element);
    if (isIframe) {
      xpath = `${iframePath}/${xpath}`;
    }
    
    const step = {
      type: 'radio',
      element: elementDescription,
      xpath: xpath,
      timestamp: Date.now()
    };
    
    addStep(step);
    console.log('Radio button recorded:', elementDescription);
    return;
  }
}

// Get a human-readable description of an element
// Update the getElementDescription function in content.js

function getElementDescription(element) {
  try {
    // For select elements, use a more readable format
    if (element.tagName === 'SELECT') {
      const label = findLabelForElement(element);
      if (label) {
        return `${label} dropdown`;
      }
      
      if (element.id) {
        // Try to make the ID more readable
        const readableId = element.id
          .replace(/([A-Z])/g, ' $1') // Add space before capital letters
          .replace(/_/g, ' ')         // Replace underscores with spaces
          .toLowerCase()
          .trim();
        
        return `${readableId} dropdown`;
      }
    }
    
    // For buttons, use button text or value
    if (element.tagName === 'BUTTON' || 
        (element.tagName === 'INPUT' && (element.type === 'button' || element.type === 'submit'))) {
      if (element.textContent && element.textContent.trim()) {
        return `${element.textContent.trim()} button`;
      }
      if (element.value) {
        return `${element.value} button`;
      }
    }
    
    // For links, use the link text
    if (element.tagName === 'A' && element.textContent && element.textContent.trim()) {
      return element.textContent.trim();
    }
    
    // For inputs, use label or placeholder
    if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
      const label = findLabelForElement(element);
      if (label) {
        return label;
      }
      
      if (element.getAttribute('placeholder')) {
        return element.getAttribute('placeholder');
      }
      
      if (element.type === 'text' || element.type === 'password' || element.tagName === 'TEXTAREA') {
        return element.name ? 
          `${element.name.replace(/([A-Z])/g, ' $1').toLowerCase()} field` : 
          `${element.type || 'text'} field`;
      }
    }
    
    // Special handling for list items and their children
    if (element.tagName === 'LI' || element.classList.contains('ms-elem-selectable')) {
      // For list items, try to get the text content
      const spanElement = element.querySelector('span');
      if (spanElement && spanElement.textContent) {
        return spanElement.textContent.trim();
      } else if (element.textContent) {
        return element.textContent.trim();
      }
    }
    
    // If this is a span inside a list item, use its text content
    if (element.tagName === 'SPAN' && element.parentElement && 
        (element.parentElement.tagName === 'LI' || element.parentElement.classList.contains('ms-elem-selectable'))) {
      return element.textContent.trim();
    }
    
    // Try to get text content for buttons, links, and labels
    if ((element.tagName === 'BUTTON' || element.tagName === 'A' || element.tagName === 'LABEL') &&
        element.textContent?.trim()) {
      const text = element.textContent.trim();
      if (text.length < 50) {
        return text;
      }
    }
    
    // For inputs with type="submit" or type="button", use their value
    if (element.tagName === 'INPUT' &&
        (element.type === 'submit' || element.type === 'button') &&
        element.value) {
      return element.value.trim();
    }
    
    // Try to get accessible name
    if (element.getAttribute('aria-label')) {
      return element.getAttribute('aria-label');
    }
    
    // Try to get placeholder
    if (element.getAttribute('placeholder')) {
      return element.getAttribute('placeholder');
    }
    
    // Try to get name or id in a more readable format
    if (element.getAttribute('name')) {
      const name = element.getAttribute('name')
        .replace(/([A-Z])/g, ' $1') // Add space before capital letters
        .replace(/\[|\]|\d+\./g, ' ') // Replace brackets and array indices
        .replace(/_/g, ' ')         // Replace underscores with spaces
        .toLowerCase()
        .trim();
      
      return name;
    }
    
    if (element.id) {
      const id = element.id
        .replace(/([A-Z])/g, ' $1') // Add space before capital letters
        .replace(/_/g, ' ')         // Replace underscores with spaces
        .toLowerCase()
        .trim();
      
      return id;
    }
    
    // If all else fails
    return 'unknown element';
  } catch (error) {
    console.error('Error getting element description:', error);
    return 'error describing element';
  }
}

// Helper function to find a label for an element
function findLabelForElement(element) {
  // Check for label with 'for' attribute
  if (element.id) {
    const label = document.querySelector(`label[for="${element.id}"]`);
    if (label && label.textContent) {
      return label.textContent.trim();
    }
  }
  
  // Check for parent label
  let parent = element.parentElement;
  while (parent && parent.tagName !== 'LABEL' && parent.tagName !== 'BODY') {
    parent = parent.parentElement;
  }
  
  if (parent && parent.tagName === 'LABEL' && parent.textContent) {
    return parent.textContent.trim();
  }
  
  // Check for preceding label or text
  const previousElement = element.previousElementSibling;
  if (previousElement && 
      (previousElement.tagName === 'LABEL' || 
       previousElement.tagName === 'SPAN' || 
       previousElement.tagName === 'DIV')) {
    if (previousElement.textContent && previousElement.textContent.trim()) {
      return previousElement.textContent.trim();
    }
  }
  
  return null;
}

// Get XPath for element
// Update the getXPath function in content/content.js

function getXPath(element) {
  try {
    if (!element) return '';
    
    // If element has ID, use it (most reliable)
    if (element.id) {
      return `//*[@id='${element.id}']`;
    }
    
    // If element has name attribute, use it (common for form elements)
    if (element.getAttribute('name')) {
      return `//*[@name='${element.getAttribute('name')}']`;
    }
    
    // If element has text content, try to use that (good for buttons, links, etc.)
    if (element.textContent && element.textContent.trim()) {
      const text = element.textContent.trim();
      if (text.length < 50) {
        // Escape single quotes in text
        const escapedText = text.replace(/'/g, "\\'");
        return `//*[contains(text(), '${escapedText}')]`;
      }
    }
    
    // For submit buttons, use the type and value
    if (element.tagName === 'INPUT' && element.type === 'submit' && element.value) {
      return `//input[@type='submit'][@value='${element.value}']`;
    }
    
    // For links with href, use that
    if (element.tagName === 'A' && element.getAttribute('href')) {
      return `//a[@href='${element.getAttribute('href')}']`;
    }
    
    // For elements with class, use that
    if (element.className && typeof element.className === 'string' && element.className.trim()) {
      const classes = element.className.trim().split(/\s+/);
      if (classes.length > 0) {
        return `//*[contains(@class, '${classes[0]}')]`;
      }
    }
    
    // For elements with role, use that
    if (element.getAttribute('role')) {
      return `//*[@role='${element.getAttribute('role')}']`;
    }
    
    // If we get here, we need to create a more specific path
    // Try to create a path that includes tag name and position
    let path = '';
    let current = element;
    
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      let tag = current.tagName.toLowerCase();
      
      // Try to use attributes to make the XPath more specific
      let attributes = '';
      
      // Try ID first
      if (current.id) {
        return `//*[@id='${current.id}']${path}`;
      }
      
      // Try text content
      if (current.textContent && current.textContent.trim()) {
        const text = current.textContent.trim();
        if (text.length < 30) {
          const escapedText = text.replace(/'/g, "\\'");
          attributes = `[contains(text(), '${escapedText}')]`;
        }
      }
      
      // Try class if no text
      if (!attributes && current.className && typeof current.className === 'string' && current.className.trim()) {
        const classes = current.className.trim().split(/\s+/);
        if (classes.length > 0) {
          attributes = `[contains(@class, '${classes[0]}')]`;
        }
      }
      
      // If still no attributes, use position
      if (!attributes) {
        let index = 1;
        let sibling = current.previousElementSibling;
        
        // Count siblings with same tag
        while (sibling) {
          if (sibling.tagName.toLowerCase() === tag) index++;
          sibling = sibling.previousElementSibling;
        }
        
        attributes = `[${index}]`;
      }
      
      // Add to path
      path = `/${tag}${attributes}${path}`;
      
      // Move up to parent
      current = current.parentNode;
      
      // If we reach the body, add html/body prefix and stop
      if (current === document.body) {
        // For shorter XPaths, try to return what we have so far if it's unique
        const currentPath = `//${tag}${attributes}${path}`;
        try {
          const matchingElements = document.evaluate(currentPath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
          if (matchingElements.snapshotLength === 1) {
            return currentPath;
          }
        } catch (e) {
          // If evaluation fails, continue with the full path
        }
        
        path = `/html/body${path}`;
        break;
      }
    }
    
    return path;
  } catch (error) {
    console.error('Error getting XPath:', error);
    return '//body';
  }
}

// Add a step to the recorded steps
function addStep(step) {
  try {
    // Skip duplicate elements
    const elementKey = `${step.type}-${step.element}`;
    if (step.type !== 'navigation' && seenElements.has(elementKey)) {
      console.log(`Skipping duplicate element: ${elementKey}`);
      return;
    }
    
    // Add to seen elements
    if (step.type !== 'navigation') {
      seenElements.add(elementKey);
    }
    
    // Send to background script
    chrome.runtime.sendMessage({
      action: 'addStep',
      step: step
    }, function(response) {
      if (chrome.runtime.lastError) {
        console.error('Error sending step:', chrome.runtime.lastError);
        
        // Try direct storage as fallback
        try {
          chrome.storage.local.get(['steps'], function(data) {
            let steps = data.steps || [];
            steps.push(step);
            chrome.storage.local.set({ steps: steps }, function() {
              if (chrome.runtime.lastError) {
                console.error('Error saving to storage:', chrome.runtime.lastError);
              } else {
                console.log('Step saved directly to storage');
              }
            });
          });
        } catch (storageError) {
          console.error('Error with storage fallback:', storageError);
        }
      } else {
        console.log('Step sent successfully, response:', response);
      }
    });
  } catch (error) {
    console.error('Error adding step:', error);
  }
}

// Send a ping to the background script to verify connection
try {
  console.log('Sending initial ping to background script');
  chrome.runtime.sendMessage({ action: 'ping' }, function(response) {
    if (chrome.runtime.lastError) {
      console.error('Error pinging background script:', chrome.runtime.lastError);
    } else {
      console.log('Background script responded to ping:', response);
    }
  });
} catch (error) {
  console.error('Exception sending ping:', error);
}

function addCleanupButton() {
  const cleanupBtn = document.createElement('button');
  cleanupBtn.id = 'cleanupBtn';
  cleanupBtn.className = 'btn btn-sm btn-outline-secondary';
  cleanupBtn.textContent = 'Clean Up Steps';
  cleanupBtn.title = 'Remove duplicate validations and simplify steps';
  
  const outputControls = document.querySelector('#gherkin-tab .output-controls');
  outputControls.prepend(cleanupBtn);
  
  cleanupBtn.addEventListener('click', function() {
    if (steps.length === 0) {
      showNotification('No steps to clean up.', 'info');
      return;
    }
    
    // Create a simplified version of the steps
    const cleanedSteps = cleanupSteps(steps);
    
    // Update the steps array and storage
    steps = cleanedSteps;
    chrome.storage.local.set({ steps: steps }, function() {
      console.log('Updated steps after cleanup');
      updateUI();
      showNotification('Steps cleaned up successfully!');
    });
  });
}

// Function to clean up steps
function cleanupSteps(originalSteps) {
  const cleanedSteps = [];
  let lastElement = null;
  let lastPageTitle = null;
  
  // First, add the navigation step
  const navigationStep = originalSteps.find(step => step.type === 'navigation');
  if (navigationStep) {
    cleanedSteps.push(navigationStep);
  }
  
  // Process the rest of the steps
  for (let i = 0; i < originalSteps.length; i++) {
    const step = originalSteps[i];
    
    // Skip navigation steps as we've already handled them
    if (step.type === 'navigation') continue;
    
    // Handle page title assertions
    if (step.type === 'assertion' && step.element.includes('page title')) {
      // Only add if it's a new page title
      if (step.element !== lastPageTitle) {
        cleanedSteps.push(step);
        lastPageTitle = step.element;
      }
      continue;
    }
    
    // Handle action steps (click, input, select)
    if (step.type === 'click' || step.type === 'input' || step.type === 'select') {
      // Skip if this is a duplicate action on the same element
      if (i > 0 && 
          originalSteps[i-1].type === step.type && 
          originalSteps[i-1].element === step.element) {
        continue;
      }
      
      // Add the step
      cleanedSteps.push(step);
      lastElement = step.element;
      continue;
    }
    
    // Add all other steps
    cleanedSteps.push(step);
  }
  
  return cleanedSteps;
}

// Log that content script initialization is complete
console.log('BDD Test Generator content script initialization complete');