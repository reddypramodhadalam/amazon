const JavaScriptObfuscator = require('javascript-obfuscator');
const fs = require('fs');
const path = require('path');

// Update these paths to match your actual file structure
const filesToObfuscate = [
  'popup/popup.js',
  'utils/xpath-utils.js'
];

// Special handling for these scripts
const contentScript = 'content/content.js';
const backgroundScript = 'background/background.js';

const filesToCopy = [
  'manifest.json',
  'popup/popup.html',
  'popup/popup.css'
];

const outputDir = 'dist';

// Create output directory structure if it doesn't exist
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir);
}

// Create subdirectories
['utils', 'popup', 'background', 'content', 'images'].forEach(dir => {
  const dirPath = path.join(outputDir, dir);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
});

// Copy non-JS files
filesToCopy.forEach(file => {
  const sourcePath = file;
  const targetPath = path.join(outputDir, file);
  
  // Make sure the target directory exists
  const targetDir = path.dirname(targetPath);
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  // Check if source file exists before copying
  if (fs.existsSync(sourcePath)) {
    fs.copyFileSync(sourcePath, targetPath);
    console.log(`Copied: ${sourcePath} -> ${targetPath}`);
  } else {
    console.warn(`Warning: Source file not found: ${sourcePath}`);
  }
});

// Copy image files if they exist
['images/icon16.png', 'images/icon48.png', 'images/icon128.png'].forEach(imgFile => {
  const sourcePath = imgFile;
  const targetPath = path.join(outputDir, imgFile);
  
  // Make sure the target directory exists
  const targetDir = path.dirname(targetPath);
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  if (fs.existsSync(sourcePath)) {
    fs.copyFileSync(sourcePath, targetPath);
    console.log(`Copied: ${sourcePath} -> ${targetPath}`);
  } else {
    console.warn(`Warning: Image file not found: ${sourcePath}`);
  }
});

// Obfuscate regular JS files with high obfuscation
filesToObfuscate.forEach(file => {
  const sourcePath = file;
  const targetPath = path.join(outputDir, file);
  
  // Make sure the target directory exists
  const targetDir = path.dirname(targetPath);
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  // Check if source file exists before obfuscating
  if (fs.existsSync(sourcePath)) {
    const code = fs.readFileSync(sourcePath, 'utf8');
    
    // High obfuscation options
    const obfuscatedCode = JavaScriptObfuscator.obfuscate(code, {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 0.7,
      deadCodeInjection: true,
      deadCodeInjectionThreshold: 0.4,
      debugProtection: false,
      disableConsoleOutput: false,
      identifierNamesGenerator: 'hexadecimal',
      renameGlobals: false,
      rotateStringArray: true,
      selfDefending: true,
      stringArray: true,
      stringArrayEncoding: ['base64'],
      stringArrayThreshold: 0.8,
      transformObjectKeys: true,
      unicodeEscapeSequence: false
    }).getObfuscatedCode();
    
    fs.writeFileSync(targetPath, obfuscatedCode);
    console.log(`Obfuscated with high settings: ${sourcePath} -> ${targetPath}`);
  } else {
    console.error(`Error: JavaScript file not found: ${sourcePath}`);
  }
});

// Obfuscate content script with medium settings
if (fs.existsSync(contentScript)) {
  const code = fs.readFileSync(contentScript, 'utf8');
  
  // Medium obfuscation for content script
  const obfuscatedCode = JavaScriptObfuscator.obfuscate(code, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.3,  // Medium level
    deadCodeInjection: false,  // Keep this off for stability
    debugProtection: false,
    disableConsoleOutput: false,
    identifierNamesGenerator: 'hexadecimal',  // More aggressive naming
    renameGlobals: false,
    rotateStringArray: true,
    selfDefending: false,
    splitStrings: true,
    splitStringsChunkLength: 10,
    stringArray: true,
    stringArrayEncoding: ['base64'],
    stringArrayThreshold: 0.5,  // Medium level
    transformObjectKeys: false,  // Keep this off for stability
    unicodeEscapeSequence: false
  }).getObfuscatedCode();
  
  fs.writeFileSync(path.join(outputDir, contentScript), obfuscatedCode);
  console.log(`Obfuscated content script with medium settings: ${contentScript} -> ${path.join(outputDir, contentScript)}`);
} else {
  console.error(`Error: Content script file not found: ${contentScript}`);
}

// Obfuscate background script with medium settings
if (fs.existsSync(backgroundScript)) {
  const code = fs.readFileSync(backgroundScript, 'utf8');
  
  // Medium obfuscation for background script
  const obfuscatedCode = JavaScriptObfuscator.obfuscate(code, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.3,  // Medium level
    deadCodeInjection: false,  // Keep this off for stability
    debugProtection: false,
    disableConsoleOutput: false,
    identifierNamesGenerator: 'hexadecimal',  // More aggressive naming
    renameGlobals: false,
    rotateStringArray: true,
    selfDefending: false,
    splitStrings: true,
    splitStringsChunkLength: 10,
    stringArray: true,
    stringArrayEncoding: ['base64'],
    stringArrayThreshold: 0.5,  // Medium level
    transformObjectKeys: false,  // Keep this off for stability
    unicodeEscapeSequence: false
  }).getObfuscatedCode();
  
  fs.writeFileSync(path.join(outputDir, backgroundScript), obfuscatedCode);
  console.log(`Obfuscated background script with medium settings: ${backgroundScript} -> ${path.join(outputDir, backgroundScript)}`);
} else {
  console.error(`Error: Background script file not found: ${backgroundScript}`);
}

console.log('Build completed successfully!');