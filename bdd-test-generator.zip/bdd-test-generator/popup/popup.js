      document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const featureTitleInput = document.getElementById('featureTitle');
        const urlInput = document.getElementById('urlInput');
        const loadUrlBtn = document.getElementById('loadUrlBtn');
        const stopBtn = document.getElementById('stopBtn');
        const clearBtn = document.getElementById('clearBtn');
        const copyBtn = document.getElementById('copyBtn');
        const copyJavaBtn = document.getElementById('copyJavaBtn');
        const downloadGherkinBtn = document.getElementById('downloadGherkinBtn');
        const downloadJavaBtn = document.getElementById('downloadJavaBtn');
        const gherkinOutput = document.getElementById('gherkinOutput');
        const javaOutput = document.getElementById('javaOutput');
        const statusDiv = document.getElementById('status');
        const recordingIndicator = document.getElementById('recordingIndicator');
        const tabHeaders = document.querySelectorAll('.tab-header');
        let isRecording = false;
        let steps = [];
        let pollInterval = null;
      
        addSettingsButton();
        // Initialize from storage
        chrome.storage.local.get(['isRecording', 'steps', 'featureTitle', 'theme'], function(data) {
          console.log('Loaded data from storage:', data);
          isRecording = data.isRecording || false;
          steps = data.steps || [];
          if (data.featureTitle) {
            featureTitleInput.value = data.featureTitle;
          }
          
          // Set theme if stored
          if (data.theme) {
            setTheme(data.theme);
          }
          
          updateUI();
          if (isRecording) {
            startPolling();
          }
        });
        
        // Tab switching
        tabHeaders.forEach(header => {
          header.addEventListener('click', function() {
            document.querySelectorAll('.tab-header').forEach(h => h.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            this.classList.add('active');
            const tabId = this.getAttribute('data-tab') + '-tab';
            document.getElementById(tabId).classList.add('active');
          });
        });
        
        // Load URL and start recording
        loadUrlBtn.addEventListener('click', function() {
          const url = urlInput.value.trim();
          if (!url) {
            showNotification('Please enter a valid URL.', 'error');
            return;
          }
          
          // Save feature title
          const featureTitle = featureTitleInput.value || 'Web Navigation';
          
          // Clear existing steps
          steps = [];
          
          // Update UI to show recording state
          isRecording = true;
          updateUI();
          statusDiv.textContent = 'Opening page and starting recording...';
          
          // Save state to storage
          chrome.storage.local.set({
            isRecording: true,
            steps: [],
            featureTitle: featureTitle
          }, function() {
            console.log('Recording state saved to storage');
            
            // Create a new tab with the URL
            chrome.tabs.create({ url: url }, function(tab) {
              console.log('Created new tab with ID:', tab.id);
              
              // Store the tab ID
              chrome.storage.local.set({ activeRecordingTabId: tab.id }, function() {
                console.log('Stored active recording tab ID:', tab.id);
                
                // Start polling for steps
                startPolling();
                
                // Wait for the tab to load
                chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
                  if (tabId === tab.id && changeInfo.status === 'complete') {
                    console.log('Tab loaded completely');
                    
                    // Remove the listener
                    chrome.tabs.onUpdated.removeListener(listener);
                    
                    // Send message to content script to start recording
                    setTimeout(() => {
                      chrome.tabs.sendMessage(tab.id, {
                        action: 'startRecording',
                        url: url,
                        featureTitle: featureTitle
                      }, function(response) {
                        if (chrome.runtime.lastError) {
                          console.error('Error starting recording:', chrome.runtime.lastError);
                          
                          // If content script isn't ready, inject it manually
                          chrome.scripting.executeScript({
                            target: { tabId: tab.id },
                            files: ['content/content.js']
                          }).then(() => {
                            console.log('Content script injected, starting recording');
                            
                            // Try again after a short delay
                            setTimeout(() => {
                              chrome.tabs.sendMessage(tab.id, {
                                action: 'startRecording',
                                url: url,
                                featureTitle: featureTitle
                              }, function(response) {
                                if (chrome.runtime.lastError) {
                                  console.error('Still could not start recording:', chrome.runtime.lastError);
                                  statusDiv.textContent = 'Error: Could not start recording.';
                                  showNotification('Could not start recording. Please try again.', 'error');
                                } else {
                                  console.log('Recording started successfully after injection');
                                }
                              });
                            }, 500);
                          }).catch(err => {
                            console.error('Failed to inject content script:', err);
                            statusDiv.textContent = 'Error: Could not inject recording script.';
                            isRecording = false;
                            updateUI();
                            showNotification('Failed to inject recording script.', 'error');
                          });
                        } else {
                          console.log('Recording started successfully');
                        }
                      });
                    }, 500); // Give the page a moment to settle
                  }
                });
              });
            });
          });
        });
        
        // Stop recording
        stopBtn.addEventListener('click', function() {
          isRecording = false;
          
          // Stop polling
          if (pollInterval) {
            clearInterval(pollInterval);
            pollInterval = null;
          }
          
          chrome.storage.local.set({ isRecording: false }, function() {
            updateUI();
            
            // Send message to all tabs to stop recording
            chrome.tabs.query({}, function(tabs) {
              tabs.forEach(tab => {
                try {
                  chrome.tabs.sendMessage(tab.id, { action: 'stopRecording' });
                } catch (e) {
                  console.log(`Could not send message to tab ${tab.id}`);
                }
              });
            });
            
            showNotification('Recording stopped successfully.', 'success');
          });
        });
        
        // Clear steps
        clearBtn.addEventListener('click', function() {
          if (steps.length > 0) {
            if (confirm('Are you sure you want to clear all recorded steps?')) {
              steps = [];
              chrome.storage.local.set({ steps: [] }, function() {
                updateUI();
                showNotification('All steps cleared.', 'info');
              });
            }
          } else {
            showNotification('No steps to clear.', 'info');
          }
        });
        
        // Copy to clipboard
        copyBtn.addEventListener('click', function() {
          const content = gherkinOutput.textContent;
          if (content && !content.includes('No steps recorded yet')) {
            navigator.clipboard.writeText(content)
              .then(() => {
                const originalText = copyBtn.textContent;
                copyBtn.textContent = 'Copied!';
                setTimeout(() => {
                  copyBtn.textContent = originalText;
                }, 2000);
                showNotification('Gherkin code copied to clipboard.', 'success');
              })
              .catch(err => {
                console.error('Failed to copy text: ', err);
                showNotification('Failed to copy text.', 'error');
              });
          }
        });
        
        // Copy Java to clipboard
        copyJavaBtn.addEventListener('click', function() {
          const content = javaOutput.textContent;
          if (content && !content.includes('No steps recorded yet')) {
            navigator.clipboard.writeText(content)
              .then(() => {
                const originalText = this.textContent;
                this.textContent = 'Copied!';
                setTimeout(() => {
                  this.textContent = originalText;
                }, 2000);
                showNotification('Java code copied to clipboard.', 'success');
              })
              .catch(err => {
                console.error('Failed to copy text: ', err);
                showNotification('Failed to copy text.', 'error');
              });
          }
        });
        
        // Download feature file
        downloadGherkinBtn.addEventListener('click', function() {
          const content = gherkinOutput.textContent;
          if (content && !content.includes('No steps recorded yet')) {
            const featureTitle = featureTitleInput.value || 'web_navigation';
            const filename = `${featureTitle.toLowerCase().replace(/\s+/g, '_')}.feature`;
            downloadFile(content, filename, 'text/plain');
            showNotification(`Downloaded as ${filename}`, 'success');
          } else {
            showNotification('No content to download.', 'info');
          }
        });
        
        // Download Java file
        downloadJavaBtn.addEventListener('click', function() {
          const content = javaOutput.textContent;
          if (content && !content.includes('No steps recorded yet')) {
            const featureTitle = featureTitleInput.value || 'web_navigation';
            const filename = `${featureTitle.toLowerCase().replace(/\s+/g, '_')}_steps.java`;
            downloadFile(content, filename, 'text/plain');
            showNotification(`Downloaded as ${filename}`, 'success');
          } else {
            showNotification('No content to download.', 'info');
          }
        });
        
        // Update feature title in storage
        featureTitleInput.addEventListener('input', function() {
          chrome.storage.local.set({ featureTitle: featureTitleInput.value });
          updateUI();
        });
        
        // Listen for updates from background script
        chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
          console.log('Message received in popup:', request);
          if (request.action === 'updateSteps') {
            try {
              steps = request.steps || [];
              console.log('Updated steps in popup:', steps.length);
              updateUI();
              sendResponse({ success: true });
            } catch (e) {
              console.error('Error updating steps:', e);
              sendResponse({ success: false, error: e.message });
            }
            return true;
          }
          
          if (request.action === 'recordingStopped') {
            isRecording = false;
            if (pollInterval) {
              clearInterval(pollInterval);
              pollInterval = null;
            }
            updateUI();
            showNotification(`Recording stopped: ${request.reason}`, 'info');
            sendResponse({ success: true });
            return true;
          }
          
          sendResponse({ success: false, error: 'Unknown action' });
          return true;
        });
        
        // Poll for steps periodically
        function startPolling() {
          console.log('Starting polling for steps');
          if (pollInterval) {
            clearInterval(pollInterval);
          }
          
          pollInterval = setInterval(() => {
            if (!isRecording) {
              clearInterval(pollInterval);
              pollInterval = null;
              return;
            }
            
            chrome.storage.local.get(['steps'], function(data) {
              if (data.steps && data.steps.length > 0) {
                steps = data.steps;
                updateUI();
              }
            });
          }, 1000);
        }
        
        // Update UI based on current state
        function updateUI() {
          // Update recording state UI
          if (isRecording) {
            stopBtn.disabled = false;
            loadUrlBtn.disabled = true;
            urlInput.disabled = true;
            featureTitleInput.disabled = true;
            statusDiv.textContent = 'Recording in progress... Interact with the page to record steps.';
            recordingIndicator.classList.add('active');
          } else {
            stopBtn.disabled = true;
            loadUrlBtn.disabled = false;
            urlInput.disabled = false;
            featureTitleInput.disabled = false;
            statusDiv.textContent = 'Enter a URL and click "Start Recording" to begin.';
            recordingIndicator.classList.remove('active');
          }
          
          // Update output
          if (steps && steps.length > 0) {
            const featureTitle = featureTitleInput.value || 'Web Navigation';
            gherkinOutput.textContent = generateGherkinFeature(featureTitle, steps);
            javaOutput.textContent = generateJavaStepDefinitions(steps);
          } else {
            gherkinOutput.textContent = 'No steps recorded yet. Enter a URL to begin.';
            javaOutput.textContent = 'No steps recorded yet. Enter a URL to begin.';
          }
        }
        
        // Generate Gherkin feature file
        function generateGherkinFeature(title, steps) {
          // Generate scenario name based on feature title
          let scenarioName = 'User Navigation Flow';
          if (title.toLowerCase().includes('login')) {
            scenarioName = 'User Login Process';
          } else if (title.toLowerCase().includes('search')) {
            scenarioName = 'User Search Process';
          } else if (title.toLowerCase().includes('registration')) {
            scenarioName = 'User Registration Process';
          } else {
            scenarioName = title + ' Scenario';
          }
          
          let feature = `Feature: ${title}\n\n`;
          feature += `Scenario: ${scenarioName}\n`;
          
          // Process steps to add validations before actions, but avoid duplicates
          let processedSteps = [];
          let navigationStep = null;
          let lastValidatedElement = null;
          let lastPageTitle = null;
          
          // Find the navigation step (should be the first one)
          for (let i = 0; i < steps.length; i++) {
            if (steps[i].type === 'navigation') {
              navigationStep = steps[i];
              break;
            }
          }
          
          // Add the navigation step first
          if (navigationStep) {
            processedSteps.push({
              type: 'given',
              text: `Given I navigate to "${navigationStep.url}"`,
              xpath: ''
            });
          }
          
          // Process the rest of the steps
          for (let i = 0; i < steps.length; i++) {
            const step = steps[i];
            
            // Skip the navigation step as we've already added it
            if (step.type === 'navigation') continue;
            
            if (step.type === 'assertion') {
              // For page title assertions, only add if it's a new title and use a different format to avoid nested quotes
              if (step.element && step.element.includes('page title')) {
                const title = step.element;
                if (title !== lastPageTitle) {
                  // Extract the actual title from the format "page title "TITLE""
                  let actualTitle = title;
                  const titleMatch = title.match(/page title "([^"]+)"/);
                  if (titleMatch && titleMatch[1]) {
                    actualTitle = titleMatch[1];
                  } else if (title.startsWith('page title ')) {
                    actualTitle = title.substring('page title '.length).trim();
                  }
                  
                  processedSteps.push({
                    type: 'then',
                    text: `Then I should see page title "${actualTitle}"`,
                    xpath: step.xpath
                  });
                  lastPageTitle = title;
                }
              } else {
                // For other assertions, add normally
                processedSteps.push({
                  type: 'then',
                  text: `Then I should see "${step.element}"`,
                  xpath: step.xpath
                });
              }
            } else if (step.type === 'click') {
              // Only add validation if we haven't validated this element yet
              if (step.element !== lastValidatedElement) {
                processedSteps.push({
                  type: 'then',
                  text: `Then I should see the element "${step.element}"`,
                  xpath: step.xpath
                });
                lastValidatedElement = step.element;
              }
              
              // Special handling for calendar date clicks
              if (step.element && step.element.includes('date') && step.element.includes('calendar')) {
                // Extract the date from the element description
                const dateMatch = step.element.match(/date (\d+) in/);
                if (dateMatch && dateMatch[1]) {
                  processedSteps.push({
                    type: 'when',
                    text: `When I select date "${dateMatch[1]}" from calendar`,
                    xpath: step.xpath
                  });
                } else {
                  // Fall back to regular click if we can't extract the date
                  processedSteps.push({
                    type: 'when',
                    text: `When I click on "${step.element}"`,
                    xpath: step.xpath
                  });
                }
              } else {
                // Regular click action
                processedSteps.push({
                  type: 'when',
                  text: `When I click on "${step.element}"`,
                  xpath: step.xpath
                });
              }
              
              // Reset lastValidatedElement after action
              lastValidatedElement = null;
            } else if (step.type === 'input') {
              // Only add validation if we haven't validated this element yet
              if (step.element !== lastValidatedElement) {
                processedSteps.push({
                  type: 'then',
                  text: `Then I should see the element "${step.element}"`,
                  xpath: step.xpath
                });
                lastValidatedElement = step.element;
              }
              
              // Determine if this is a credential field or eSign field
              const isCredential = step.element && (
                step.element.toLowerCase().includes('username') ||
                step.element.toLowerCase().includes('user name') ||
                step.element.toLowerCase().includes('email') ||
                step.element.toLowerCase().includes('password') ||
                step.element.toLowerCase().includes('login') ||
                step.element.toLowerCase().includes('esign') ||
                step.element.toLowerCase().includes('e-sign') ||
                step.element.toLowerCase().includes('e-signature') ||
                step.element.toLowerCase().includes('signature'));
              
              // Add input action with different wording based on field type
              processedSteps.push({
                type: 'when',
                text: isCredential ?
                  `When I enter "${step.value}" into "${step.element}"` :
                  `When I input "${step.value}" into "${step.element}"`,
                xpath: step.xpath
              });
              
              // Reset lastValidatedElement after action
              lastValidatedElement = null;
            } else if (step.type === 'select') {
              // Only add validation if we haven't validated this element yet
              if (step.element !== lastValidatedElement) {
                processedSteps.push({
                  type: 'then',
                  text: `Then I should see the element "${step.element}"`,
                  xpath: step.xpath
                });
                lastValidatedElement = step.element;
              }
              
              // Add select action
              processedSteps.push({
                type: 'when',
                text: `When I select "${step.value}" from "${step.element}"`,
                xpath: step.xpath
              });
              
              // Reset lastValidatedElement after action
              lastValidatedElement = null;
            } else if (step.type === 'checkbox') {
              // Only add validation if we haven't validated this element yet
              if (step.element !== lastValidatedElement) {
                processedSteps.push({
                  type: 'then',
                  text: `Then I should see the element "${step.element}"`,
                  xpath: step.xpath
                });
                lastValidatedElement = step.element;
              }
              
              // Add checkbox action based on checked state
              const action = step.checked ? 'check' : 'uncheck';
              processedSteps.push({
                type: 'when',
                text: `When I ${action} "${step.element}"`,
                xpath: step.xpath
              });
              
              // Reset lastValidatedElement after action
              lastValidatedElement = null;
            } else if (step.type === 'radio') {
              // Only add validation if we haven't validated this element yet
              if (step.element !== lastValidatedElement) {
                processedSteps.push({
                  type: 'then',
                  text: `Then I should see the element "${step.element}"`,
                  xpath: step.xpath
                });
                lastValidatedElement = step.element;
              }
              
              // Add radio button action
              processedSteps.push({
                type: 'when',
                text: `When I select radio button "${step.element}"`,
                xpath: step.xpath
              });
              
              // Reset lastValidatedElement after action
              lastValidatedElement = null;
            }
          }
          
          // Generate the feature file from processed steps
          processedSteps.forEach(step => {
            // Put the step text on one line
            feature += `  ${step.text}\n`;
            
            // Put the XPath on a separate line as a comment
            if (step.xpath) {
              feature += `    # xpath: ${step.xpath}\n`;
            }
          });
          
          return feature;
        }
        
        // Generate Java step definitions
        function generateJavaStepDefinitions(steps) {
          let imports = `package com.qa.stepdef;\n\n`;
          imports += `import io.cucumber.java.en.Given;\n`;
          imports += `import io.cucumber.java.en.When;\n`;
          imports += `import io.cucumber.java.en.Then;\n`;
          imports += `import org.openqa.selenium.By;\n`;
          imports += `import org.openqa.selenium.WebDriver;\n`;
          imports += `import org.openqa.selenium.WebElement;\n`;
          imports += `import org.openqa.selenium.chrome.ChromeDriver;\n`;
          imports += `import org.openqa.selenium.support.ui.ExpectedConditions;\n`;
          imports += `import org.openqa.selenium.support.ui.Select;\n`;
          imports += `import org.openqa.selenium.support.ui.WebDriverWait;\n`;
          imports += `import org.testng.Assert;\n`;
          imports += `import com.qa.pages.BasePage;\n`;
          imports += `import com.qa.utils.DriverManager;\n`;
          imports += `import com.qa.utils.JavaScriptExecutorUtil;\n`;
          imports += `import java.time.Duration;\n`;
          imports += `import java.util.HashMap;\n`;
          imports += `import java.util.Map;\n`;
          imports += `import java.util.List;\n\n`;
          
          let stepDefs = `public class StepDefinitions {\n\n`;
          stepDefs += `    private WebDriver driver;\n`;
          stepDefs += `    private WebDriverWait wait;\n`;
          stepDefs += `    private BasePage bp;\n`;
          stepDefs += `    private Map<String, String> elementXpaths = new HashMap<>();\n\n`;
          
          stepDefs += `    public StepDefinitions() {\n`;
          stepDefs += `        this.driver = DriverManager.getDriver();\n`;
          stepDefs += `        this.wait = new WebDriverWait(driver, 25);\n`;
          stepDefs += `        this.bp = new BasePage(driver);\n`;
          stepDefs += `        initializeXpaths();\n`;
          stepDefs += `    }\n\n`;
          
          stepDefs += `    private void initializeXpaths() {\n`;
          
          // Add all XPaths to the map
          const xpathMap = new Map();
          for (let i = 0; i < steps.length; i++) {
            const step = steps[i];
            if (step.element && step.xpath) {
              xpathMap.set(step.element, step.xpath);
            }
          }
          
          // Add the XPaths to the initialization method
          xpathMap.forEach((xpath, element) => {
            stepDefs += `        elementXpaths.put("${element.replace(/"/g, '\\"')}", "${xpath.replace(/"/g, '\\"')}");\n`;
          });
          
          stepDefs += `    }\n\n`;
          
          // Add step definitions
          let hasNavigationStep = false;
          let hasClickStep = false;
          let hasEnterStep = false;
          let hasInputStep = false;
          let hasSelectStep = false;
          let hasCheckboxStep = false;
          let hasRadioStep = false;
          let hasElementValidationStep = false;
          let hasTextValidationStep = false;
          let hasPageTitleStep = false;
          let hasCalendarDateStep = false;
          
          // Check what types of steps we have
          for (let i = 0; i < steps.length; i++) {
            const step = steps[i];
            if (step.type === 'navigation') {
              hasNavigationStep = true;
            } else if (step.type === 'click') {
              hasClickStep = true;
              hasElementValidationStep = true;
              
              // Check for calendar date steps
              if (step.element && step.element.includes('date') && step.element.includes('calendar')) {
                hasCalendarDateStep = true;
              }
            } else if (step.type === 'input') {
              // Determine if this is a credential field or eSign field
              const isCredential = step.element && (
                step.element.toLowerCase().includes('username') ||
                step.element.toLowerCase().includes('user name') ||
                step.element.toLowerCase().includes('email') ||
                step.element.toLowerCase().includes('password') ||
                step.element.toLowerCase().includes('login') ||
                step.element.toLowerCase().includes('esign') ||
                step.element.toLowerCase().includes('e-sign') ||
                step.element.toLowerCase().includes('e-signature') ||
                step.element.toLowerCase().includes('signature'));
              
              if (isCredential) {
                hasEnterStep = true;
              } else {
                hasInputStep = true;
              }
              
              hasElementValidationStep = true;
            } else if (step.type === 'select') {
              hasSelectStep = true;
              hasElementValidationStep = true;
            } else if (step.type === 'checkbox') {
              hasCheckboxStep = true;
              hasElementValidationStep = true;
            } else if (step.type === 'radio') {
              hasRadioStep = true;
              hasElementValidationStep = true;
            } else if (step.type === 'assertion') {
              if (step.element && step.element.includes('page title')) {
                hasPageTitleStep = true;
              } else {
                hasTextValidationStep = true;
              }
            }
          }
          
          // Add navigation step definition
          if (hasNavigationStep) {
            stepDefs += `    @Given("I navigate to {string}")\n`;
            stepDefs += `    public void i_navigate_to(String url) {\n`;
            stepDefs += `        driver.get(url);\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add element validation step definition
          if (hasElementValidationStep) {
            stepDefs += `    @Then("I should see the element {string}")\n`;
            stepDefs += `    public void i_should_see_the_element(String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));\n`;
            stepDefs += `        bp.scrollToWebElement(el);\n`;
            stepDefs += `        Assert.assertTrue(el.isDisplayed(), "Element '" + element + "' should be visible");\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add text validation step definition
          if (hasTextValidationStep) {
            stepDefs += `    @Then("I should see {string}")\n`;
            stepDefs += `    public void i_should_see(String text) {\n`;
            stepDefs += `        String xpath = getXPathForElement(text);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));\n`;
            stepDefs += `        Assert.assertTrue(el.isDisplayed(), "Text '" + text + "' should be visible");\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add page title validation step definition
          if (hasPageTitleStep) {
            stepDefs += `    @Then("I should see page title {string}")\n`;
            stepDefs += `    public void i_should_see_page_title(String expectedTitle) {\n`;
            stepDefs += `        wait.until(ExpectedConditions.titleContains(expectedTitle));\n`;
            stepDefs += `        Assert.assertTrue(driver.getTitle().contains(expectedTitle), \n`;
            stepDefs += `            "Page title should contain '" + expectedTitle + "' but was '" + driver.getTitle() + "'");\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add click step definition
          if (hasClickStep) {
            stepDefs += `    @When("I click on {string}")\n`;
            stepDefs += `    public void i_click_on(String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));\n`;
            stepDefs += `        bp.scrollToWebElement(el);\n`;
            stepDefs += `        JavaScriptExecutorUtil.waitForPageLoad(driver);\n`;
            stepDefs += `        el.click();\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add calendar date selection step definition
          if (hasCalendarDateStep) {
            stepDefs += `    @When("I select date {string} from calendar")\n`;
            stepDefs += `    public void i_select_date_from_calendar(String date) {\n`;
            stepDefs += `        try {\n`;
            stepDefs += `            // Wait for any calendar to be visible\n`;
            stepDefs += `            wait.until(ExpectedConditions.presenceOfElementLocated(\n`;
            stepDefs += `                By.xpath("//*[contains(@class, 'datepicker') or contains(@class, 'calendar') or contains(@class, 'ui-datepicker')][not(contains(@style, 'display: none'))]")));\n`;
            stepDefs += `            \n`;
            stepDefs += `            WebElement dateCell = null;\n`;
            stepDefs += `            \n`;
            stepDefs += `            // Strategy 1: Try the exact XPath from recording (for highlighted/selected dates)\n`;
            stepDefs += `            try {\n`;
            stepDefs += `                String xpath = getXPathForElement("date " + date + " in calendar");\n`;
            stepDefs += `                dateCell = driver.findElement(By.xpath(xpath));\n`;
            stepDefs += `            } catch (Exception e) { /* Try next strategy */ }\n`;
            stepDefs += `            \n`;
            stepDefs += `            // Strategy 2: Look for highlighted/active date cell\n`;
            stepDefs += `            if (dateCell == null) {\n`;
            stepDefs += `                try {\n`;
            stepDefs += `                    dateCell = driver.findElement(By.xpath(\n`;
            stepDefs += `                        "//*[contains(@class, 'ui-state-default') and (contains(@class, 'ui-state-highlight') or contains(@class, 'ui-state-active') or contains(@class, 'ui-state-hover'))]"));\n`;
            stepDefs += `                } catch (Exception e) { /* Try next strategy */ }\n`;
            stepDefs += `            }\n`;
            stepDefs += `            \n`;
            stepDefs += `            // Strategy 3: Look for the exact date text in a day cell\n`;
            stepDefs += `            if (dateCell == null) {\n`;
            stepDefs += `                try {\n`;
            stepDefs += `                    dateCell = driver.findElement(By.xpath(\n`;
            stepDefs += `                        "//*[contains(@class, 'ui-state-default') and text()='" + date + "' and not(ancestor::*[contains(@class, 'ui-datepicker-other-month')])]"));\n`;
            stepDefs += `                } catch (Exception e) { /* Try next strategy */ }\n`;
            stepDefs += `            }\n`;
            stepDefs += `            \n`;
            stepDefs += `            // Strategy 4: Look for any element with the date text that's in a calendar\n`;
            stepDefs += `            if (dateCell == null) {\n`;
            stepDefs += `                try {\n`;
            stepDefs += `                    dateCell = driver.findElement(By.xpath(\n`;
            stepDefs += `                        "//*[contains(@class, 'datepicker') or contains(@class, 'calendar') or contains(@class, 'ui-datepicker')]//*[text()='" + date + "' and not(contains(@class, 'disabled'))]"));\n`;
            stepDefs += `                } catch (Exception e) { /* Try next strategy */ }\n`;
            stepDefs += `            }\n`;
            stepDefs += `            \n`;
            stepDefs += `            // Strategy 5: Look for a td with the date text\n`;
            stepDefs += `            if (dateCell == null) {\n`;
            stepDefs += `                try {\n`;
            stepDefs += `                    dateCell = driver.findElement(By.xpath("//td[text()='" + date + "' or .//*[text()='" + date + "']]"));\n`;
            stepDefs += `                } catch (Exception e) { /* Try next strategy */ }\n`;
            stepDefs += `            }\n`;
            stepDefs += `            \n`;
            stepDefs += `            // Strategy 6: Look for a day cell with the date as its text content\n`;
            stepDefs += `            if (dateCell == null) {\n`;
            stepDefs += `                try {\n`;
            stepDefs += `                    dateCell = driver.findElement(By.xpath("//*[@role='gridcell' and normalize-space(.)='" + date + "']"));\n`;
            stepDefs += `                } catch (Exception e) { /* Try next strategy */ }\n`;
            stepDefs += `            }\n`;
            stepDefs += `            \n`;
            stepDefs += `            // If we found a date cell, click it\n`;
            stepDefs += `            if (dateCell != null) {\n`;
            stepDefs += `                bp.scrollToWebElement(dateCell);\n`;
            stepDefs += `                dateCell.click();\n`;
            stepDefs += `            } else {\n`;
            stepDefs += `                throw new RuntimeException("Could not find date '" + date + "' in the calendar");\n`;
            stepDefs += `            }\n`;
            stepDefs += `        } catch (Exception e) {\n`;
            stepDefs += `            throw new RuntimeException("Error selecting date from calendar: " + e.getMessage(), e);\n`;
            stepDefs += `        }\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add enter step definition for credentials and eSign
          if (hasEnterStep) {
            stepDefs += `    @When("I enter {string} into {string}")\n`;
            stepDefs += `    public void i_enter_into(String value, String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));\n`;
            stepDefs += `        el.sendKeys(value);\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add input step definition for other text fields
          if (hasInputStep) {
            stepDefs += `    @When("I input {string} into {string}")\n`;
            stepDefs += `    public void i_input_into(String value, String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));\n`;
            stepDefs += `        bp.scrollToWebElement(el);\n`;
            stepDefs += `        value = value+BasePage.generateRandomString(5);\n`;
            stepDefs += `        el.sendKeys(value);\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add select step definition
          if (hasSelectStep) {
            stepDefs += `    @When("I select {string} from {string}")\n`;
            stepDefs += `    public void i_select_from(String value, String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));\n`;
            stepDefs += `        bp.scrollToWebElement(el);\n`;
            stepDefs += `        Select dropdown = new Select(el);\n`;
            stepDefs += `        dropdown.selectByVisibleText(value);\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add checkbox step definitions
          if (hasCheckboxStep) {
            // Check checkbox
            stepDefs += `    @When("I check {string}")\n`;
            stepDefs += `    public void i_check(String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));\n`;
            stepDefs += `        bp.scrollToWebElement(el);\n`;
            stepDefs += `        if (!el.isSelected()) {\n`;
            stepDefs += `            el.click();\n`;
            stepDefs += `        }\n`;
            stepDefs += `    }\n\n`;
            
            // Uncheck checkbox
            stepDefs += `    @When("I uncheck {string}")\n`;
            stepDefs += `    public void i_uncheck(String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));\n`;
            stepDefs += `        bp.scrollToWebElement(el);\n`;
            stepDefs += `        if (el.isSelected()) {\n`;
            stepDefs += `            el.click();\n`;
            stepDefs += `        }\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add radio button step definition
          if (hasRadioStep) {
            stepDefs += `    @When("I select radio button {string}")\n`;
            stepDefs += `    public void i_select_radio_button(String element) {\n`;
            stepDefs += `        String xpath = getXPathForElement(element);\n`;
            stepDefs += `        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));\n`;
            stepDefs += `        bp.scrollToWebElement(el);\n`;
            stepDefs += `        if (!el.isSelected()) {\n`;
            stepDefs += `            el.click();\n`;
            stepDefs += `        }\n`;
            stepDefs += `    }\n\n`;
          }
          
          // Add helper method to get XPath for element
          stepDefs += `    // Helper method to get XPath for an element\n`;
          stepDefs += `    private String getXPathForElement(String element) {\n`;
          stepDefs += `        // First check if we have a stored XPath for this element\n`;
          stepDefs += `        if (elementXpaths.containsKey(element)) {\n`;
          stepDefs += `            return elementXpaths.get(element);\n`;
          stepDefs += `        }\n\n`;
          
          stepDefs += `        // If no stored XPath, try to generate one\n`;
          stepDefs += `        String elementText = element.trim();\n`;
          stepDefs += `        // Check if it's a calendar date\n`;
          stepDefs += `        if (elementText.contains("date") && elementText.contains("calendar")) {\n`;
          stepDefs += `            String dateText = elementText.replaceAll(".*date (\\\\d+) in.*", "$1");\n`;
          stepDefs += `            return String.format("//*[contains(@class, 'day') or @role='gridcell'][text()='%s']", dateText);\n`;
          stepDefs += `        }\n\n`;
          
          stepDefs += `        // Check if it's an input field with a name or placeholder\n`;
          stepDefs += `        if (elementText.contains("with name")) {\n`;
          stepDefs += `            String name = extractBetweenQuotes(elementText, "with name");\n`;
          stepDefs += `            if (name != null) {\n`;
          stepDefs += `                return String.format("//*[@name='%s']", name);\n`;
          stepDefs += `            }\n`;
          stepDefs += `        }\n\n`;
          
          stepDefs += `        // Check if it's an element with an ID\n`;
          stepDefs += `        if (elementText.contains("with id")) {\n`;
          stepDefs += `            String id = extractBetweenQuotes(elementText, "with id");\n`;
          stepDefs += `            if (id != null) {\n`;
          stepDefs += `                return String.format("//*[@id='%s']", id);\n`;
          stepDefs += `            }\n`;
          stepDefs += `        }\n\n`;
          
          stepDefs += `        // Check if it's a button or link with text\n`;
          stepDefs += `        if (!elementText.contains("with") && !elementText.contains("field")) {\n`;
          stepDefs += `            return String.format("//*[contains(text(), '%s')]", elementText.replace("'", "\\\\'")); \n`;
          stepDefs += `        }\n\n`;
          
          stepDefs += `        // Default fallback\n`;
          stepDefs += `        return "//body";\n`;
          stepDefs += `    }\n\n`;
          
          stepDefs += `    // Helper method to extract text between quotes\n`;
          stepDefs += `    private String extractBetweenQuotes(String text, String prefix) {\n`;
          stepDefs += `        int startIndex = text.indexOf(prefix);\n`;
          stepDefs += `        if (startIndex >= 0) {\n`;
          stepDefs += `            startIndex = text.indexOf("\\"", startIndex);\n`;
          stepDefs += `            if (startIndex >= 0) {\n`;
          stepDefs += `                int endIndex = text.indexOf("\\"", startIndex + 1);\n`;
          stepDefs += `                if (endIndex >= 0) {\n`;
          stepDefs += `                    return text.substring(startIndex + 1, endIndex);\n`;
          stepDefs += `                }\n`;
          stepDefs += `            }\n`;
          stepDefs += `        }\n`;
          stepDefs += `        return null;\n`;
          stepDefs += `    }\n`;
          
          stepDefs += `}`;
          
          return imports + stepDefs;
        }
        
        // Helper function to download files
        function downloadFile(content, filename, contentType) {
          const blob = new Blob([content], { type: contentType });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          a.click();
          URL.revokeObjectURL(url);
        }
        
        // Function to show a notification
        function showNotification(message, type = 'success') {
          const notification = document.createElement('div');
          notification.className = `notification ${type}`;
          notification.textContent = message;
          document.body.appendChild(notification);
          
          // Remove the notification after 3 seconds
          setTimeout(() => {
            if (document.body.contains(notification)) {
              document.body.removeChild(notification);
            }
          }, 3000);
        }
        
        // Make steps editable
        function makeStepsEditable() {
          // Check if button already exists
          if (document.getElementById('editStepsBtn')) {
            return;
          }
          
          const editBtn = document.createElement('button');
          editBtn.id = 'editStepsBtn';
          editBtn.className = 'btn btn-sm btn-outline-secondary';
          editBtn.textContent = 'Edit Steps';
          editBtn.title = 'Edit the recorded steps';
          
          const outputControls = document.querySelector('#gherkin-tab .output-controls');
          outputControls.prepend(editBtn);
          
          editBtn.addEventListener('click', function() {
            if (gherkinOutput.contentEditable === 'true') {
              // Save changes
              gherkinOutput.contentEditable = 'false';
              gherkinOutput.classList.remove('editing');
              this.textContent = 'Edit Steps';
              
              // Parse the edited content and update steps
              const lines = gherkinOutput.textContent.split('\n');
              const updatedSteps = [];
              
              // Simple parser for Gherkin syntax
              let currentStep = null;
              lines.forEach(line => {
                line = line.trim();
                if (line.startsWith('Given I navigate to')) {
                  const url = line.match(/"([^"]+)"/)[1];
                  currentStep = {
                    type: 'navigation',
                    url: url,
                    timestamp: Date.now()
                  };
                  updatedSteps.push(currentStep);
                } else if (line.startsWith('When I click on')) {
                  const element = line.match(/"([^"]+)"/)[1];
                  const xpath = line.includes('# xpath:') ? line.split('# xpath:')[1].trim() : '';
                  currentStep = {
                    type: 'click',
                    element: element,
                    xpath: xpath,
                    timestamp: Date.now()
                  };
                  updatedSteps.push(currentStep);
                } else if (line.startsWith('When I enter')) {
                  const matches = line.match(/"([^"]+)" into "([^"]+)"/);
                  if (matches && matches.length >= 3) {
                    const value = matches[1];
                    const element = matches[2];
                    const xpath = line.includes('# xpath:') ? line.split('# xpath:')[1].trim() : '';
                    currentStep = {
                      type: 'input',
                      element: element,
                      value: value,
                      xpath: xpath,
                      timestamp: Date.now()
                    };
                    updatedSteps.push(currentStep);
                  }
                } else if (line.startsWith('Then I should see')) {
                  const element = line.match(/"([^"]+)"/)[1];
                  const xpath = line.includes('# xpath:') ? line.split('# xpath:')[1].trim() : '';
                  currentStep = {
                    type: 'assertion',
                    element: element,
                    xpath: xpath,
                    timestamp: Date.now()
                  };
                  updatedSteps.push(currentStep);
                }
                // Add more step types as needed
              });
              
              // Update the steps array and storage
              if (updatedSteps.length > 0) {
                steps = updatedSteps;
                chrome.storage.local.set({ steps: steps }, function() {
                  console.log('Updated steps after editing');
                  showNotification('Steps updated successfully!');
                });
                
                // Regenerate Java code
                javaOutput.textContent = generateJavaStepDefinitions(steps);
              }
            } else {
              // Enter edit mode
              gherkinOutput.contentEditable = 'true';
              gherkinOutput.classList.add('editing');
              this.textContent = 'Save Changes';
              gherkinOutput.focus();
              showNotification('Edit mode enabled. Click "Save Changes" when done.', 'info');
            }
          });
        }
        
        // Add step organizer
        // Add step organizer
      // Add step organizer with direct DOM manipulation and inline styles
    function addStepOrganizer() {
      console.log('Setting up step organizer');
      
      // Check if button already exists
      if (document.getElementById('organizeStepsBtn')) {
        console.log('Organize Steps button already exists');
        return;
      }
      
      const outputControls = document.querySelector('#gherkin-tab .output-controls');
      if (!outputControls) {
        console.error('Output controls element not found');
        return;
      }
      
      const organizerBtn = document.createElement('button');
      organizerBtn.id = 'organizeStepsBtn';
      organizerBtn.className = 'btn btn-sm btn-outline-secondary';
      organizerBtn.textContent = 'Organize Steps';
      organizerBtn.title = 'Filter and organize recorded steps';
      
      outputControls.prepend(organizerBtn);
      console.log('Organize Steps button added');
      
      organizerBtn.addEventListener('click', function() {
        console.log('Organize Steps button clicked');
        
        if (steps.length === 0) {
          showNotification('No steps to organize.', 'info');
          return;
        }
        
        // Create modal directly with DOM API
        const modalOverlay = document.createElement('div');
        modalOverlay.style.position = 'fixed';
        modalOverlay.style.top = '0';
        modalOverlay.style.left = '0';
        modalOverlay.style.width = '100%';
        modalOverlay.style.height = '100%';
        modalOverlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        modalOverlay.style.zIndex = '9999';
        modalOverlay.style.display = 'flex';
        modalOverlay.style.justifyContent = 'center';
        modalOverlay.style.alignItems = 'center';
        
        const modalContent = document.createElement('div');
        modalContent.style.backgroundColor = '#fff';
        modalContent.style.borderRadius = '8px';
        modalContent.style.width = '80%';
        modalContent.style.maxWidth = '500px';
        modalContent.style.maxHeight = '80vh';
        modalContent.style.display = 'flex';
        modalContent.style.flexDirection = 'column';
        modalContent.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.3)';
        
        // Modal header
        const modalHeader = document.createElement('div');
        modalHeader.style.padding = '12px 16px';
        modalHeader.style.borderBottom = '1px solid #dee2e6';
        modalHeader.style.display = 'flex';
        modalHeader.style.justifyContent = 'space-between';
        modalHeader.style.alignItems = 'center';
        
        const modalTitle = document.createElement('h3');
        modalTitle.style.margin = '0';
        modalTitle.style.fontSize = '18px';
        modalTitle.textContent = 'Organize Steps';
        
        const closeButton = document.createElement('button');
        closeButton.style.background = 'none';
        closeButton.style.border = 'none';
        closeButton.style.fontSize = '24px';
        closeButton.style.cursor = 'pointer';
        closeButton.innerHTML = '&times;';
        closeButton.onclick = function() {
          document.body.removeChild(modalOverlay);
        };
        
        modalHeader.appendChild(modalTitle);
        modalHeader.appendChild(closeButton);
        
        // Modal body
        const modalBody = document.createElement('div');
        modalBody.style.padding = '16px';
        modalBody.style.overflowY = 'auto';
        modalBody.style.flex = '1';
        
        // Filter controls
        const filterControls = document.createElement('div');
        filterControls.style.marginBottom = '16px';
        filterControls.style.display = 'flex';
        filterControls.style.gap = '16px';
        
        // Click filter
        const clickLabel = document.createElement('label');
        clickLabel.style.display = 'flex';
        clickLabel.style.alignItems = 'center';
        clickLabel.style.gap = '4px';
        
        const clickCheckbox = document.createElement('input');
        clickCheckbox.type = 'checkbox';
        clickCheckbox.id = 'filter-clicks';
        clickCheckbox.checked = true;
        
        clickLabel.appendChild(clickCheckbox);
        clickLabel.appendChild(document.createTextNode('Show Clicks'));
        
        // Input filter
        const inputLabel = document.createElement('label');
        inputLabel.style.display = 'flex';
        inputLabel.style.alignItems = 'center';
        inputLabel.style.gap = '4px';
        
        const inputCheckbox = document.createElement('input');
        inputCheckbox.type = 'checkbox';
        inputCheckbox.id = 'filter-inputs';
        inputCheckbox.checked = true;
        
        inputLabel.appendChild(inputCheckbox);
        inputLabel.appendChild(document.createTextNode('Show Inputs'));
        
        // Assertion filter
        const assertionLabel = document.createElement('label');
        assertionLabel.style.display = 'flex';
        assertionLabel.style.alignItems = 'center';
        assertionLabel.style.gap = '4px';
        
        const assertionCheckbox = document.createElement('input');
        assertionCheckbox.type = 'checkbox';
        assertionCheckbox.id = 'filter-assertions';
        assertionCheckbox.checked = true;
        
        assertionLabel.appendChild(assertionCheckbox);
        assertionLabel.appendChild(document.createTextNode('Show Assertions'));
        
        filterControls.appendChild(clickLabel);
        filterControls.appendChild(inputLabel);
        filterControls.appendChild(assertionLabel);
        
        // Step list
        const stepList = document.createElement('div');
        stepList.id = 'step-list';
        stepList.style.maxHeight = '300px';
        stepList.style.overflowY = 'auto';
        
        // Add steps to the list
        steps.forEach((step, index) => {
          const stepItem = document.createElement('div');
          stepItem.className = `step-item step-${step.type}`;
          stepItem.draggable = true;
          stepItem.dataset.index = index;
          stepItem.style.padding = '8px';
          stepItem.style.border = '1px solid #dee2e6';
          stepItem.style.borderRadius = '4px';
          stepItem.style.marginBottom = '8px';
          stepItem.style.display = 'flex';
          stepItem.style.alignItems = 'center';
          stepItem.style.backgroundColor = '#fff';
          
          // Step handle for drag and drop
          const stepHandle = document.createElement('div');
          stepHandle.style.cursor = 'grab';
          stepHandle.style.marginRight = '8px';
          stepHandle.style.color = '#6c757d';
          stepHandle.textContent = '⋮⋮';
          
          // Step content
          const stepContent = document.createElement('div');
          stepContent.style.flex = '1';
          
          // Step type
          const stepType = document.createElement('div');
          stepType.style.fontSize = '12px';
          stepType.style.color = '#6c757d';
          stepType.textContent = step.type;
          
          // Step text
          const stepText = document.createElement('div');
          stepText.style.fontFamily = 'monospace';
          
          // Generate step text based on type
          let textContent = '';
          if (step.type === 'navigation') {
            textContent = `Given I navigate to "${step.url}"`;
          } else if (step.type === 'click') {
            textContent = `When I click on "${step.element}"`;
          } else if (step.type === 'input') {
            textContent = `When I enter "${step.value}" into "${step.element}"`;
          } else if (step.type === 'assertion') {
            textContent = `Then I should see "${step.element}"`;
          } else if (step.type === 'select') {
            textContent = `When I select "${step.value}" from "${step.element}"`;
          } else if (step.type === 'checkbox') {
            textContent = `When I ${step.checked ? 'check' : 'uncheck'} "${step.element}"`;
          } else if (step.type === 'radio') {
            textContent = `When I select radio button "${step.element}"`;
          }
          
          stepText.textContent = textContent;
          
          // Step remove button
          const stepRemove = document.createElement('div');
          stepRemove.style.cursor = 'pointer';
          stepRemove.style.color = '#dc3545';
          stepRemove.textContent = '✕';
          stepRemove.onclick = function() {
            stepItem.remove();
          };
          
          // Assemble step item
          stepContent.appendChild(stepType);
          stepContent.appendChild(stepText);
          stepItem.appendChild(stepHandle);
          stepItem.appendChild(stepContent);
          stepItem.appendChild(stepRemove);
          stepList.appendChild(stepItem);
        });
        
        // Add drag and drop functionality
        let draggedItem = null;
        
        // Modal footer
        const modalFooter = document.createElement('div');
        modalFooter.style.padding = '12px 16px';
        modalFooter.style.borderTop = '1px solid #dee2e6';
        modalFooter.style.display = 'flex';
        modalFooter.style.justifyContent = 'flex-end';
        
        const applyButton = document.createElement('button');
        applyButton.className = 'btn btn-primary';
        applyButton.textContent = 'Apply';
        applyButton.style.marginRight = '8px';
        applyButton.onclick = function() {
          // Get the new order of steps
          const newSteps = [];
          document.querySelectorAll('.step-item').forEach(item => {
            if (item.style.display !== 'none') {
              const index = parseInt(item.dataset.index);
              if (!isNaN(index) && index >= 0 && index < steps.length) {
                newSteps.push(steps[index]);
              }
            }
          });
          
          // Update the steps array and storage
          if (newSteps.length > 0) {
            steps = newSteps;
            chrome.storage.local.set({ steps: steps }, function() {
              console.log('Updated steps after organizing');
              updateUI();
              showNotification('Steps organized successfully!');
            });
          }
          
          document.body.removeChild(modalOverlay);
        };
        
        const cancelButton = document.createElement('button');
        cancelButton.className = 'btn btn-secondary';
        cancelButton.textContent = 'Cancel';
        cancelButton.onclick = function() {
          document.body.removeChild(modalOverlay);
        };
        
        modalFooter.appendChild(applyButton);
        modalFooter.appendChild(cancelButton);
        
        // Assemble modal
        modalBody.appendChild(filterControls);
        modalBody.appendChild(stepList);
        
        modalContent.appendChild(modalHeader);
        modalContent.appendChild(modalBody);
        modalContent.appendChild(modalFooter);
        
        modalOverlay.appendChild(modalContent);
        document.body.appendChild(modalOverlay);
        
        console.log('Modal created and added to DOM');
        
        // Set up filter functionality
        clickCheckbox.addEventListener('change', function() {
          const clickSteps = document.querySelectorAll('.step-click');
          clickSteps.forEach(step => {
            step.style.display = this.checked ? 'flex' : 'none';
          });
        });
        
        inputCheckbox.addEventListener('change', function() {
          const inputSteps = document.querySelectorAll('.step-input');
          inputSteps.forEach(step => {
            step.style.display = this.checked ? 'flex' : 'none';
          });
        });
        
        assertionCheckbox.addEventListener('change', function() {
          const assertionSteps = document.querySelectorAll('.step-assertion');
          assertionSteps.forEach(step => {
            step.style.display = this.checked ? 'flex' : 'none';
          });
        });
        
        // Set up drag and drop
        document.querySelectorAll('.step-item').forEach(item => {
          item.addEventListener('dragstart', function() {
            draggedItem = this;
            setTimeout(() => {
              this.style.opacity = '0.5';
            }, 0);
          });
          
          item.addEventListener('dragend', function() {
            this.style.opacity = '1';
            draggedItem = null;
          });
          
          item.addEventListener('dragover', function(e) {
            e.preventDefault();
          });
          
          item.addEventListener('drop', function(e) {
            e.preventDefault();
            if (draggedItem && draggedItem !== this) {
              const allItems = Array.from(document.querySelectorAll('.step-item'));
              const draggedIndex = allItems.indexOf(draggedItem);
              const dropIndex = allItems.indexOf(this);
              
              if (draggedIndex < dropIndex) {
                this.parentNode.insertBefore(draggedItem, this.nextSibling);
              } else {
                this.parentNode.insertBefore(draggedItem, this);
              }
            }
          });
        });
      });
    }
        
        // Add cleanup button
        function addCleanupButton() {
          // Check if button already exists
          if (document.getElementById('cleanupBtn')) {
            return;
          }
          
          const cleanupBtn = document.createElement('button');
          cleanupBtn.id = 'cleanupBtn';
          cleanupBtn.className = 'btn btn-sm btn-outline-secondary';
          cleanupBtn.textContent = 'Clean Up Steps';
          cleanupBtn.title = 'Remove duplicate validations and simplify steps';
          
          const outputControls = document.querySelector('#gherkin-tab .output-controls');
          outputControls.prepend(cleanupBtn);
          
          cleanupBtn.addEventListener('click', function() {
            if (steps.length === 0) {
              showNotification('No steps to clean up.', 'info');
              return;
            }
            
            // Create a simplified version of the steps
            const cleanedSteps = cleanupSteps(steps);
            
            // Update the steps array and storage
            steps = cleanedSteps;
            chrome.storage.local.set({ steps: steps }, function() {
              console.log('Updated steps after cleanup');
              updateUI();
              showNotification('Steps cleaned up successfully!');
            });
          });
        }
        
        // Function to clean up steps
        function cleanupSteps(originalSteps) {
          const cleanedSteps = [];
          let lastElement = null;
          let lastPageTitle = null;
          
          // First, add the navigation step
          const navigationStep = originalSteps.find(step => step.type === 'navigation');
          if (navigationStep) {
            cleanedSteps.push(navigationStep);
          }
          
          // Process the rest of the steps
          for (let i = 0; i < originalSteps.length; i++) {
            const step = originalSteps[i];
            
            // Skip navigation steps as we've already handled them
            if (step.type === 'navigation') continue;
            
            // Handle page title assertions
            if (step.type === 'assertion' && step.element.includes('page title')) {
              // Only add if it's a new page title
              if (step.element !== lastPageTitle) {
                cleanedSteps.push(step);
                lastPageTitle = step.element;
              }
              continue;
            }
            
            // Handle action steps (click, input, select)
            if (step.type === 'click' || step.type === 'input' || step.type === 'select') {
              // Skip if this is a duplicate action on the same element
              if (i > 0 &&
                  originalSteps[i-1].type === step.type &&
                  originalSteps[i-1].element === step.element) {
                continue;
              }
              
              // Add the step
              cleanedSteps.push(step);
              lastElement = step.element;
              continue;
            }
            
            // Add all other steps
            cleanedSteps.push(step);
          }
          
          return cleanedSteps;
        }
        
        // Add debug button
        const debugBtn = document.createElement('button');
        debugBtn.textContent = 'Debug';
        debugBtn.className = 'btn btn-sm btn-outline-secondary';
        debugBtn.style.marginLeft = '8px';
        document.querySelector('.recording-controls').appendChild(debugBtn);
        
        debugBtn.addEventListener('click', function() {
          chrome.storage.local.get(null, function(data) {
            console.log('Storage state:', data);
            let debugInfo = `Storage state:\n`;
            debugInfo += `- isRecording: ${data.isRecording}\n`;
            debugInfo += `- steps: ${data.steps ? data.steps.length : 0}\n`;
            
            if (data.steps && data.steps.length > 0) {
              debugInfo += `\nLast step:\n`;
              const lastStep = data.steps[data.steps.length - 1];
              debugInfo += `- Type: ${lastStep.type}\n`;
              debugInfo += `- Element: ${lastStep.element}\n`;
              debugInfo += `- Timestamp: ${new Date(lastStep.timestamp).toLocaleTimeString()}\n`;
            }
            
            alert(debugInfo);
          });
        });
        
        // Add reset button
        const resetBtn = document.createElement('button');
        resetBtn.textContent = 'Reset';
        resetBtn.className = 'btn btn-sm btn-outline-danger';
        resetBtn.style.marginLeft = '8px';
        document.querySelector('.recording-controls').appendChild(resetBtn);
        
        resetBtn.addEventListener('click', function() {
          if (confirm('This will reset all extension data. Continue?')) {
            chrome.storage.local.clear(function() {
              console.log('Storage cleared');
              steps = [];
              isRecording = false;
              if (pollInterval) {
                clearInterval(pollInterval);
                pollInterval = null;
              }
              updateUI();
              showNotification('Extension reset successfully', 'info');
            });
          }
        });
        
        // Add a reload button
        const reloadBtn = document.createElement('button');
        reloadBtn.id = 'reloadBtn';
        reloadBtn.textContent = 'Reload Steps';
        reloadBtn.className = 'btn btn-sm btn-outline-secondary';
        reloadBtn.style.marginLeft = '8px';
        document.querySelector('.recording-controls').appendChild(reloadBtn);
        
        reloadBtn.addEventListener('click', function() {
          chrome.storage.local.get(['steps'], function(data) {
            console.log('Reloaded steps from storage:', data.steps ? data.steps.length : 0);
            if (data.steps && data.steps.length > 0) {
              steps = data.steps;
              updateUI();
              showNotification('Steps reloaded from storage: ' + steps.length, 'success');
            } else {
              showNotification('No steps found in storage.', 'info');
            }
          });
        });

        // Function to add settings button to header
    function addSettingsButton() {
      console.log('Adding settings button to header');
      
      // Check if button already exists
      if (document.getElementById('settingsBtn')) {
        console.log('Settings button already exists');
        return;
      }
      
      // Find the header element
      const header = document.querySelector('header');
      if (!header) {
        console.error('Header element not found');
        return;
      }
      
      // Create settings button
      const settingsBtn = document.createElement('button');
      settingsBtn.id = 'settingsBtn';
      settingsBtn.className = 'btn btn-primary btn-sm';
      settingsBtn.style.marginLeft = 'auto';
      settingsBtn.style.display = 'flex';
      settingsBtn.style.alignItems = 'center';
      settingsBtn.style.gap = '4px';
      settingsBtn.innerHTML = '<span style="font-weight: bold;">⚙</span> Settings';
      
      // Add button to header
      header.appendChild(settingsBtn);
      console.log('Settings button added to header');
      
      // Add click handler
      settingsBtn.addEventListener('click', function() {
        console.log('Settings button clicked');
        showSettingsModal();
      });
    }

    

    // Function to show settings modal
    function showSettingsModal() {
      console.log('Showing settings modal');
      
      // Create modal overlay
      const modalOverlay = document.createElement('div');
      modalOverlay.style.position = 'fixed';
      modalOverlay.style.top = '0';
      modalOverlay.style.left = '0';
      modalOverlay.style.width = '100%';
      modalOverlay.style.height = '100%';
      modalOverlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
      modalOverlay.style.zIndex = '9999';
      modalOverlay.style.display = 'flex';
      modalOverlay.style.justifyContent = 'center';
      modalOverlay.style.alignItems = 'center';
      
      // Create modal content
      const modalContent = document.createElement('div');
      modalContent.style.backgroundColor = '#fff';
      modalContent.style.borderRadius = '8px';
      modalContent.style.width = '80%';
      modalContent.style.maxWidth = '400px';
      modalContent.style.display = 'flex';
      modalContent.style.flexDirection = 'column';
      modalContent.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.3)';
      
      // Modal header
      const modalHeader = document.createElement('div');
      modalHeader.style.padding = '12px 16px';
      modalHeader.style.borderBottom = '1px solid #dee2e6';
      modalHeader.style.display = 'flex';
      modalHeader.style.justifyContent = 'space-between';
      modalHeader.style.alignItems = 'center';
      
      const modalTitle = document.createElement('h3');
      modalTitle.style.margin = '0';
      modalTitle.style.fontSize = '18px';
      modalTitle.textContent = 'Settings';
      
      const closeButton = document.createElement('button');
      closeButton.style.background = 'none';
      closeButton.style.border = 'none';
      closeButton.style.fontSize = '24px';
      closeButton.style.cursor = 'pointer';
      closeButton.innerHTML = '&times;';
      closeButton.onclick = function() {
        document.body.removeChild(modalOverlay);
      };
      
      modalHeader.appendChild(modalTitle);
      modalHeader.appendChild(closeButton);
      
      // Modal body
      const modalBody = document.createElement('div');
      modalBody.style.padding = '16px';
      
      // Theme section
      const themeSection = document.createElement('div');
      themeSection.style.marginBottom = '24px';
      
      const themeTitle = document.createElement('h4');
      themeTitle.style.marginTop = '0';
      themeTitle.style.marginBottom = '12px';
      themeTitle.textContent = 'Theme';
      
      const themeOptions = document.createElement('div');
      themeOptions.style.display = 'flex';
      themeOptions.style.gap = '10px';
      themeOptions.style.marginBottom = '16px';
      
      // Light theme option
      const lightTheme = document.createElement('div');
      lightTheme.className = 'theme-option';
      lightTheme.dataset.theme = 'light';
      lightTheme.title = 'Light Theme';
      lightTheme.style.width = '40px';
      lightTheme.style.height = '40px';
      lightTheme.style.borderRadius = '50%';
      lightTheme.style.cursor = 'pointer';
      lightTheme.style.border = '2px solid transparent';
      lightTheme.style.background = 'linear-gradient(135deg, #ffffff 0%, #e6f2ff 100%)';
      lightTheme.style.transition = 'transform 0.2s ease, border-color 0.2s ease';
      
      // Dark theme option
      const darkTheme = document.createElement('div');
      darkTheme.className = 'theme-option';
      darkTheme.dataset.theme = 'dark';
      darkTheme.title = 'Dark Theme';
      darkTheme.style.width = '40px';
      darkTheme.style.height = '40px';
      darkTheme.style.borderRadius = '50%';
      darkTheme.style.cursor = 'pointer';
      darkTheme.style.border = '2px solid transparent';
      darkTheme.style.background = 'linear-gradient(135deg, #333333 0%, #1a2733 100%)';
      darkTheme.style.transition = 'transform 0.2s ease, border-color 0.2s ease';
      
      // Sepia theme option
      const sepiaTheme = document.createElement('div');
      sepiaTheme.className = 'theme-option';
      sepiaTheme.dataset.theme = 'sepia';
      sepiaTheme.title = 'Sepia Theme';
      sepiaTheme.style.width = '40px';
      sepiaTheme.style.height = '40px';
      sepiaTheme.style.borderRadius = '50%';
      sepiaTheme.style.cursor = 'pointer';
      sepiaTheme.style.border = '2px solid transparent';
      sepiaTheme.style.background = 'linear-gradient(135deg, #faf6f0 0%, #e8f0f5 100%)';
      sepiaTheme.style.transition = 'transform 0.2s ease, border-color 0.2s ease';
      
      // Add theme options to container
      themeOptions.appendChild(lightTheme);
      themeOptions.appendChild(darkTheme);
      themeOptions.appendChild(sepiaTheme);
      
      // Add theme section to modal body
      themeSection.appendChild(themeTitle);
      themeSection.appendChild(themeOptions);
      modalBody.appendChild(themeSection);
      
      // Options section
      const optionsSection = document.createElement('div');
      
      const optionsTitle = document.createElement('h4');
      optionsTitle.style.marginTop = '0';
      optionsTitle.style.marginBottom = '12px';
      optionsTitle.textContent = 'Options';
      
      optionsSection.appendChild(optionsTitle);
      
      // Create option switches
      const options = [
        { id: 'autoGenerateJava', label: 'Auto-generate Java code', defaultChecked: true },
        { id: 'showStepNumbers', label: 'Show step numbers', defaultChecked: true },
        { id: 'autoCopy', label: 'Auto-copy to clipboard', defaultChecked: false }
      ];
      
      options.forEach(option => {
        const switchContainer = document.createElement('div');
        switchContainer.style.display = 'flex';
        switchContainer.style.alignItems = 'center';
        switchContainer.style.marginBottom = '12px';
        
        const switchLabel = document.createElement('span');
        switchLabel.style.flex = '1';
        switchLabel.textContent = option.label;
        
        const switchWrapper = document.createElement('div');
        switchWrapper.style.position = 'relative';
        switchWrapper.style.display = 'inline-block';
        switchWrapper.style.width = '50px';
        switchWrapper.style.height = '24px';
        
        const switchInput = document.createElement('input');
        switchInput.type = 'checkbox';
        switchInput.id = option.id;
        switchInput.checked = option.defaultChecked;
        switchInput.style.opacity = '0';
        switchInput.style.width = '0';
        switchInput.style.height = '0';
        
        const switchSlider = document.createElement('span');
        switchSlider.style.position = 'absolute';
        switchSlider.style.cursor = 'pointer';
        switchSlider.style.top = '0';
        switchSlider.style.left = '0';
        switchSlider.style.right = '0';
        switchSlider.style.bottom = '0';
        switchSlider.style.backgroundColor = '#ccc';
        switchSlider.style.transition = '.4s';
        switchSlider.style.borderRadius = '24px';
        
        // Create the slider button
        const sliderButton = document.createElement('span');
        sliderButton.style.position = 'absolute';
        sliderButton.style.content = '""';
        sliderButton.style.height = '16px';
        sliderButton.style.width = '16px';
        sliderButton.style.left = '4px';
        sliderButton.style.bottom = '4px';
        sliderButton.style.backgroundColor = 'white';
        sliderButton.style.transition = '.4s';
        sliderButton.style.borderRadius = '50%';
        
        switchSlider.appendChild(sliderButton);
        switchWrapper.appendChild(switchInput);
        switchWrapper.appendChild(switchSlider);
        
        switchContainer.appendChild(switchLabel);
        switchContainer.appendChild(switchWrapper);
        
        optionsSection.appendChild(switchContainer);
        
        // Add change event
        switchInput.addEventListener('change', function() {
          if (this.checked) {
            switchSlider.style.backgroundColor = '#4a86e8';
            sliderButton.style.transform = 'translateX(26px)';
          } else {
            switchSlider.style.backgroundColor = '#ccc';
            sliderButton.style.transform = 'translateX(0)';
          }
          
          // Save setting to storage
          chrome.storage.local.set({ [option.id]: this.checked });
          
          // Handle specific actions based on setting
          if (option.id === 'showStepNumbers' && typeof updateUI === 'function') {
            updateUI();
          } else if (option.id === 'autoGenerateJava' && this.checked && steps && steps.length > 0) {
            if (typeof generateJavaStepDefinitions === 'function' && typeof javaOutput !== 'undefined') {
              javaOutput.textContent = generateJavaStepDefinitions(steps);
            }
          }
        });
        
        // Set initial state
        if (switchInput.checked) {
          switchSlider.style.backgroundColor = '#4a86e8';
          sliderButton.style.transform = 'translateX(26px)';
        }
      });
      
      // Load settings from storage
      chrome.storage.local.get(['autoGenerateJava', 'showStepNumbers', 'autoCopy', 'theme'], function(data) {
        if (data.autoGenerateJava !== undefined) {
          const input = document.getElementById('autoGenerateJava');
          input.checked = data.autoGenerateJava;
          input.dispatchEvent(new Event('change'));
        }
        
        if (data.showStepNumbers !== undefined) {
          const input = document.getElementById('showStepNumbers');
          input.checked = data.showStepNumbers;
          input.dispatchEvent(new Event('change'));
        }
        
        if (data.autoCopy !== undefined) {
          const input = document.getElementById('autoCopy');
          input.checked = data.autoCopy;
          input.dispatchEvent(new Event('change'));
        }
        
        if (data.theme) {
          const themeOption = document.querySelector(`.theme-option[data-theme="${data.theme}"]`);
          if (themeOption) {
            themeOption.style.borderColor = '#4a86e8';
          }
        } else {
          // Default to light theme
          lightTheme.style.borderColor = '#4a86e8';
        }
      });
      
      // Add theme click handlers
      [lightTheme, darkTheme, sepiaTheme].forEach(option => {
        option.addEventListener('click', function() {
          const theme = this.dataset.theme;
          
          // Update active state
          document.querySelectorAll('.theme-option').forEach(el => {
            el.style.borderColor = 'transparent';
          });
          this.style.borderColor = '#4a86e8';
          
          // Apply theme
          setTheme(theme);
          
          // Save to storage
          chrome.storage.local.set({ theme: theme });
        });
        
        // Add hover effect
        option.addEventListener('mouseover', function() {
          this.style.transform = 'scale(1.1)';
        });
        
        option.addEventListener('mouseout', function() {
          this.style.transform = 'scale(1)';
        });
      });
      
      // Add options section to modal body
      modalBody.appendChild(optionsSection);
      
      // Assemble modal
      modalContent.appendChild(modalHeader);
      modalContent.appendChild(modalBody);
      
      modalOverlay.appendChild(modalContent);
      document.body.appendChild(modalOverlay);
    }

    // Function to set theme
    function setTheme(theme) {
      console.log('Setting theme:', theme);
      document.body.setAttribute('data-theme', theme);
      
      // Apply theme colors directly
      if (theme === 'light') {
        document.body.style.backgroundColor = '#e6f2ff'; // Light blue
        document.body.style.color = '#333333';
      } else if (theme === 'dark') {
        document.body.style.backgroundColor = '#1a2733'; // Dark blue
        document.body.style.color = '#e0e0e0';
      } else if (theme === 'sepia') {
        document.body.style.backgroundColor = '#e8f0f5'; // Light tan-blue
        document.body.style.color = '#5d4a33';
      }
    }
        
        // Initialize the UI enhancements - make sure this only appears ONCE
        function initializeUIEnhancements() {
          // Check if buttons already exist to avoid duplicates
          if (!document.getElementById('editStepsBtn')) {
            makeStepsEditable();
          }
          if (!document.getElementById('organizeStepsBtn')) {
            addStepOrganizer();
          }
          if (!document.getElementById('cleanupBtn')) {
            addCleanupButton();
          }
        }
        
        // Call the initialization function
        initializeUIEnhancements();
        
        // ===== NEW FEATURES ADDED BELOW =====
        
        // Theme management
        // Update the initThemeSettings function to ensure the settings button is visible
      function initThemeSettings() {
        // Check if settings button exists, if not create it
        if (!document.getElementById('settingsBtn')) {
          const header = document.querySelector('header');
          const headerActions = document.createElement('div');
          headerActions.className = 'header-actions';
          headerActions.style.display = 'flex';
          headerActions.style.gap = '8px';
          
          const settingsBtn = document.createElement('button');
          settingsBtn.id = 'settingsBtn';
          settingsBtn.className = 'btn btn-icon-only tooltip';
          settingsBtn.innerHTML = '<span class="glyphicon glyphicon-cog"></span><span class="tooltip-text">Settings</span>';
          settingsBtn.style.padding = '4px 8px';
          settingsBtn.style.backgroundColor = 'var(--primary-color)';
          settingsBtn.style.color = 'white';
          settingsBtn.style.border = 'none';
          settingsBtn.style.borderRadius = '4px';
          
          const helpBtn = document.createElement('button');
          helpBtn.id = 'helpBtn';
          helpBtn.className = 'btn btn-icon-only tooltip';
          helpBtn.innerHTML = '<span class="glyphicon glyphicon-question-sign"></span><span class="tooltip-text">Help</span>';
          helpBtn.style.padding = '4px 8px';
          helpBtn.style.backgroundColor = 'var(--primary-color)';
          helpBtn.style.color = 'white';
          helpBtn.style.border = 'none';
          helpBtn.style.borderRadius = '4px';
          
          headerActions.appendChild(settingsBtn);
          headerActions.appendChild(helpBtn);
          header.appendChild(headerActions);
          
          console.log('Created settings and help buttons');
        }
        
        // Rest of the function remains the same...
      }

        function setTheme(theme) {
          document.body.setAttribute('data-theme', theme);
        }

        // Settings panel
        // Update the initSettingsPanel function to ensure the settings panel is visible
      function initSettingsPanel() {
        const settingsBtn = document.getElementById('settingsBtn');
        const settingsPanel = document.getElementById('settingsPanel');
        const closeSettings = document.getElementById('closeSettings');
        
        if (!settingsPanel) {
          console.error('Settings panel not found');
          return;
        }
        
        // Make sure the settings panel has the correct styles
        settingsPanel.style.position = 'fixed';
        settingsPanel.style.top = '0';
        settingsPanel.style.right = '-300px';
        settingsPanel.style.width = '300px';
        settingsPanel.style.height = '100%';
        settingsPanel.style.backgroundColor = 'var(--card-background)';
        settingsPanel.style.boxShadow = '-2px 0 10px var(--shadow-color)';
        settingsPanel.style.zIndex = '1010';
        settingsPanel.style.transition = 'right 0.3s ease';
        settingsPanel.style.overflowY = 'auto';
        
        // Load settings from storage
        chrome.storage.local.get(['autoGenerateJava', 'showStepNumbers', 'autoCopy'], function(data) {
          if (data.autoGenerateJava !== undefined) {
            document.getElementById('autoGenerateJava').checked = data.autoGenerateJava;
          }
          if (data.showStepNumbers !== undefined) {
            document.getElementById('showStepNumbers').checked = data.showStepNumbers;
          }
          if (data.autoCopy !== undefined) {
            document.getElementById('autoCopy').checked = data.autoCopy;
          }
        });
        
        // Settings toggle with direct style manipulation
        settingsBtn.addEventListener('click', function() {
          console.log('Settings button clicked');
          settingsPanel.style.right = '0';
        });
        
        closeSettings.addEventListener('click', function() {
          settingsPanel.style.right = '-300px';
        });
        
        // Click outside to close
        document.addEventListener('click', function(event) {
          if (!settingsPanel.contains(event.target) && event.target !== settingsBtn && !event.target.closest('#settingsBtn')) {
            settingsPanel.style.right = '-300px';
          }
        });
        
        // Save settings changes
        document.getElementById('autoGenerateJava').addEventListener('change', function() {
          chrome.storage.local.set({ autoGenerateJava: this.checked });
          if (this.checked && steps.length > 0) {
            javaOutput.textContent = generateJavaStepDefinitions(steps);
          }
        });
        
        document.getElementById('showStepNumbers').addEventListener('change', function() {
          chrome.storage.local.set({ showStepNumbers: this.checked });
          // Refresh output if needed
          updateUI();
        });
        
        document.getElementById('autoCopy').addEventListener('change', function() {
          chrome.storage.local.set({ autoCopy: this.checked });
        });
      }

        // Tour functionality
        function initTour() {
          // Create tour elements if they don't exist
          if (!document.getElementById('tourWelcome')) {
            // Add tour welcome dialog
            const tourWelcome = document.createElement('div');
            tourWelcome.id = 'tourWelcome';
            tourWelcome.className = 'tour-welcome';
            tourWelcome.innerHTML = `
              <div class="tour-welcome-icon">
                <span class="glyphicon glyphicon-info-sign"></span>
              </div>
              <h2>Welcome to Next Gen BDD!</h2>
              <p>Would you like a quick tour of the features?</p>
              <div class="tour-welcome-buttons">
                <button id="startTourBtn" class="btn btn-primary btn-ripple">Start Tour</button>
                <button id="skipTourBtn" class="btn btn-outline-secondary">Skip Tour</button>
              </div>
            `;
            document.body.appendChild(tourWelcome);
            
            // Add tour overlay
            const tourOverlay = document.createElement('div');
            tourOverlay.id = 'tourOverlay';
            tourOverlay.className = 'tour-overlay';
            document.body.appendChild(tourOverlay);
            
            // Add tour steps
            const tourSteps = [
              {
                id: 'tourStep1',
                title: 'Step 1: Configure Your Test',
                content: 'Enter a descriptive feature title and the URL you want to test. This will be used in your generated Cucumber feature file.'
              },
              {
                id: 'tourStep2',
                title: 'Step 2: Record Your Actions',
                content: 'Click "Start Recording" to begin capturing your interactions. The extension will record clicks, inputs, and other actions you perform on the website.'
              },
              {
                id: 'tourStep3',
                title: 'Step 3: Generate Code',
                content: 'After recording, your actions will be converted to Gherkin scenarios and Java step definitions automatically. Switch between tabs to view different outputs.'
              },
              {
                id: 'tourStep4',
                title: 'Step 4: Customize Settings',
                content: 'Click the settings icon to change themes and adjust options for your testing workflow. You can always restart the tour from the footer link.'
              }
            ];
            
            tourSteps.forEach((step, index) => {
              const tourStep = document.createElement('div');
              tourStep.id = step.id;
              tourStep.className = 'tour-step';
              
              const isFirst = index === 0;
              const isLast = index === tourSteps.length - 1;
              
              tourStep.innerHTML = `
                <div class="tour-step-header">
                  <h4 class="tour-step-title">${step.title}</h4>
                </div>
                <div class="tour-step-content">
                  ${step.content}
                </div>
                <div class="tour-step-footer">
                  <div class="tour-progress">
                    ${tourSteps.map((_, i) => `<span class="tour-dot${i === index ? ' active' : ''}"></span>`).join('')}
                  </div>
                  <div>
                    ${!isFirst ? `<button class="btn btn-sm btn-outline-secondary prev-step">Back</button>` : ''}
                    ${!isLast ? `<button class="btn btn-sm btn-primary next-step">Next</button>` : 
                              `<button class="btn btn-sm btn-primary finish-tour">Finish</button>`}
                  </div>
                </div>
              `;
              
              document.body.appendChild(tourStep);
            });
            
            // Add footer link if it doesn't exist
            if (!document.getElementById('showTourLink')) {
              const footer = document.querySelector('footer');
              const footerLinks = document.createElement('div');
              footerLinks.className = 'footer-links';
              footerLinks.innerHTML = '<a href="#" id="showTourLink">Show Tour</a>';
              footer.appendChild(footerLinks);
            }
          }
          
          const tourWelcome = document.getElementById('tourWelcome');
          const tourOverlay = document.getElementById('tourOverlay');
          const startTourBtn = document.getElementById('startTourBtn');
          const skipTourBtn = document.getElementById('skipTourBtn');
          const showTourLink = document.getElementById('showTourLink');
          const tourSteps = document.querySelectorAll('.tour-step');
          let currentStep = 0;
          
          // Check if first time user
          chrome.storage.local.get(['tourCompleted'], function(data) {
            if (data.tourCompleted !== true) {
              // Show welcome dialog after a short delay
              setTimeout(() => {
                tourWelcome.classList.add('active');
              }, 1000);
            }
          });
          
          // Start tour button
          startTourBtn.addEventListener('click', function() {
            tourWelcome.classList.remove('active');
            startTour();
          });
          
          // Skip tour button
          skipTourBtn.addEventListener('click', function() {
            tourWelcome.classList.remove('active');
            chrome.storage.local.set({ tourCompleted: true });
          });
          
          // Show tour link in footer
          showTourLink.addEventListener('click', function(e) {
            e.preventDefault();
            startTour();
          });
          
          // Next step buttons
          document.querySelectorAll('.next-step').forEach(btn => {
            btn.addEventListener('click', function() {
              goToStep(currentStep + 1);
            });
          });
          
          // Previous step buttons
          document.querySelectorAll('.prev-step').forEach(btn => {
            btn.addEventListener('click', function() {
              goToStep(currentStep - 1);
            });
          });
          
          // Finish tour button
          document.querySelector('.finish-tour').addEventListener('click', function() {
            endTour();
            chrome.storage.local.set({ tourCompleted: true });
          });
          
          function startTour() {
            tourOverlay.classList.add('active');
            goToStep(0);
          }
          
          function endTour() {
            tourOverlay.classList.remove('active');
            tourSteps.forEach(step => {
              step.classList.remove('active');
            });
          }
          
          function goToStep(stepIndex) {
            if (stepIndex < 0 || stepIndex >= tourSteps.length) return;
            
            // Hide current step
            if (tourSteps[currentStep]) {
              tourSteps[currentStep].classList.remove('active');
            }
            
            // Show new step
            currentStep = stepIndex;
            tourSteps[currentStep].classList.add('active');
            
            // Position the step based on relevant UI element
            positionTourStep(currentStep);
          }
          
          function positionTourStep(stepIndex) {
            const step = tourSteps[stepIndex];
            let targetElement;
            
            switch(stepIndex) {
              case 0: // Configure Test
                targetElement = document.querySelector('.card');
                break;
              case 1: // Record Actions
                targetElement = document.querySelector('.recording-controls');
                break;
              case 2: // Generate Code
                targetElement = document.querySelector('.tabs');
                break;
              case 3: // Settings
                targetElement = document.getElementById('settingsBtn');
                break;
            }
            
            if (targetElement) {
              const rect = targetElement.getBoundingClientRect();
              const stepRect = step.getBoundingClientRect();
              
              // Position to the right of the element if possible, otherwise below
              if (rect.right + stepRect.width + 20 < window.innerWidth) {
                step.style.left = `${rect.right + 20}px`;
                step.style.top = `${rect.top}px`;
              } else {
                step.style.left = `${rect.left}px`;
                step.style.top = `${rect.bottom + 20}px`;
              }
            }
          }
        }

        // Add ripple effect to buttons
        function addRippleEffect() {
          // Add ripple class to buttons that should have the effect
          document.querySelectorAll('.btn').forEach(button => {
            if (!button.classList.contains('btn-ripple')) {
              button.classList.add('btn-ripple');
            }
          });
          
          // Add event listeners for ripple effect
          document.addEventListener('click', function(e) {
            const target = e.target.closest('.btn-ripple');
            if (!target) return;
            
            const rect = target.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('span');
            ripple.className = 'ripple';
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            
            target.appendChild(ripple);
            
            setTimeout(() => {
              ripple.remove();
            }, 600);
          });
        }

        // Add help button functionality
        function initHelpButton() {
          const helpBtn = document.getElementById('helpBtn');
          if (helpBtn) {
            helpBtn.addEventListener('click', function() {
              // Show tour welcome
              document.getElementById('tourWelcome').classList.add('active');
            });
          }
        }
        // Add this function to your popup.js file
      function addSettingsAndHelpButtons() {
        console.log('Adding settings and help buttons');
        
        // First, check if buttons already exist
        if (document.getElementById('settingsBtn') && document.getElementById('helpBtn')) {
          console.log('Settings and help buttons already exist');
          return;
        }
        
        // Find the header element
        const header = document.querySelector('header');
        if (!header) {
          console.error('Header element not found');
          return;
        }
        
        // Create header actions container
        let headerActions = document.querySelector('.header-actions');
        if (!headerActions) {
          headerActions = document.createElement('div');
          headerActions.className = 'header-actions';
          headerActions.style.display = 'flex';
          headerActions.style.gap = '8px';
          headerActions.style.marginLeft = 'auto'; // Push to the right side
          header.appendChild(headerActions);
        }
        
        // Create settings button
        const settingsBtn = document.createElement('button');
        settingsBtn.id = 'settingsBtn';
        settingsBtn.className = 'btn btn-sm btn-primary';
        settingsBtn.innerHTML = '<span class="glyphicon glyphicon-cog"></span> Settings';
        settingsBtn.style.display = 'flex';
        settingsBtn.style.alignItems = 'center';
        settingsBtn.style.gap = '4px';
        
        // Create help button
        const helpBtn = document.createElement('button');
        helpBtn.id = 'helpBtn';
        helpBtn.className = 'btn btn-sm btn-info';
        helpBtn.innerHTML = '<span class="glyphicon glyphicon-question-sign"></span> Help';
        helpBtn.style.display = 'flex';
        helpBtn.style.alignItems = 'center';
        helpBtn.style.gap = '4px';
        
        // Add buttons to header actions
        headerActions.appendChild(settingsBtn);
        headerActions.appendChild(helpBtn);
        
        console.log('Settings and help buttons added to header');
        
        // Add event listeners
        settingsBtn.addEventListener('click', function() {
          console.log('Settings button clicked');
          showSettingsPanel();
        });
        
        helpBtn.addEventListener('click', function() {
          console.log('Help button clicked');
          showTourWelcome();
        });
      }

      // Function to show settings panel
      function showSettingsPanel() {
        console.log('Showing settings panel');
        
        // Check if settings panel exists, create it if not
        let settingsPanel = document.getElementById('settingsPanel');
        if (!settingsPanel) {
          console.log('Creating settings panel');
          settingsPanel = document.createElement('div');
          settingsPanel.id = 'settingsPanel';
          settingsPanel.className = 'settings-panel';
          settingsPanel.style.position = 'fixed';
          settingsPanel.style.top = '0';
          settingsPanel.style.right = '-300px';
          settingsPanel.style.width = '300px';
          settingsPanel.style.height = '100%';
          settingsPanel.style.backgroundColor = 'var(--card-background, white)';
          settingsPanel.style.boxShadow = '-2px 0 10px rgba(0, 0, 0, 0.1)';
          settingsPanel.style.zIndex = '1010';
          settingsPanel.style.transition = 'right 0.3s ease';
          settingsPanel.style.overflowY = 'auto';
          
          settingsPanel.innerHTML = `
            <div class="settings-header" style="
              padding: 16px;
              border-bottom: 1px solid var(--border-color, #dee2e6);
              display: flex;
              justify-content: space-between;
              align-items: center;
            ">
              <h3 style="margin: 0; color: var(--primary-color, #4a86e8);">Settings</h3>
              <span class="close" id="closeSettings" style="
                font-size: 24px;
                cursor: pointer;
                color: var(--secondary-color, #6c757d);
              ">&times;</span>
            </div>
            <div class="settings-body" style="padding: 16px;">
              <div class="settings-section" style="margin-bottom: 24px;">
                <h4 style="margin-top: 0; margin-bottom: 12px; color: var(--primary-color, #4a86e8);">Theme</h4>
                <div class="theme-options" style="display: flex; gap: 10px; margin-bottom: 16px;">
                  <div class="theme-option theme-light active" data-theme="light" title="Light Theme" style="
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    cursor: pointer;
                    border: 2px solid transparent;
                    background: linear-gradient(135deg, #ffffff 0%, #e6f2ff 100%);
                    transition: transform 0.2s ease, border-color 0.2s ease;
                  "></div>
                  <div class="theme-option theme-dark" data-theme="dark" title="Dark Theme" style="
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    cursor: pointer;
                    border: 2px solid transparent;
                    background: linear-gradient(135deg, #333333 0%, #1a2733 100%);
                    transition: transform 0.2s ease, border-color 0.2s ease;
                  "></div>
                  <div class="theme-option theme-sepia" data-theme="sepia" title="Sepia Theme" style="
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    cursor: pointer;
                    border: 2px solid transparent;
                    background: linear-gradient(135deg, #faf6f0 0%, #e8f0f5 100%);
                    transition: transform 0.2s ease, border-color 0.2s ease;
                  "></div>
                </div>
              </div>
              
              <div class="settings-section" style="margin-bottom: 24px;">
                <h4 style="margin-top: 0; margin-bottom: 12px; color: var(--primary-color, #4a86e8);">Options</h4>
                <div class="switch-container" style="display: flex; align-items: center; margin-bottom: 12px;">
                  <span class="switch-label" style="flex: 1;">Auto-generate Java code</span>
                  <label class="switch" style="position: relative; display: inline-block; width: 50px; height: 24px;">
                    <input type="checkbox" id="autoGenerateJava" checked>
                    <span class="slider" style="
                      position: absolute;
                      cursor: pointer;
                      top: 0;
                      left: 0;
                      right: 0;
                      bottom: 0;
                      background-color: var(--secondary-color, #6c757d);
                      transition: .4s;
                      border-radius: 24px;
                    "></span>
                  </label>
                </div>
                <div class="switch-container" style="display: flex; align-items: center; margin-bottom: 12px;">
                  <span class="switch-label" style="flex: 1;">Show step numbers</span>
                  <label class="switch" style="position: relative; display: inline-block; width: 50px; height: 24px;">
                    <input type="checkbox" id="showStepNumbers" checked>
                    <span class="slider" style="
                      position: absolute;
                      cursor: pointer;
                      top: 0;
                      left: 0;
                      right: 0;
                      bottom: 0;
                      background-color: var(--secondary-color, #6c757d);
                      transition: .4s;
                      border-radius: 24px;
                    "></span>
                  </label>
                </div>
                <div class="switch-container" style="display: flex; align-items: center; margin-bottom: 12px;">
                  <span class="switch-label" style="flex: 1;">Auto-copy to clipboard</span>
                  <label class="switch" style="position: relative; display: inline-block; width: 50px; height: 24px;">
                    <input type="checkbox" id="autoCopy">
                    <span class="slider" style="
                      position: absolute;
                      cursor: pointer;
                      top: 0;
                      left: 0;
                      right: 0;
                      bottom: 0;
                      background-color: var(--secondary-color, #6c757d);
                      transition: .4s;
                      border-radius: 24px;
                    "></span>
                  </label>
                </div>
              </div>
            </div>
          `;
          
          document.body.appendChild(settingsPanel);
          
          // Add slider styles for toggle switches
          const style = document.createElement('style');
          style.textContent = `
            .slider:before {
              position: absolute;
              content: "";
              height: 16px;
              width: 16px;
              left: 4px;
              bottom: 4px;
              background-color: white;
              transition: .4s;
              border-radius: 50%;
            }
            
            input:checked + .slider {
              background-color: var(--primary-color, #4a86e8);
            }
            
            input:focus + .slider {
              box-shadow: 0 0 1px var(--primary-color, #4a86e8);
            }
            
            input:checked + .slider:before {
              transform: translateX(26px);
            }
            
            .theme-option:hover {
              transform: scale(1.1);
            }
            
            .theme-option.active {
              border-color: var(--primary-color, #4a86e8);
            }
          `;
          document.head.appendChild(style);
          
          // Add event listeners for settings panel
          document.getElementById('closeSettings').addEventListener('click', function() {
            settingsPanel.style.right = '-300px';
          });
          
          // Theme option click handlers
          document.querySelectorAll('.theme-option').forEach(option => {
            option.addEventListener('click', function() {
              const theme = this.getAttribute('data-theme');
              setTheme(theme);
              
              // Update active state
              document.querySelectorAll('.theme-option').forEach(el => {
                el.classList.remove('active');
                el.style.borderColor = 'transparent';
              });
              this.classList.add('active');
              this.style.borderColor = 'var(--primary-color, #4a86e8)';
              
              // Save to storage
              chrome.storage.local.set({ theme: theme });
            });
          });
          
          // Settings toggle handlers
          document.getElementById('autoGenerateJava').addEventListener('change', function() {
            chrome.storage.local.set({ autoGenerateJava: this.checked });
            if (this.checked && steps.length > 0) {
              javaOutput.textContent = generateJavaStepDefinitions(steps);
            }
          });
          
          document.getElementById('showStepNumbers').addEventListener('change', function() {
            chrome.storage.local.set({ showStepNumbers: this.checked });
            // Refresh output if needed
            updateUI();
          });
          
          document.getElementById('autoCopy').addEventListener('change', function() {
            chrome.storage.local.set({ autoCopy: this.checked });
          });
          
          // Load settings from storage
          chrome.storage.local.get(['autoGenerateJava', 'showStepNumbers', 'autoCopy', 'theme'], function(data) {
            if (data.autoGenerateJava !== undefined) {
              document.getElementById('autoGenerateJava').checked = data.autoGenerateJava;
            }
            if (data.showStepNumbers !== undefined) {
              document.getElementById('showStepNumbers').checked = data.showStepNumbers;
            }
            if (data.autoCopy !== undefined) {
              document.getElementById('autoCopy').checked = data.autoCopy;
            }
            if (data.theme) {
              setTheme(data.theme);
              document.querySelector(`.theme-option[data-theme="${data.theme}"]`).classList.add('active');
              document.querySelector(`.theme-option[data-theme="${data.theme}"]`).style.borderColor = 'var(--primary-color, #4a86e8)';
            }
          });
        }
        
        // Show the settings panel
        settingsPanel.style.right = '0';
      }

      // Function to show tour welcome
      function showTourWelcome() {
        console.log('Showing tour welcome');
        
        // Check if tour welcome exists, create it if not
        let tourWelcome = document.getElementById('tourWelcome');
        if (!tourWelcome) {
          console.log('Creating tour welcome');
          tourWelcome = document.createElement('div');
          tourWelcome.id = 'tourWelcome';
          tourWelcome.className = 'tour-welcome';
          tourWelcome.style.position = 'fixed';
          tourWelcome.style.top = '50%';
          tourWelcome.style.left = '50%';
          tourWelcome.style.transform = 'translate(-50%, -50%)';
          tourWelcome.style.backgroundColor = 'var(--card-background, white)';
          tourWelcome.style.borderRadius = '8px';
          tourWelcome.style.padding = '24px';
          tourWelcome.style.boxShadow = '0 5px 25px rgba(0, 0, 0, 0.2)';
          tourWelcome.style.maxWidth = '400px';
          tourWelcome.style.zIndex = '1030';
          tourWelcome.style.textAlign = 'center';
          tourWelcome.style.display = 'none';
          
          tourWelcome.innerHTML = `
            <div class="tour-welcome-icon" style="
              font-size: 48px;
              color: var(--primary-color, #4a86e8);
              margin-bottom: 16px;
            ">
              <span class="glyphicon glyphicon-info-sign"></span>
            </div>
            <h2 style="margin-top: 0; color: var(--primary-color, #4a86e8);">Welcome to BDD Test Generator!</h2>
            <p>Would you like a quick tour of the features?</p>
            <div class="tour-welcome-buttons" style="
              margin-top: 24px;
              display: flex;
              justify-content: center;
              gap: 12px;
            ">
              <button id="startTourBtn" class="btn btn-primary">Start Tour</button>
              <button id="skipTourBtn" class="btn btn-outline-secondary">Skip Tour</button>
            </div>
          `;
          
          document.body.appendChild(tourWelcome);
          
          // Add event listeners
          document.getElementById('startTourBtn').addEventListener('click', function() {
            tourWelcome.style.display = 'none';
            alert('Tour functionality will be implemented soon!');
          });
          
          document.getElementById('skipTourBtn').addEventListener('click', function() {
            tourWelcome.style.display = 'none';
            chrome.storage.local.set({ tourCompleted: true });
          });
        }
        
        // Show the tour welcome
        tourWelcome.style.display = 'block';
      }
	  
	  document.addEventListener("contextmenu", function (e){
              e.preventDefault();
            }, false);

        // Initialize new features
        initThemeSettings();
        initSettingsPanel();
        initTour();
        addRippleEffect();
        initHelpButton();
      });