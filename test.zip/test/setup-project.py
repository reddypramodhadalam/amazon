import os

# Define the base project name
project_name = "custom-web-automation"

# Define the folder structure
folders = [
    f"{project_name}/src/main/java/com/example/automation",
    f"{project_name}/src/main/java/com/example/automation/controller",
    f"{project_name}/src/main/java/com/example/automation/service",
    f"{project_name}/src/main/resources/templates",
    f"{project_name}/src/main/resources/static",
    f"{project_name}/screenshots",
    f"{project_name}/target"
]

# Define Java files
java_files = {
    f"{project_name}/src/main/java/com/example/automation/AutomationApplication.java": 
    "package com.example.automation;\n\npublic class AutomationApplication {\n    public static void main(String[] args) {\n        System.out.println(\"Spring Boot Automation App Initialized\");\n    }\n}",

    f"{project_name}/src/main/java/com/example/automation/controller/TestController.java":
    "package com.example.automation.controller;\n\npublic class TestController {\n    public TestController() {\n        System.out.println(\"Controller Initialized\");\n    }\n}",

    f"{project_name}/src/main/java/com/example/automation/service/AgentService.java":
    "package com.example.automation.service;\n\npublic class AgentService {\n    public AgentService() {\n        System.out.println(\"Automation Service Initialized\");\n    }\n}"
}

# Define template files
html_files = {
    f"{project_name}/src/main/resources/templates/index.html":
    "<!DOCTYPE html>\n<html>\n<head>\n    <title>Custom Web Automation</title>\n</head>\n<body>\n    <h1>Welcome to Automation</h1>\n</body>\n</html>"
}

# Create folders
for folder in folders:
    os.makedirs(folder, exist_ok=True)

# Create Java files
for file_path, content in java_files.items():
    with open(file_path, "w") as file:
        file.write(content)

# Create HTML files
for file_path, content in html_files.items():
    with open(file_path, "w") as file:
        file.write(content)

# Create application.properties (optional Spring Boot config)
with open(f"{project_name}/src/main/resources/application.properties", "w") as file:
    file.write("# Spring Boot Configuration\n")

# Create pom.xml
with open(f"{project_name}/pom.xml", "w") as file:
    file.write("<!-- Define Maven Dependencies Here -->\n")

# Create a .gitignore file to exclude unnecessary files
with open(f"{project_name}/.gitignore", "w") as file:
    file.write("target/\n*.log\nscreenshots/\n")

print(f"✅ Project '{project_name}' folder structure created successfully!")
