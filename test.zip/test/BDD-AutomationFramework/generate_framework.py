import json
import os
import yaml

# Define framework directory
framework_root = "BDD-AutomationFramework"

# Directory structure
directories = [
    "src/test/java/runner",
    "src/test/java/stepDefinitions",
    "src/test/java/pageObjects",
    "src/test/java/utils",
    "src/test/resources/features",
    "test-output/SparkReport"
]

# Create directories
def create_directories():
    for directory in directories:
        os.makedirs(os.path.join(framework_root, directory), exist_ok=True)

# Load test data from YAML
def load_test_data():
    yaml_file = "test-data.yaml"
    try:
        with open(yaml_file, "r") as file:
            test_data = yaml.safe_load(file)
            return test_data.get("input_data", {})
    except Exception as e:
        print(f"❌ Error loading YAML: {e}")
        return {}

input_data = load_test_data()

# Generate Maven `pom.xml` with Java version fix
def generate_pom():
    pom_content = """<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>bdd.automation</groupId>
    <artifactId>BDD-AutomationFramework</artifactId>
    <version>1.0</version>
    <packaging>jar</packaging>

    <properties>
        <maven.compiler.source>8</maven.compiler.source>
        <maven.compiler.target>8</maven.compiler.target>
    </properties>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
                <configuration>
                    <source>8</source>
                    <target>8</target>
                </configuration>
            </plugin>
        </plugins>
    </build>

    <dependencies>
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.10.0</version>
        </dependency>
        <dependency>
            <groupId>io.cucumber</groupId>
            <artifactId>cucumber-java</artifactId>
            <version>7.14.0</version>
        </dependency>
        <dependency>
            <groupId>com.aventstack</groupId>
            <artifactId>extentreports</artifactId>
            <version>5.0.9</version>
        </dependency>
        <dependency>
            <groupId>org.testng</groupId>
            <artifactId>testng</artifactId>
            <version>7.5</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>io.github.bonigarcia</groupId>
            <artifactId>webdriver-manager</artifactId>
            <version>5.3.2</version>
        </dependency>
     </dependencies>
    </project>"""
    with open(os.path.join(framework_root, "pom.xml"), "w") as file:
        file.write(pom_content)

# Generate TestNG configuration `testng.xml`
def generate_testng():
    testng_content = """<suite name="BDD Automation Suite">
    <test name="BDD Tests">
        <classes>
            <class name="runner.TestRunner"/>
        </classes>
    </test>
</suite>"""
    with open(os.path.join(framework_root, "testng.xml"), "w") as file:
        file.write(testng_content)

# Generate Feature File (Using YAML Test Data)
def generate_feature_file(actions, base_url):
    feature_file_path = os.path.join(framework_root, "src/resources/features/recorded_test.feature")

    feature_content = f"Feature: Recorded User Actions\n\n  Scenario: Automate actions on {base_url}\n"
    for action in actions:
        name = action["name"]
        action_type = action["type"]

        if action_type == "click":
            feature_content += f"    Given the user clicks on {name}\n"
        elif action_type == "input":
            feature_content += f"    Given the user enters \"{input_data.get(name, '')}\" into {name}\n"

    with open(feature_file_path, "w") as file:
        file.write(feature_content)

    print(f"✅ Feature file generated: {feature_file_path}")

# Generate Page Objects (Using WebDriver Manager)
def generate_page_objects(actions):
    page_objects_path = os.path.join(framework_root, "src/test/java/pageObjects/LoginPage.java")
    page_objects_content = """package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }
"""

    for action in actions:
        name = action["name"].replace("-", "_")
        action_type = action["type"]
        xpath = action.get("xpath", "")

        page_objects_content += f"""
    private By {name} = By.xpath("{xpath}");

    public void {('click' if action_type == 'click' else 'enter')}{name}({'' if action_type == 'click' else 'String value'}) {{
        driver.findElement({name}).{('click()' if action_type == 'click' else 'sendKeys(value)')};
    }}
"""

    page_objects_content += "\n}"
    with open(page_objects_path, "w") as file:
        file.write(page_objects_content)

# Generate Step Definitions
def generate_step_definitions(actions):
    step_definitions_path = os.path.join(framework_root, "src/test/java/stepDefinitions/StepDefinitions.java")
    step_definitions_content = """package stepDefinitions;

import io.cucumber.java.en.Given;
import org.openqa.selenium.WebDriver;
import pageObjects.LoginPage;
import utils.WebDriverFactory;
import utils.ExtentReportManager;
import utils.ScreenshotUtil;

public class StepDefinitions {
    WebDriver driver = WebDriverFactory.getDriver();
    LoginPage loginPage = new LoginPage(driver);

"""

    for action in actions:
        name = action["name"].replace("-", "_")
        action_type = action["type"]

        if action_type == "click":
            step_definitions_content += f"""
    @Given("the user clicks on {name}")
    public void click{name}() {{
        loginPage.click{name}();
        String screenshotPath = ScreenshotUtil.captureScreenshot(driver, "click_{name}");
        ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath);
    }}
"""
        elif action_type == "input":
            value = input_data.get(name, "")
            step_definitions_content += f"""
    @Given("the user enters \"{value}\" into {name}")
    public void enter{name}() {{
        loginPage.enter{name}("{value}");
        String screenshotPath = ScreenshotUtil.captureScreenshot(driver, "input_{name}");
        ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath);
    }}
"""

    step_definitions_content += "\n}"
    with open(step_definitions_path, "w") as file:
        file.write(step_definitions_content)

# Load recorded-actions.json
def load_actions():
    json_file = "recorded-actions.json"
    try:
        with open(json_file, "r") as file:
            data = json.load(file)
            return data.get("actions", []), data.get("url", "")
    except Exception as e:
        print(f"❌ Error loading JSON: {e}")
        return [], ""

# Generate the complete framework
def generate_framework():
    create_directories()
    generate_pom()
    generate_testng()
    actions, base_url = load_actions()
    if actions:
        generate_feature_file(actions, base_url)
        generate_step_definitions(actions)
        generate_page_objects(actions)
        print("🚀 Framework generated successfully with YAML test data & WebDriver Manager!")
    else:
        print("⚠ No actions found in JSON file.")

if __name__ == "__main__":
    generate_framework()
