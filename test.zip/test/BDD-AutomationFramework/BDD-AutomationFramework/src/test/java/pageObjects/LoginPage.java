package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    private By theme_btn register_btn = By.xpath("/html/body/div/header/div[2]/div/div/div[2]/div[2]/a");

    public void clicktheme_btn register_btn() {
        driver.findElement(theme_btn register_btn).click();
    }

    private By email = By.xpath("//*[@id="email"]");

    public void clickemail() {
        driver.findElement(email).click();
    }

    private By email = By.xpath("//*[@id="email"]");

    public void enteremail(String value) {
        driver.findElement(email).sendKeys(value);
    }

    private By otp_login_btn = By.xpath("//*[@id="otp-login-btn"]");

    public void enterotp_login_btn(String value) {
        driver.findElement(otp_login_btn).sendKeys(value);
    }

}