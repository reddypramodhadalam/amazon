package stepDefinitions;

import io.cucumber.java.en.Given;
import org.openqa.selenium.WebDriver;
import pageObjects.LoginPage;
import utils.WebDriverFactory;
import utils.ExtentReportManager;
import utils.ScreenshotUtil;

public class StepDefinitions {
    WebDriver driver = WebDriverFactory.getDriver();
    LoginPage loginPage = new LoginPage(driver);


    @Given("the user clicks on theme_btn register_btn")
    public void clicktheme_btn register_btn() {
        loginPage.clicktheme_btn register_btn();
        String screenshotPath = ScreenshotUtil.captureScreenshot(driver, "click_theme_btn register_btn");
        ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath);
    }

    @Given("the user clicks on email")
    public void clickemail() {
        loginPage.clickemail();
        String screenshotPath = ScreenshotUtil.captureScreenshot(driver, "click_email");
        ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath);
    }

    @Given("the user enters "" into email")
    public void enteremail() {
        loginPage.enteremail("");
        String screenshotPath = ScreenshotUtil.captureScreenshot(driver, "input_email");
        ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath);
    }

}