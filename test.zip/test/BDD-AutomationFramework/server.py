from flask import Flask, jsonify, request, send_file
import subprocess
import os
import shutil

app = Flask(__name__)

# Define framework directory
FRAMEWORK_DIR = "BDD-AutomationFramework"

@app.route("/generate", methods=["POST"])
def generate_framework():
    try:
        print("🚀 Received POST request at /generate")  # Debugging log

        # Run the script to generate the framework
        result = subprocess.run(["python", "generate_framework.py"], capture_output=True, text=True, check=True)
        print("⚙️ Script Output:", result.stdout)  # Debugging log

        # Zip the framework
        shutil.make_archive(FRAMEWORK_DIR, "zip", FRAMEWORK_DIR)
        print("📦 Framework zipped successfully!")  # Debugging log

        return jsonify({"message": "Framework generated successfully!", "zip_file": f"{FRAMEWORK_DIR}.zip"})
    except Exception as e:
        print("❌ Error:", str(e))  # Debugging log
        return jsonify({"error": str(e)}), 500

@app.route("/download", methods=["GET"])
def download_framework():
    print("📥 Received GET request at /download")  # Debugging log
    return send_file(f"{FRAMEWORK_DIR}.zip", as_attachment=True)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)