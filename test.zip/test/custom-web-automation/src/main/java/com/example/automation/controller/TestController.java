package com.example.automation.controller;

import com.example.automation.service.AgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.nio.file.Paths;
import java.util.List;

@Controller
public class TestController {

    @Autowired
    private AgentService agentService;

    // Display the main page.
    @GetMapping("/")
    public String index(Model model) {
        // Available high-level actions.
        String[] actions = { "testStart", "launch", "enter", "enterPassword", "do", "check", "testEnd" };
        model.addAttribute("actions", actions);
        List<String> steps = agentService.getSteps();
        model.addAttribute("steps", steps);
        // The showResults button is disabled until after test execution.
        model.addAttribute("showResultsDisabled", true);
        return "index";
    }

    // Endpoint to add a DSL step.
    @PostMapping("/addStep")
    public String addStep(
            @RequestParam("action") String action,
            @RequestParam("param") String param) {
        // Build the DSL command string. For example:
        // Agent.launch("https://www.example.com")
        String dslCommand = "Agent." + action + "(\"" + param + "\")";
        agentService.addStep(dslCommand);
        return "redirect:/";
    }

    // Endpoint to run the test.
    @PostMapping("/runTest")
    public String runTest(Model model) {
        agentService.runTestSteps(agentService.getSteps());
        agentService.clearSteps();
        model.addAttribute("message", "Test execution completed. Click 'Show Results' to view the report.");
        // Enable the show results button.
        model.addAttribute("showResultsDisabled", false);
        return "index";
    }
    
    // Endpoint to show the generated report.
@GetMapping("/showReport")
public String showReport() {
    File reportFile = Paths.get("reports/extentReport.html").toFile();
    if(reportFile.exists()){
        return "redirect:/extentReport.html";
    } else {
        return "redirect:/?message=Report not found!";
    }
}
    
}
