package com.example.automation.service;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
// Use ExtentSparkReporter with ExtentReports 5
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class AgentService {

    private WebDriver driver;
    private ExtentReports extent;
    private ExtentTest test;
    // List holding DSL step commands
    private List<String> testSteps = new ArrayList<>();
    // Mapping for dynamic locators (logical name -> Selenium By locator)
    private Map<String, By> locatorMap = new HashMap<>();

    // ------------------ Helper Methods ------------------

    // Initialize default locators (e.g., a "default input" field)
    private void initDefaultLocators() {
        registerLocator("default input", "name", "q");
    }

    // Register a locator using a logical name, strategy, and locator value.
    public void registerLocator(String logicalName, String strategy, String locatorValue) {
        if (logicalName == null || strategy == null || locatorValue == null) {
            System.err.println("Invalid locator registration parameters.");
            return;
        }
        locatorMap.put(logicalName.toLowerCase(), parseLocatorDefinition(strategy + ":" + locatorValue));
    }

    // Retrieve a previously registered locator by its logical name.
    private By getLocator(String logicalName) {
        return logicalName == null ? null : locatorMap.get(logicalName.toLowerCase());
    }

    // Parse locator definitions of the format "strategy:locatorValue"
    // For example: "css:#searchInput" or "xpath://input[@id='login']"
    private By parseLocatorDefinition(String locatorDef) {
        String[] parts = locatorDef.split(":", 2);
        if (parts.length != 2) {
            System.err.println("Invalid locator definition: " + locatorDef);
            return null;
        }
        String strategy = parts[0].trim().toLowerCase();
        String value = parts[1].trim();
        switch (strategy) {
            case "css":
                return By.cssSelector(value);
            case "xpath":
                return By.xpath(value);
            case "id":
                return By.id(value);
            case "name":
                return By.name(value);
            default:
                System.err.println("Unsupported locator strategy: " + strategy);
                return null;
        }
    }

    // Capture a screenshot and return the saved file path.
    private String captureScreenshot(String stepName) {
        String screenshotDir = "screenshots";
        new File(screenshotDir).mkdirs();
        String fileName = screenshotDir + "/" + System.currentTimeMillis() + "_" + stepName.replaceAll("\\s+", "_") + ".png";
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destFile = new File(fileName);
            FileUtils.copyFile(srcFile, destFile);
            return fileName;
        } catch (IOException e) {
            System.err.println("Failed capturing screenshot for " + stepName + ": " + e.getMessage());
            return "";
        }
    }

    // ------------------ Reporting Setup with ExtentSparkReporter ------------------

    private void initReport() {
    extent = new ExtentReports();
    // Create a directory named "reports" if not exists.
    new File("reports").mkdirs();
    // Write the report to "reports/extentReport.html"
    ExtentSparkReporter sparkReporter = new ExtentSparkReporter("reports/extentReport.html");
    extent.attachReporter(sparkReporter);
}
    // ------------------ DSL Command Methods ------------------

    // Marks the beginning of a test case.
    public void testStart(String testName) {
        initReport();
        test = extent.createTest(testName);
        test.log(Status.INFO, "Test started: " + testName);
        initDefaultLocators();
    }

    // Launches a URL in Chrome using WebDriverManager.
    public void launch(String url) {
        try {
            // Force WebDriverManager to use the correct driver version.
            // You can also clear cache using .clearCache() or .forceDownload() if needed.
            WebDriverManager.chromedriver().browserVersion("136.0.7103.93").setup();
            driver = new ChromeDriver();
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.get(url);
            String path = captureScreenshot("launch");
            test.log(Status.PASS, "Launched URL: " + url,
                    MediaEntityBuilder.createScreenCaptureFromPath(path).build());
        } catch (Exception e) {
            test.log(Status.FAIL, "Exception in launch: " + e.getMessage());
        }
    }

    // Enters text into an input field.
    // Supported formats:
    // "Enter MacBook" or "Enter MacBook in element located by css:#searchInput"
	public void enter(String command) {
    try {
        String text = "";
        String locatorStr = "";
        // The DSL command is expected to be: "Enter testUser in username field"
        Pattern pattern = Pattern.compile("Enter\\s+(.+?)(?:\\s+in\\s+(.+))?", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(command);
        if (matcher.find()) {
            text = matcher.group(1).trim();
            locatorStr = matcher.group(2) != null ? matcher.group(2).trim() : "";
        } else {
            test.log(Status.FAIL, "Incorrect enter command format: " + command);
            return;
        }
        
        By locator = null;
        // If a locator string was given that explicitly contains "css:" or "xpath:" then use that.
        if (!locatorStr.isEmpty() && (locatorStr.contains("css:") || locatorStr.contains("xpath:"))) {
            locator = parseLocatorDefinition(locatorStr);
        } else if (!locatorStr.isEmpty()) {
            // Otherwise, assume the given text is a logical hint (like "username field")
            locator = smartLocate(locatorStr);
            
            if (locator == null) {
                // Fallback: If smartLocate fails, try to get a pre-registered locator.
                locator = getLocator(locatorStr);
            }
        } else {
            // If no locator information is provided, use the default input.
            locator = getLocator("default input");
        }
        
        if (locator != null) {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            element.clear();
            element.sendKeys(text);
            String path = captureScreenshot("enter");
            test.log(Status.PASS, "Entered text '" + text + "' using locator: " +
                    (locatorStr.isEmpty() ? "default input" : locatorStr),
                    MediaEntityBuilder.createScreenCaptureFromPath(path).build());
        } else {
            test.log(Status.FAIL, "Could not locate element for: " + locatorStr);
        }
    } catch (Exception e) {
        test.log(Status.FAIL, "Exception in enter: " + e.getMessage());
    }
}    
    // Enters a password into an input field.
    // Supported format: 
    // "EnterPassword mySecretPwd" or "EnterPassword mySecretPwd in element located by css:#password"
    // The actual password is not logged.
    public void enterPassword(String command) {
        try {
            String pass = "";
            String locatorStr = "";
            Pattern pattern = Pattern.compile("EnterPassword\\s+(.+?)(?:\\s+(?:in(?:\\s+element)?(?:\\s+located\\s+by)\\s+(.+))$)?", Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(command);
            if (matcher.find()) {
                pass = matcher.group(1).trim();
                locatorStr = matcher.group(2) != null ? matcher.group(2).trim() : "";
            } else {
                test.log(Status.FAIL, "Incorrect enterPassword command format: " + command);
                return;
            }
            By locator;
            if (!locatorStr.isEmpty()) {
                locator = locatorStr.contains(":") ? parseLocatorDefinition(locatorStr) : getLocator(locatorStr);
            } else {
                locator = getLocator("default input");
            }
            if (locator != null) {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                element.clear();
                element.sendKeys(pass);
                String path = captureScreenshot("enterPassword");
                // Do not log the password value.
                test.log(Status.PASS, "Entered password using locator: " +
                        (locatorStr.isEmpty() ? "default input" : locatorStr),
                        MediaEntityBuilder.createScreenCaptureFromPath(path).build());
            } else {
                test.log(Status.FAIL, "Locator not found for enterPassword: " + locatorStr);
            }
        } catch (Exception e) {
            test.log(Status.FAIL, "Exception in enterPassword: " + e.getMessage());
        }
    }

    // Performs UI actions: click, double-click, right-click, scroll, hover, and drag-and-drop.
    public void doAction(String command) {
        try {
            // Simple click.
            if (command.toLowerCase().contains("click") &&
                !command.toLowerCase().contains("double-click") &&
                !command.toLowerCase().contains("right-click")) {
                Pattern pattern = Pattern.compile("click(?:\\s+(?:of|element)(?:\\s+located\\s+by)?\\s+(.+))?", Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(command);
                String locatorStr = (matcher.find() && matcher.group(1) != null) ? matcher.group(1).trim() : "";
                By locator = !locatorStr.isEmpty() && locatorStr.contains(":") ? 
                        parseLocatorDefinition(locatorStr) : getLocator(locatorStr);
                if (locator != null) {
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
                    element.click();
                    String path = captureScreenshot("click");
                    test.log(Status.PASS, "Clicked on element using locator: " + locatorStr,
                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                } else {
                    test.log(Status.FAIL, "Locator not defined for click: " + locatorStr);
                }
            }
            // Double-click.
            else if (command.toLowerCase().contains("double-click")) {
                Pattern pattern = Pattern.compile("double-click(?:\\s+(?:of|element)(?:\\s+located\\s+by)?\\s+(.+))?", Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(command);
                String locatorStr = (matcher.find() && matcher.group(1) != null) ? matcher.group(1).trim() : "";
                if (locatorStr.isEmpty()) {
                    test.log(Status.FAIL, "No locator provided in double-click command: " + command);
                    return;
                }
                By locator = locatorStr.contains(":") ? parseLocatorDefinition(locatorStr) : getLocator(locatorStr);
                if (locator != null) {
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                    new Actions(driver).doubleClick(element).perform();
                    String path = captureScreenshot("double-click");
                    test.log(Status.PASS, "Double-clicked on element with locator: " + locatorStr,
                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                } else {
                    test.log(Status.FAIL, "Locator not defined for double-click: " + locatorStr);
                }
            }
            // Right-click.
            else if (command.toLowerCase().contains("right-click")) {
                Pattern pattern = Pattern.compile("right-click(?:\\s+(?:of|element)(?:\\s+located\\s+by)?\\s+(.+))?", Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(command);
                String locatorStr = (matcher.find() && matcher.group(1) != null) ? matcher.group(1).trim() : "";
                if (locatorStr.isEmpty()) {
                    test.log(Status.FAIL, "No locator provided in right-click command: " + command);
                    return;
                }
                By locator = locatorStr.contains(":") ? parseLocatorDefinition(locatorStr) : getLocator(locatorStr);
                if (locator != null) {
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                    new Actions(driver).contextClick(element).perform();
                    String path = captureScreenshot("right-click");
                    test.log(Status.PASS, "Right-clicked on element with locator: " + locatorStr,
                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                } else {
                    test.log(Status.FAIL, "Locator not defined for right-click: " + locatorStr);
                }
            }
            // Scroll actions.
            else if (command.toLowerCase().contains("scroll")) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                if (command.toLowerCase().contains("down")) {
                    js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                    String path = captureScreenshot("scroll-down");
                    test.log(Status.PASS, "Scrolled down the page.",
                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                } else if (command.toLowerCase().contains("up")) {
                    js.executeScript("window.scrollTo(0, 0);");
                    String path = captureScreenshot("scroll-up");
                    test.log(Status.PASS, "Scrolled up the page.",
                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                } else {
                    test.log(Status.FAIL, "Scroll direction not defined: " + command);
                }
            }
            // Hover.
            else if (command.toLowerCase().contains("hover")) {
                Pattern pattern = Pattern.compile("hover(?:\\s+over)?\\s+(.+)", Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(command);
                String locatorStr = (matcher.find() && matcher.group(1) != null) ? matcher.group(1).trim() : "";
                if (locatorStr.isEmpty()) {
                    test.log(Status.FAIL, "No locator provided in hover command: " + command);
                    return;
                }
                By locator = locatorStr.contains(":") ? parseLocatorDefinition(locatorStr) : getLocator(locatorStr);
                if (locator != null) {
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
                    new Actions(driver).moveToElement(element).perform();
                    String path = captureScreenshot("hover");
                    test.log(Status.PASS, "Hovered over element with locator: " + locatorStr,
                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                } else {
                    test.log(Status.FAIL, "Locator not defined for hover: " + locatorStr);
                }
            }
            // Drag-and-drop.
            else if (command.toLowerCase().contains("drag from")) {
                Pattern pattern = Pattern.compile("drag from\\s+(.+)\\s+to\\s+(.+)", Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(command);
                if (matcher.find()) {
                    String sourceStr = matcher.group(1).trim();
                    String targetStr = matcher.group(2).trim();
                    By sourceLocator = sourceStr.contains(":") ? parseLocatorDefinition(sourceStr) : getLocator(sourceStr);
                    By targetLocator = targetStr.contains(":") ? parseLocatorDefinition(targetStr) : getLocator(targetStr);
                    if (sourceLocator != null && targetLocator != null) {
                        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                        WebElement sourceElement = wait.until(ExpectedConditions.visibilityOfElementLocated(sourceLocator));
                        WebElement targetElement = wait.until(ExpectedConditions.visibilityOfElementLocated(targetLocator));
                        new Actions(driver).dragAndDrop(sourceElement, targetElement).perform();
                        String path = captureScreenshot("drag");
                        test.log(Status.PASS, "Dragged from '" + sourceStr + "' to '" + targetStr + "'",
                                MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                    } else {
                        test.log(Status.FAIL, "Locator not defined for drag action: " +
                                sourceStr + " or " + targetStr);
                    }
                } else {
                    test.log(Status.FAIL, "Unable to parse drag command: " + command);
                }
            }
            // Unsupported command.
            else {
                test.log(Status.FAIL, "Unsupported action command: " + command);
            }
        } catch (Exception e) {
            test.log(Status.FAIL, "Exception in doAction: " + e.getMessage());
        }
    }

    // Checks that the expected text appears on the page.
    // Expected format: "MacBook Pro text in search results"
    public void check(String command) {
        try {
            String expectedText = "";
            Pattern pattern = Pattern.compile("(.+?)\\s+text(?:\\s+in\\s+(.+))?", Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(command);
            if (matcher.find()) {
                expectedText = matcher.group(1).trim();
            } else {
                test.log(Status.FAIL, "Unable to parse check command: " + command);
                return;
            }
            if (driver.getPageSource().contains(expectedText)) {
                String path = captureScreenshot("check");
                test.log(Status.PASS, "Validation passed: '" + expectedText + "' found.",
                        MediaEntityBuilder.createScreenCaptureFromPath(path).build());
            } else {
                String path = captureScreenshot("check");
                test.log(Status.FAIL, "Validation failed: '" + expectedText + "' not found.",
                        MediaEntityBuilder.createScreenCaptureFromPath(path).build());
            }
        } catch (Exception e) {
            test.log(Status.FAIL, "Exception in check: " + e.getMessage());
        }
    }

    // Ends the test case: flushes the report and closes the browser.
    public void testEnd() {
        try {
            test.log(Status.INFO, "Test ended.");
        } catch (Exception e) {
            System.err.println("Error in testEnd: " + e.getMessage());
        } finally {
            extent.flush();
            if (driver != null) {
                driver.quit();
            }
        }
    }

    // Runs each DSL test step sequentially.
    public void runTestSteps(List<String> steps) {
        for (String step : steps) {
            processCommand(step);
        }
    }

    // Parses and executes a DSL command.
    private void processCommand(String commandLine) {
        Pattern pattern = Pattern.compile("Agent\\.(\\w+)\\(\"([^\"]+)\"\\)");
        Matcher matcher = pattern.matcher(commandLine);
        if (matcher.find()) {
            String method = matcher.group(1).trim().toLowerCase();
            String arg = matcher.group(2).trim();
            switch (method) {
                case "teststart":
                    testStart(arg);
                    break;
                case "launch":
                    launch(arg);
                    break;
                case "enter":
                    enter(arg);
                    break;
                case "enterpassword":
                    enterPassword(arg);
                    break;
                case "do":
                    doAction(arg);
                    break;
                case "check":
                    check(arg);
                    break;
                case "testend":
                    testEnd();
                    break;
                default:
                    test.log(Status.FAIL, "Unknown command: " + method);
            }
        } else {
            test.log(Status.FAIL, "Command not recognized: " + commandLine);
        }
    }
private By smartLocate(String fieldKeyword) {
    // Convert the keyword to lower-case to handle case-insensitive matching.
    String keyword = fieldKeyword.toLowerCase();
    
    // Get all input elements on the current page.
    List<WebElement> inputs = driver.findElements(By.tagName("input"));
    
    // Loop over the input elements and check their attributes.
    for (WebElement input : inputs) {
        String id = input.getAttribute("id") != null ? input.getAttribute("id").toLowerCase() : "";
        String name = input.getAttribute("name") != null ? input.getAttribute("name").toLowerCase() : "";
        String placeholder = input.getAttribute("placeholder") != null ? input.getAttribute("placeholder").toLowerCase() : "";
        String type = input.getAttribute("type") != null ? input.getAttribute("type").toLowerCase() : "";
        
        // Add your own heuristics:
        // For example, if the fieldKeyword contains "username", the method will try to match that
        if (keyword.contains("username")) {
            if (id.contains("user") || name.contains("user") || placeholder.contains("user")) {
                // Prefer an element with an id; if not, try to use name.
                if (!id.isEmpty()) {
                    return By.id(input.getAttribute("id"));
                } else if (!name.isEmpty()) {
                    return By.name(input.getAttribute("name"));
                }
            }
        }
        // Similarly, you can add logic for password fields or other types.
        if (keyword.contains("password")) {
            if (type.equals("password") || id.contains("pass") || name.contains("pass") || placeholder.contains("pass")) {
                if (!id.isEmpty()) {
                    return By.id(input.getAttribute("id"));
                } else if (!name.isEmpty()) {
                    return By.name(input.getAttribute("name"));
                }
            }
        }
    }
    // If no matching element is found, return null.
    return null;
}

    // ------------------ Methods Exposed to the Controller ------------------

    public void addStep(String dslCommand) {
        testSteps.add(dslCommand);
    }

    public List<String> getSteps() {
        return testSteps;
    }

    public void clearSteps() {
        testSteps.clear();
    }
}