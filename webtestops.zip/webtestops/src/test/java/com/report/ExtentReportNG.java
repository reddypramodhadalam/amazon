package com.report;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

/*
 * Developed by Baxter@Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class ExtentReportNG {

    public static ExtentReports getReportObject()
	{
		String time = currentDate();
		String path =System.getProperty("user.dir")+File.separator+"reports"+time+File.separator+"index.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);
		try {
			reporter.loadXMLConfig(new File(System.getProperty("user.dir")+File.separator+"extentconfig.xml"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		ExtentReports extent =new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Reddy Pramodh A");
		return extent;		
	}

	public static String currentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
   		LocalDateTime now = LocalDateTime.now();
		String str = dtf.format(now);
		str = str.replaceAll(" ", "");
		str = str.replaceAll(":", "");
		str = str.replaceAll("/", "");
		return str;
	}

}
