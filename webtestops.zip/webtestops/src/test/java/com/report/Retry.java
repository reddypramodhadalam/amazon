package com.report;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/*
 * Developed by Baxter @Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class Retry implements IRetryAnalyzer{

    int count = 0;
	int maxTry = 1;

    @Override
    public boolean retry(ITestResult result) {
    	if(!result.isSuccess()){
    		if(count<maxTry)
    		{
    			count++;
    			return true;
    		}    		
    	}
		return false;
    }

}
