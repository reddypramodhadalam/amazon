package com.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Map;
import org.yaml.snakeyaml.Yaml;

/*
 * Developed by Baxter@Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class TestData {
	@SuppressWarnings("unchecked")
    public String getTestData(String environment, String dataName) {
		String data = null;
		String path= System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" + File.separator
		+ "resources" + File.separator + "TestData.yaml";
		try {
			Yaml yaml = new Yaml();
			InputStream inputStream = new FileInputStream(path);
			Map<String, Object> map = yaml.load(inputStream);
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				Object value = entry.getValue();
				if (value instanceof Map) {
					Map<String, Object> subMap = (Map<String, Object>) value;
					for (Map.Entry<String, Object> subEntry : subMap.entrySet()) {
						String subKey = subEntry.getKey();
						Object subValue = subEntry.getValue();
						//System.out.println(key + "." + subKey + ": " + subValue);
						String test= key+"."+subKey;
						if(test.equalsIgnoreCase(environment+"."+dataName)){
							data=(String) subValue.toString();
							break;
						}
					}
				} else {
					System.out.println(key + ": " + value);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		return data;
	}
}
