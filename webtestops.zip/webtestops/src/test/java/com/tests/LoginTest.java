package com.tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.report.Retry;

/*
 * Developed by Baxter @Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class LoginTest extends BaseTest {

    @Test(retryAnalyzer = Retry.class)
    public void testLogin() {
        boolean textStatus = lp.validateGmailText();
        Assert.assertFalse(textStatus, "Google Website is loaded properly");
    }

    @Test(retryAnalyzer = Retry.class)
    public void testLoginForParallel() {
        boolean textStatus = lp.validateGmailText();
        Assert.assertTrue(textStatus, "Google Website is not loaded properly");
    }
}
