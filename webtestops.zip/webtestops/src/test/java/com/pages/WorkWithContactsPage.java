package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.tests.BaseTest;
import com.utils.TestData;

public class WorkWithContactsPage extends BasePage {
	
	TestData td = new TestData();
	BaseTest tb = new BaseTest();
	
	@FindBy(xpath="//*[@id='e1menuAppIframe']")
	WebElement frameId;
	
	@FindBy(xpath="//*[@id='jdeFormTitle0']")
	WebElement pageTitle;
	
	@FindBy(xpath="//*[@id='C0_23']")
	WebElement shipToField;
	
	@FindBy(xpath = "//input[@class='textfield associated0_297']")
	WebElement callerFirstName;
	
	@FindBy(xpath = "//input[@class='textfield associated0_301']")
	WebElement callerLastName;
	
	@FindBy(xpath = "//input[@class='textfield associated0_305']")
	WebElement callerPhoneNumber;
	
	@FindBy(xpath = "//input[@class='textfield associated0_307']")
	WebElement callerDepartment;
	
	@FindBy(xpath = "//input[@class='textfield associated0_118']")
	WebElement callerTeamType;
	
	@FindBy(xpath = "//span[@class='FieldLabelSmall']/u[text()='F']")
	WebElement formDropDown;
	
	@FindBy(xpath = "//span[@class='MenuItem']/nobr/u[text()='l']")
	WebElement rentalOrderButton;
	
	@FindBy(xpath="//*[@id='hc_Find']")
	WebElement findButton;
	
	@FindBy(xpath = "//span[@class='FieldLabelSmall']/u[text()='R']")
	WebElement rowDropDown;
	
	@FindBy(xpath = "//span[@class='MenuItem']/nobr[contains(text(),'Work Order Inquiry')]")
	WebElement workOrderInquiry;
	
	public WorkWithContactsPage() {
		
	}
	
	public boolean validateIfWorkWithContactsPageIsDisplayed() {
		tb.getDriver().switchTo().defaultContent();
		tb.getDriver().switchTo().frame(frameId);
		String text = pageTitle.getText();
		boolean status = text.contains(td.getTestData(BaseTest.environment, "wwcText"));
		return status;
	}

	public CustomerProtocolViewPage enterShipToFieldData() {
		waitUntilPageLoad(tb.getDriver());
		//sendKeys(shipToField, td.getTestData(BaseTest.environment, "shipto"));
		try {
			Thread.sleep(2000);
			shipToField.sendKeys(Keys.TAB);
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CustomerProtocolViewPage cpvp = new CustomerProtocolViewPage();
		return cpvp;
	}
	
	public void enterCallerFirstName() {
		//sendKeys(callerFirstName, td.getTestData(BaseTest.environment, "firstName"));
	}
	
	public void enterCallerLastName() {
		//sendKeys(callerLastName, td.getTestData(BaseTest.environment, "lastName"));
	}
	
	public void enterCallerPhoneNumber() {
		String text = td.getTestData(BaseTest.environment, "phoneNumber").trim();
		text = text.replaceAll("\\s", "");
		callerPhoneNumber.clear();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//sendKeys(callerPhoneNumber, text);
	}
	
	public void enterCallerDepartment() {
		//sendKeys(callerDepartment, td.getTestData(BaseTest.environment, "department"));
	}
	
	public void enterCallerTeamType() {
		//sendKeys(callerTeamType, td.getTestData(BaseTest.environment, "teamType"));
	}
	
	public void clickOnFormDropDown() {
		waitForVisibility(formDropDown);
		//click(formDropDown);
	}
	
	public SodrPage clickOnRentalOrder() {
		//click(rentalOrderButton);
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SodrPage sdp = new SodrPage();
		return sdp;
	}
	
	public void clickOnFindButton() {
		//click(findButton);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public WorkWithOrdersPage clickOnWorkOrderInquiry() {
		//click(rowDropDown);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement element = tb.getDriver().findElement(By.xpath("//span[@class='MenuItem']/nobr[contains(text(),'Work Order Inquiry')]"));
		((JavascriptExecutor) tb.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		try {
			Thread.sleep(2000);
			//click(workOrderInquiry);
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WorkWithOrdersPage wwo = new WorkWithOrdersPage();
		return wwo;
		
	}
}
