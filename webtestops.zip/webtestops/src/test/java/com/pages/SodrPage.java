package com.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tests.BaseTest;
import com.utils.TestData;

public class SodrPage extends BasePage {
	
	TestData td = new TestData();
	
	@FindBy(xpath= "//*[@id='jdeFormTitle0']")
	WebElement sdPageTitle;
	
	@FindBy(xpath = "//*[@id='C0_800']")
	WebElement soldToField;
	
	@FindBy(xpath = "//*[@id='C0_802']")
	WebElement shipToField;
	
	@FindBy(xpath = "//*[@id='C0_23']")
	WebElement orderDate;
	
	@FindBy(xpath = "//td[@colindex='0']/div/input")
	WebElement quantityOrdered;
	
	@FindBy(xpath = "//td[@colindex='2']/div/input")
	WebElement uom;
	
	@FindBy(xpath = "//td[@colindex='3']/div/input")
	WebElement itemNumber;
	
	@FindBy(xpath = "//span[@class='FieldLabelSmall']/u[text()='F']")
	WebElement formDropDown;
	
	@FindBy(xpath = "//*[@id='outerHE0_858']")
	WebElement supplementalOrder;
	

	public SodrPage() {
	
	}
	
	public boolean validateSalesOrderDetailsPageIsDisplayed() {
		waitForVisibility(sdPageTitle);
		String text = sdPageTitle.getText();
		boolean status = text.contains(td.getTestData(BaseTest.environment, "sodrText"));
		return status;
	}
	
	public void pressingTabInSodrPage() {
		try {
			soldToField.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			shipToField.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			orderDate.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			quantityOrdered.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			uom.sendKeys(Keys.TAB);
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void enterItemNumber() {
		//sendKeys(itemNumber, td.getTestData(BaseTest.environment, "itemNumber"));
		itemNumber.sendKeys(Keys.DOWN);
		try {
			Thread.sleep(8000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void clickOnFormDropDown() {
		//click(formDropDown);
	}
	
	public RosirPage clickOnSupplementalInfo() {
		//click(supplementalOrder);
		try {
			Thread.sleep(12000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		RosirPage rsp = new RosirPage();
		return rsp;
	}

}
