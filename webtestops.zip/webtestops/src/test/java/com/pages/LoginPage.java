package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.tests.BaseTest;
import com.utils.TestData;

/*
 * Developed by Baxter@Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class LoginPage extends BasePage {

    WebDriver driver;
	TestData td = new TestData();
	public LoginPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath="//a[text()='Gmail']")
	WebElement gmailText;

	public boolean validateGmailText() {
		boolean status = gmailText.isDisplayed();
		return status;
	}

	public void goTo() {
		driver.get(td.getTestData(BaseTest.environment, "url"));
	}

}