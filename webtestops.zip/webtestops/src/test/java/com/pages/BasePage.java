package com.pages;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/*
 * Developed by Baxter@Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class BasePage {
	WebDriver driver;

    public BasePage(WebDriver driver) {
        this.driver = driver;
		PageFactory.initElements(driver, this);
    }
	//Switching to alert and accepting the alert
    public boolean SwitchAlert() {
		boolean Flag = false;
		try {
			if (driver.switchTo().alert() != null) {
				driver.switchTo().alert().accept();
				Flag = true;
			}
		}
		catch (NoAlertPresentException e) {
		}
		return Flag;
	}
	//double click on any webelement
    public void doubleClick(WebElement element) {
		if ((driver != null) && (element != null))
			(new Actions(driver)).doubleClick(element).build().perform();
	}
	//Dynamically waiting for visibility of webelement
    public boolean waitForVisibility(WebElement e) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		return wait.until(ExpectedConditions.visibilityOf(e))!=null;
	}
	//Clicking on a webelement
    public void click(WebElement e) {
		waitForVisibility(e);
		e.click();
	}
	//Entering text in a text box
	public void sendKeys(WebElement e, String txt) {
		waitForVisibility(e);
		e.sendKeys(txt);
	}
	//Getting html attribute of a web element
	public String getAttribute(WebElement e, String attribute) {
		waitForVisibility(e);
		return e.getAttribute(attribute);
	}
	//Selecting drop down value from a web page
	public void selectDropDownValue(WebElement element, String value) {
		try {
			if (element != null) {
				Select selectBox = new Select(element);
				selectBox.selectByValue(value);
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//Decrypting values of an ecrypted string
	public String decryptString(String decryptValue) {
		String result = new String();
		char[] charArray = decryptValue.toCharArray();
      	for(int i = 0; i < charArray.length; i=i+2) {
        	String st = ""+charArray[i]+""+charArray[i+1];
        	char ch = (char)Integer.parseInt(st, 16);
         	result = result + ch;
      	}
		return result;
	}
}
