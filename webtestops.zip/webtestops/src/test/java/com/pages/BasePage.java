TestData td = new TestData();
public LoginPage() {
	
}

@FindBy(xpath="//*[@id='User']")
WebElement username;

@FindBy(xpath="//*[@id='Password']")
WebElement password;

@FindBy(xpath="//input[@type='submit']")
WebElement signInButton;

@FindBy(xpath = "//button[@class='btn launchButton']")
WebElement launchButton;

public boolean validateLoginPageDisplay() {
	boolean status = username.isDisplayed();
	return status;
}

public void enterUsername(String message) {
	sendKeys(username, td.getTestData(BaseTest.environment, "testUser"), message);
}

public void enterPassword(String message) {
	String passwordDecrypted = decryptString(td.getTestData(BaseTest.environment, "validPassword"));
	sendKeys(password, passwordDecrypted, message);
}

public HomePage clickOnLoginButton(String message) {
	click(signInButton, message);
	HomePage hp = new HomePage();
	return hp;
}
public void goTo() {
	BaseTest tb = new BaseTest();
	tb.getDriver().get(td.getTestData(BaseTest.environment, "url"));
TestData td = new TestData();
public LoginPage() {
	
}

@FindBy(xpath="//*[@id='User']")
WebElement username;

@FindBy(xpath="//*[@id='Password']")
WebElement password;

@FindBy(xpath="//input[@type='submit']")
WebElement signInButton;

@FindBy(xpath = "//button[@class='btn launchButton']")
WebElement launchButton;

public boolean validateLoginPageDisplay() {
	boolean status = username.isDisplayed();
	return status;
}

public void enterUsername(String message) {
	sendKeys(username, td.getTestData(BaseTest.environment, "testUser"), message);
}

public void enterPassword(String message) {
	String passwordDecrypted = decryptString(td.getTestData(BaseTest.environment, "validPassword"));
	sendKeys(password, passwordDecrypted, message);
}

public HomePage clickOnLoginButton(String message) {
	click(signInButton, message);
	HomePage hp = new HomePage();
	return hp;
}
public void goTo() {
	BaseTest tb = new BaseTest();
	tb.getDriver().get(td.getTestData(BaseTest.environment, "url"));
}