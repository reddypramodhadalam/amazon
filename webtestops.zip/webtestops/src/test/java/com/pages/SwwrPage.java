package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tests.BaseTest;
import com.utils.TestData;

public class SwwrPage extends BasePage {
	
	TestData td = new TestData();
	
	@FindBy(xpath= "//*[@id='jdeFormTitle0']")
	WebElement swwrTitle;
	
	@FindBy(xpath="//*[@id='hc_Cancel']")
	WebElement cancelButton;
	
	public SwwrPage() {
		
	}
	
	public boolean validateIfSelectWhoIsWhoRecordPageIsDisplayed() {
		waitForVisibility(swwrTitle);
		String text = swwrTitle.getText();
		boolean status = text.contains(td.getTestData(BaseTest.environment, "swrText"));
		return status;
	}
	
	public WorkWithContactsPage clickOnCancelButton() {
		//click(cancelButton);
		try {
			Thread.sleep(2000);
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WorkWithContactsPage wwcp = new WorkWithContactsPage();
		return wwcp;
	}

}
