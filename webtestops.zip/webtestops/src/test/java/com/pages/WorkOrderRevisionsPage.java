package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tests.BaseTest;
import com.utils.TestData;

public class WorkOrderRevisionsPage extends BasePage {
	
	TestData td = new TestData();
	BaseTest tb = new BaseTest();
	
	@FindBy(xpath= "//*[@id='jdeFormTitle0']")
	WebElement worPageTitle;
	
	@FindBy(xpath="//*[@id='C0_41']")
	WebElement serialNumber;
	
	@FindBy(xpath="//*[@id='va0_41']")
	WebElement virtualAssist;
	
	@FindBy(xpath="//input[@title='Customer Number' and @class='textfield']")
	WebElement customerNumber;
	
	@FindBy(xpath="//input[@title='Site Number' and @class='textfield']")
	WebElement siteNumber;
	
	@FindBy(xpath="//input[@title='Installation Date' and @class='textfield']")
	WebElement installationDate;
	
	@FindBy(xpath="//input[@title='Equipment Status' and @class='textfield']")
	WebElement equipmentStatus;
	
	@FindBy(xpath = "//*[@id='hc_Find']")
	WebElement findButton;
	
	@FindBy(xpath = "//*[@id='hc_Select']")
	WebElement selectButton;
	
	@FindBy(xpath="//a[text()='Planning']")
	WebElement planningTab;
	
	@FindBy(xpath="//*[@id='e1menuAppIframe']")
	WebElement frameId;
	
	@FindBy(xpath = "//*[@id='C0_70']")
	WebElement statusField;
	
	@FindBy(xpath="//*[@id='C0_80']")
	WebElement dateField;
	
	@FindBy(xpath = "//*[@id='C0_227']")
	WebElement timeField;
	
	@FindBy(xpath = "//*[@id='C0_102']")
	WebElement primaryTechnician;
	
	@FindBy(xpath = "//*[@id='hc_OK']")
	WebElement okButton;
	
	
	public WorkOrderRevisionsPage() {
		
	}
	
	public boolean validateWorkOrderRevisionsScreenIsDisplayed() {
		waitForVisibility(worPageTitle);
		String text = worPageTitle.getText();
		boolean status = text.contains(td.getTestData(BaseTest.environment, "worPageText"));
		return status;
	}
	
	public void clickOnSerialNumber() {
		//click(serialNumber);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//click(virtualAssist);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void enterCustomerNumber() {
		WebElement frame = tb.getDriver().findElement(By.xpath("//*[@id='modalIframe1']"));
		tb.getDriver().switchTo().frame(frame);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//sendKeys(customerNumber, td.getTestData(BaseTest.environment, "customerNumber"));
	}
	
	public void enterEquipmentStatus() {
		customerNumber.sendKeys(Keys.TAB);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		siteNumber.sendKeys(Keys.TAB);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		installationDate.sendKeys(Keys.TAB);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//sendKeys(equipmentStatus, td.getTestData(BaseTest.environment, "equipmentStatus"));
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void clickOnFindButton() {
		//click(findButton);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void clickOnSelectButton() {
		//click(selectButton);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tb.getDriver().switchTo().defaultContent();
		tb.getDriver().switchTo().frame(frameId);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void clickOnPlanningTab() {
		//click(planningTab);
	}
	
	public void updateStatus() {
		//sendKeys(statusField, td.getTestData(BaseTest.environment, "status"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void enterCompletionDateAndTime() {
		String date = getCurrentDateAndTime();
		String[] splitDate = date.split(" ");
		//sendKeys(dateField, splitDate[0]);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//sendKeys(timeField, splitDate[1]);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void enterPrimaryTechnicianData() {
		//sendKeys(primaryTechnician, td.getTestData(BaseTest.environment, "primaryTechnician"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public WorkWithOrdersPage clickOnOkButton() {
		//click(okButton);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WorkWithOrdersPage wwop = new WorkWithOrdersPage();
		return wwop;
	}
}
