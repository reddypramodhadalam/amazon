package com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tests.BaseTest;
import com.utils.TestData;

public class RosirPage extends BasePage {

	TestData td = new TestData();
	
	@FindBy(xpath= "//*[@id='jdeFormTitle0']")
	WebElement rspPageTitle;
	
	@FindBy(xpath = "//td[@colindex='6']/div/input")
	WebElement serialNumber;
	
	@FindBy(xpath = "//td[@colindex='7']/div/input")
	WebElement serviceType;
	
	@FindBy(xpath = "//td[@colindex='8']/div/input")
	WebElement patientFirstName;
	
	@FindBy(xpath = "//td[@colindex='9']/div/input")
	WebElement patientLastName;
	
	@FindBy(xpath = "//td[@colindex='10']/div/input")
	WebElement referringDoctor;
	
	@FindBy(xpath = "//td[@colindex='11']/div/input")
	WebElement gender;
	
	@FindBy(xpath = "//td[@colindex='12']/div/input")
	WebElement patientRoomNumber;
	
	@FindBy(xpath = "//td[@colindex='13']/div/input")
	WebElement patientWardNumber;
	
	@FindBy(xpath = "//td[@colindex='14']/div/input")
	WebElement medicalRecord;
	
	@FindBy(xpath = "//td[@colindex='15']/div/input")
	WebElement billingDate;
	
	@FindBy(xpath = "//td[@colindex='17']/div/input")
	WebElement equipDate;
	
	@FindBy(xpath = "//td[@colindex='19']/div/input")
	WebElement billingOffDate;
	
	@FindBy(xpath = "//td[@colindex='21']/div/input")
	WebElement equipOffDate;
	
	@FindBy(xpath = "//td[@colindex='23']/div/input")
	WebElement customerPo;
	
	@FindBy(xpath="//*[@id='hc_OK']")
	WebElement okButton;
	
	public RosirPage() {
		
	}
	
	public boolean validateRentalOrderSupplementalIsDisplayed() {
		waitForVisibility(rspPageTitle);
		String text = rspPageTitle.getText();
		boolean status = text.contains(td.getTestData(BaseTest.environment, "rspText"));
		return status;
	}
	
	public void enterServiceType() {
		serialNumber.sendKeys(Keys.TAB);
		try {
			Thread.sleep(3000);
			//sendKeys(serviceType, td.getTestData(BaseTest.environment, "serviceType"));
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void enterPatientFirstName() {
		serviceType.sendKeys(Keys.TAB);
		//sendKeys(patientFirstName, td.getTestData(BaseTest.environment, "patientFirstName"));
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void enterPatientLastName() {
		patientFirstName.sendKeys(Keys.TAB);
		//sendKeys(patientLastName, td.getTestData(BaseTest.environment, "patientLastName"));
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void enterPatientRoomNumber() {
		patientLastName.sendKeys(Keys.TAB);
		referringDoctor.sendKeys(Keys.TAB);
		gender.sendKeys(Keys.TAB);
		//sendKeys(patientRoomNumber, td.getTestData(BaseTest.environment, "patientRoomNumber"));
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void enterPatientWardNumber() {
		patientRoomNumber.sendKeys(Keys.TAB);
		//sendKeys(patientWardNumber, td.getTestData(BaseTest.environment, "patientWardNumber"));
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void enterCustomerPoNumber() {
		patientWardNumber.sendKeys(Keys.TAB);
		medicalRecord.sendKeys(Keys.TAB);
		billingDate.sendKeys(Keys.TAB);
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		equipDate.sendKeys(Keys.TAB);
		billingOffDate.sendKeys(Keys.TAB);
		equipOffDate.sendKeys(Keys.TAB);
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		//sendKeys(customerPo, td.getTestData(BaseTest.environment, "customerPo"));
		try {
			Thread.sleep(4000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public WorkWithContactsPage clickOkButton() {
		//click(okButton);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		//click(okButton);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		//click(okButton);
		try {
			Thread.sleep(30000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		WorkWithContactsPage wcp = new WorkWithContactsPage();
		return wcp;
	}

}
