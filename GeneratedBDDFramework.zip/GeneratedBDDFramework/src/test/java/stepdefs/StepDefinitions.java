package stepdefs;

import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.WebDriverManager;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class StepDefinitions {

    WebDriver driver = WebDriverManager.getDriver();
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

    Map<String, String> elementMap = new HashMap<String, String>() {{
        put("username", "//*[@id="username"]");
        put("password", "//*[@id="password"]");
        put("loginbtn", "//*[@id="loginbtn"]");
        put("btn2 btn-warning", "//*[@id="content"]/nav/div/div[3]/div/span/span/a");
        put("issueTitle", "//*[@id="issueTitle"]");
        put("issueConfirmationDate", "//*[@id="issueConfirmationDate"]");
        put("ui-state-default ui-state-highlight ui-state-hover", "//*[@id="ui-datepicker-div"]/table/tbody/tr[3]/td[6]/a");
        put("glyphicon glyphicon-plus", "//*[@id="addRowIdDoc"]/span");
        put("relatedDocsList[0].documentType", "//*[@id="docType_0"]");
        put("relatedDocsList[0].documentNumber", "//*[@id="docNo_0"]");
        put("scrollbx", "//*[@id="relatedTable"]/div[3]");
        put("supplierInitAction", "//*[@id="supplierInitAction"]");
        put("division", "//*[@id="division"]");
        put("faAssesmentOwnerInput", "//*[@id="faAssesmentOwnerInput"]");
        put("-791047907-selectable", "//*[@id="-791047907-selectable"]");
        put("issueCategory", "//*[@id="issueCategory"]");
        put("issueSubCategory", "//*[@id="issueSubCategory"]");
        put("submit_details", "//*[@id="submit_details"]");
        put("mandatoryBtnNo", "//*[@id="mandatoryBtnNo"]");
        put("descIssueAndPotentialImpact", "//*[@id="descIssueAndPotentialImpact"]");
        put("esignPerson", "//*[@id="esignPerson"]");
        put("signatureBtnYes", "//*[@id="signatureBtnYes"]");
        put("toastclose", "//*[@id="toastclose"]");
        put("profile", "//*[@id="profile"]");
        put("Logout", "//*[@id="logoutDropdown"]/a");
    }};

    @Given("I open the application {string}")
    public void i_open_the_application(String url) {
        driver.get(url);
    }

    @When("I input {string} into {string}")
    public void i_input_into(String value, String name) {
        String xpath = elementMap.get(name);
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
        element.clear();
        element.sendKeys(value);
    }

    @When("I click {string}")
    public void i_click(String name) {
        String xpath = elementMap.get(name);
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        element.click();
    }
}
