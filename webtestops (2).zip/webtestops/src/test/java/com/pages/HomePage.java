package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tests.BaseTest;
import com.utils.TestData;

public class HomePage extends BasePage {
	
	TestData td = new TestData();

	public HomePage() {
		
	}
	
	@FindBy(xpath= "//td[text()='Home']")
	WebElement homeText;
	
	@FindBy(xpath = "//*[@id='usernameDiv']")
	WebElement usernameText;
	
	@FindBy(xpath="//*[@id='drop_mainmenu']")
	WebElement dropdown;
	
	@FindBy(xpath= "//*[@id='TE_FAST_PATH_BOX']")
	WebElement fastpathTextBox;
	
	@FindBy(xpath = "//*[@id='fastPathButton']")
	WebElement fastpathButton;
	
	public boolean validateIfLoginIsSuccessful() {
		BaseTest tb = new BaseTest();
		boolean status;
		try {
			if(usernameText.isDisplayed()) {
				tb.getDriver().navigate().refresh();
				Thread.sleep(4000);
			}else {
				tb.getDriver().navigate().refresh();
				Thread.sleep(4000);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		waitForVisibility(homeText);
		status = homeText.isDisplayed();
		return status;
	}
	
	public void clickOnDropDown() {
		dropdown.click();
	}
	
	public void enterCustomerId() {
		fastpathTextBox.sendKeys(td.getTestData(BaseTest.environment, "customerId"));
	}
	
	public WorkWithContactsPage clickOnFastPathButton() {
		//click(fastpathButton);
		WorkWithContactsPage wwcp = new WorkWithContactsPage();
		return wwcp;
	}
}
