package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tests.BaseTest;
import com.utils.TestData;

public class WorkWithOrdersPage extends BasePage {
	
	TestData td = new TestData();
	BaseTest tb = new BaseTest();
	
	@FindBy(xpath= "//*[@id='jdeFormTitle0']")
	WebElement wwoPageTitle;
	
	@FindBy(xpath = "//input[@type='checkbox' and @tabindex='21']")
	WebElement checkbox;
	
	@FindBy(xpath = "//td[@colindex='0']/div/a")
	WebElement orderNumber;

	public WorkWithOrdersPage() {
		
	}
	
	public boolean validateWorkWithWorkOrderScreenIsDisplayed() {
		waitForVisibility(wwoPageTitle);
		String text = wwoPageTitle.getText();
		boolean status = text.contains(td.getTestData(BaseTest.environment, "wwoPageText"));
		return status;
	}
	
	public void clickOnCheckBox() {
		WebElement element = tb.getDriver().findElement(By.xpath("//input[@type='checkbox' and @tabindex='21']"));
		((JavascriptExecutor) tb.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		//click(checkbox);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public WorkOrderRevisionsPage clickOnOrderNumber() {
		//click(orderNumber);
		try {
			Thread.sleep(30000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		WorkOrderRevisionsPage wor = new WorkOrderRevisionsPage();
		return wor;
	}

}
