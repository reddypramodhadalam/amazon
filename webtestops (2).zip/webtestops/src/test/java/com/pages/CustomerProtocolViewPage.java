package com.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tests.BaseTest;
import com.utils.TestData;

public class CustomerProtocolViewPage extends BasePage {
	
	TestData td = new TestData();
	
	@FindBy(xpath= "//*[@id='jdeFormTitle0']")
	WebElement cpPageTitle;
	
	@FindBy(xpath="//*[@id='hc_Cancel']")
	WebElement cancelButton;
	
	public CustomerProtocolViewPage() {
		
	}
	
	public boolean validateIfCustomerProtocolViewPageIsDisplayed() {
		waitForVisibility(cpPageTitle);
		String text = cpPageTitle.getText();
		boolean status = text.contains(td.getTestData(BaseTest.environment, "cpvText"));
		return status;
	}
	
	public SwwrPage clickOnCancelButton() {
		//click(cancelButton);
		try {
			Thread.sleep(2000);
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SwwrPage swp = new SwwrPage();
		return swp;
	}
	
}
