package com.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.report.ExtentReportNG;
import com.tests.BaseTest;

/*
 * Developed by Baxter@Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class BasePage {
	static String parentWindow;
	private WebDriver driver;
	ExtentReportNG ern = new ExtentReportNG();

	public BasePage() {
		this.driver = new BaseTest().getDriver();
		PageFactory.initElements(driver, this);
	}

	// Switching to alert and accepting the alert
	public boolean SwitchAlert() {
		boolean Flag = false;
		try {
			if (driver.switchTo().alert() != null) {
				driver.switchTo().alert().accept();
				Flag = true;
			}
		} catch (NoAlertPresentException e) {
		}
		return Flag;
	}

	// double click on any webelement
	public void doubleClick(WebElement element, String message) {
		String text = message.replaceAll("\\s+", "");
		String filePath = null;
		try {	
			filePath = highlightElement(element, text);
		} catch (Exception e) {
			e.printStackTrace();
		}
		ern.enterLogAndCapture(message, filePath);
		if ((driver != null) && (element != null)) {
			(new Actions(driver)).doubleClick(element).build().perform();
		}
	}

	// Dynamically waiting for visibility of webelement
	public boolean waitForVisibility(WebElement ele) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		return wait.until(ExpectedConditions.visibilityOf(ele)) != null;
	}

	// Clicking on a webelement
	public void click(WebElement ele, String message) {
		String text = message.replaceAll("\\s+", "");
		String filePath = null;
		try {	
			filePath = highlightElement(ele, text);
		} catch (Exception e) {
			e.printStackTrace();
		}
		ern.enterLogAndCapture(message, filePath);
		waitForVisibility(ele);
		ele.click();
	}

	// Entering text in a text box
	public void sendKeys(WebElement ele, String txt, String message) {
		waitForVisibility(ele);
		ele.sendKeys(txt);
		String text = message.replaceAll("\\s+", "");
		String filePath = null;
		try {	
			filePath = highlightElement(ele, text);
		} catch (Exception e) {
			e.printStackTrace();
		}
		ern.enterLogAndCapture(message, filePath);
	}

	// Getting html attribute of a web element
	public String getAttribute(WebElement ele, String attribute, String message) {
		String text = message.replaceAll("\\s+", "");
		String filePath = null;
		try {	
			filePath = highlightElement(ele, text);
		} catch (Exception e) {
			e.printStackTrace();
		}
		ern.enterLogAndCapture(message, filePath);
		return ele.getAttribute(attribute);
	}

	// Selecting drop down value from a web page
	public void selectDropDownValue(WebElement element, String value) {
		try {
			if (element != null) {
				Select selectBox = new Select(element);
				selectBox.selectByValue(value);
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Decrypting values of an ecrypted string
	public String decryptString(String decryptValue) {
		String result = new String();
		char[] charArray = decryptValue.toCharArray();
		for (int i = 0; i < charArray.length; i = i + 2) {
			String st = "" + charArray[i] + "" + charArray[i + 1];
			char ch = (char) Integer.parseInt(st, 16);
			result = result + ch;
		}
		return result;
	}

	public void switchWindow() {
		parentWindow = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();
		System.out.println("Total Windows::::::::::::" + s.size());
		Iterator<String> I1 = s.iterator();
		while (I1.hasNext()) {
			String child_window = I1.next();
			if (!parentWindow.equals(child_window)) {
				driver.switchTo().window(child_window);
			}
		}
		System.out.println(driver.getTitle());

	}

	public void switchToParentWindow() {
		driver.switchTo().window(parentWindow);
	}

	public String getCurrentDateAndTime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		return dtf.format(now);
	}

	public void waitUntilPageLoad(WebDriver driver) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(5)).ignoring(Exception.class);
		ExpectedCondition<Boolean> documentReady = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				String state = (String) js.executeScript("return document.readyState;");
				return state.equals("complete");
			}
		};
	}

	public String highlightElement(WebElement element, String stepName) {
		TakesScreenshot ts = (TakesScreenshot)driver;
		for (int i = 0; i < 2; i++) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid orange'", element);
		}
		File source = ts.getScreenshotAs(OutputType.FILE);
		File file = new File(System.getProperty("user.dir") +File.separator +"reports"+File.separator+ stepName + ".png");
		try {
			FileUtils.copyFile(source, file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].style.border='0px solid orange'", element);
		return System.getProperty("user.dir")  +File.separator +"reports" +File.separator + stepName + ".png";
	}

}
