package com.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.pages.CustomerProtocolViewPage;
import com.pages.HomePage;
import com.pages.RosirPage;
import com.pages.SodrPage;
import com.pages.SwwrPage;
import com.pages.WorkOrderRevisionsPage;
import com.pages.WorkWithContactsPage;
import com.pages.WorkWithOrdersPage;
import com.report.ExtentReportNG;
import com.report.Retry;

/*
 * Developed by Baxter @Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 27th August 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class RentalDeliveryTest extends BaseTest {
	ExtentReportNG ern = new ExtentReportNG();

	@Test
	public void rentalDeliveryCreation() {
		boolean initialLoadStatus = lp.validateLoginPageDisplay();
		ern.enterLog("JDE application loaded");
		Assert.assertTrue(initialLoadStatus, "JDE Application is not displayed properly");
		lp.enterUsername("Entering Username");
		lp.enterPassword("Entering password");
		HomePage hp = lp.clickOnLoginButton("Clicking on sign in button");
		boolean loginStatus = hp.validateIfLoginIsSuccessful();
		Assert.assertTrue(loginStatus, "Home page is not displayed, login is not successful");
		// hp.clickOnDropDown();
		// hp.enterCustomerId();
		// WorkWithContactsPage wwcp = hp.clickOnFastPathButton();
		// boolean workWithContactScreen =
		// wwcp.validateIfWorkWithContactsPageIsDisplayed();
		// Assert.assertTrue(workWithContactScreen, "Work with Contacts screen is not
		// displayed");
		// CustomerProtocolViewPage cpvp = wwcp.enterShipToFieldData();
		// boolean customerProtocolViewScreen =
		// cpvp.validateIfCustomerProtocolViewPageIsDisplayed();
		// Assert.assertTrue(customerProtocolViewScreen, "Customer Protocol View screen
		// is not displayed");
		// SwwrPage swp = cpvp.clickOnCancelButton();
		// boolean swwrStatus = swp.validateIfSelectWhoIsWhoRecordPageIsDisplayed();
		// Assert.assertTrue(swwrStatus, "Select Who's who Record Screen is not
		// displayed");
		// wwcp = swp.clickOnCancelButton();
		// boolean workWithContactScreen1 =
		// wwcp.validateIfWorkWithContactsPageIsDisplayed();
		// Assert.assertTrue(workWithContactScreen1, "Work with Contacts screen is not
		// displayed");
		// wwcp.enterCallerFirstName();
		// wwcp.enterCallerLastName();
		// wwcp.enterCallerPhoneNumber();
		// wwcp.enterCallerDepartment();
		// wwcp.enterCallerTeamType();
		// wwcp.clickOnFormDropDown();
		// SodrPage sdp = wwcp.clickOnRentalOrder();
		// boolean sodrStatus = sdp.validateSalesOrderDetailsPageIsDisplayed();
		// Assert.assertTrue(sodrStatus, "Sales Order Details Revisions screen is not
		// displayed");
		// sdp.pressingTabInSodrPage();
		// sdp.enterItemNumber();
		// sdp.clickOnFormDropDown();
		// RosirPage rsp = sdp.clickOnSupplementalInfo();
		// boolean rosirStatus = rsp.validateRentalOrderSupplementalIsDisplayed();
		// Assert.assertTrue(rosirStatus, "Rental order Supplemental Info Revision
		// screen is not displayed");
		// rsp.enterServiceType();
		// rsp.enterPatientFirstName();
		// rsp.enterPatientLastName();
		// rsp.enterPatientRoomNumber();
		// rsp.enterPatientWardNumber();
		// rsp.enterCustomerPoNumber();
		// wwcp = rsp.clickOkButton();
		// boolean workWithContactScreen2 =
		// wwcp.validateIfWorkWithContactsPageIsDisplayed();
		// Assert.assertTrue(workWithContactScreen2, "Work with Contacts screen is not
		// displayed");
		// wwcp.clickOnFindButton();
		// WorkWithOrdersPage wwp = wwcp.clickOnWorkOrderInquiry();
		// boolean wwoStatus = wwp.validateWorkWithWorkOrderScreenIsDisplayed();
		// Assert.assertTrue(wwoStatus, "Work with Work Orders screen is not
		// displayed");
		// wwp.clickOnCheckBox();
		// WorkOrderRevisionsPage wor = wwp.clickOnOrderNumber();
		// boolean worStatus = wor.validateWorkOrderRevisionsScreenIsDisplayed();
		// Assert.assertTrue(worStatus, "Work Order Revisions screen is not displayed");
		// wor.clickOnSerialNumber();
		// wor.enterCustomerNumber();
		// wor.enterEquipmentStatus();
		// wor.clickOnFindButton();
		// wor.clickOnSelectButton();
		// wor.clickOnPlanningTab();
		// wor.updateStatus();
		// wor.enterCompletionDateAndTime();
		// wor.enterPrimaryTechnicianData();
		// wwp = wor.clickOnOkButton();
		// boolean wwoStatus1 = wwp.validateWorkWithWorkOrderScreenIsDisplayed();
		// Assert.assertTrue(wwoStatus1, "Work with Work Orders screen is not
		// displayed");
	}

	@Test
	public void validateLogin() {
		boolean initialLoadStatus = lp.validateLoginPageDisplay();
		ern.enterLog("JDE application loaded");
		Assert.assertTrue(initialLoadStatus, "JDE Application is not displayed properly");
		lp.enterUsername("Entering Username");
		lp.enterPassword("Entering password");
		HomePage hp = lp.clickOnLoginButton("Clicking on sign in button");
		boolean loginStatus = hp.validateIfLoginIsSuccessful();
		Assert.assertFalse(loginStatus, "Home page is not displayed, login is not successful");
	}

}
