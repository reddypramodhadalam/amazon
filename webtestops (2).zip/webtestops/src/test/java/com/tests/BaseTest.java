package com.tests;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import com.pages.LoginPage;
import com.utils.TestData;

import io.github.bonigarcia.wdm.WebDriverManager;

/*
 * Developed by Baxter @Webtestops
 * Resource Name - Reddy Pramodh
 * Date: 11th March 2024
 * Last Code Checkin - 11th March 2024
 * This is Baxter Proprietary Framework - Don't use without any permissions
 * Modified By - Reddy Pramodh
 */

public class BaseTest {
	public static String environment=System.getProperty("environment");
	public static String browserName=System.getProperty("browser");
	TestData td = new TestData();
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	public LoginPage lp;
	
	
	public static WebDriver getDriver(){
		return driver.get();
	}

	public static void setDriver(WebDriver driver2){
		driver.set(driver2);
	}
    public void initializeDriver() throws IOException {
		WebDriver webDriver = null;
		if (browserName.contains("chrome") || browserName.contains("Chrome")) {
			ChromeOptions options = new ChromeOptions();
			WebDriverManager.chromedriver().setup();
			if(browserName.contains("headless")){
				options.addArguments("headless");
			}		
			webDriver = new ChromeDriver(options);
			webDriver.manage().window().maximize();

		} else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver",
					"");
			webDriver = new FirefoxDriver();
			// Firefox
		} else if (browserName.equalsIgnoreCase("edge")) {
			// Edge
			System.setProperty("webdriver.edge.driver", "");
			webDriver = new EdgeDriver();
		}
		webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		webDriver.manage().window().maximize();
		BaseTest.driver.set(webDriver);
	}

    public String getScreenshot(String testCaseName,WebDriver driver) throws IOException {
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File file = new File(System.getProperty("user.dir") +File.separator +"reports"+File.separator+ testCaseName + ".png");
		FileUtils.copyFile(source, file);
		return System.getProperty("user.dir")  +File.separator +"reports" +File.separator + testCaseName + ".png";
	}

    @BeforeMethod(alwaysRun=true)
    public LoginPage launchBrowser() throws IOException {
        initializeDriver();
		lp = new LoginPage();
		lp.goTo();
		return lp;
    }

    @AfterMethod(alwaysRun=true)
	public void tearDown() {
		getDriver().close();
		if(driver!=null) {
			getDriver().quit();
		}
	}
}